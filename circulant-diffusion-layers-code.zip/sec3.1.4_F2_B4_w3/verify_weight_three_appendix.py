"""Reproduce Appendix A.1 using only Python's standard library."""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("3.1.4") / "results"

import csv
import json
import math
import time
from functools import lru_cache
from itertools import combinations
from pathlib import Path

ROOT = Path(__file__).resolve().parent
OUT = RESULTS / 'weight_three_verification'
OUT.mkdir(exist_ok=True)


def remainder(a, b):
    while a and a.bit_length() >= b.bit_length():
        a ^= b << (a.bit_length() - b.bit_length())
    return a


def gcd(a, b):
    while b:
        a, b = b, remainder(a, b)
    return a


def matching(adj):
    @lru_cache(None)
    def solve(mask):
        if not mask:
            return 0
        vertices = [i for i in range(len(adj)) if mask & (1 << i)]
        v = min(vertices, key=lambda i: (adj[i] & mask).bit_count())
        bit = 1 << v
        rest = mask ^ bit
        best = solve(rest)
        choices = adj[v] & rest
        while choices:
            edge = choices & -choices
            choices ^= edge
            best = max(best, 1 + solve(rest ^ edge))
        return best
    return solve((1 << len(adj)) - 1)


def classified_cost(n, support):
    if n % 2 == 0 and any((v + n // 2) % n in support for v in support):
        return 3 * n // 2
    for middle in support:
        ends = list(support - {middle})
        if (sum(ends) - 2 * middle) % n == 0:
            step = (ends[0] - middle) % n
            components = math.gcd(n, step)
            length = n // components
            assert length % 3
            return 2 * n - components * (length // 2)
    return 2 * n


supports = []
summary = []
for n in range(4, 34):
    started = time.perf_counter()
    current = []
    for a, b in combinations(range(1, n), 2):
        support = {0, a, b}
        if gcd(1 | (1 << a) | (1 << b), (1 << n) | 1) != 1:
            continue
        rows = [{(i + d) % n for d in support} for i in range(n)]
        adj = [0] * n
        for i, j in combinations(range(n), 2):
            overlap = len(rows[i] & rows[j])
            assert overlap < 3
            if overlap == 2:
                adj[i] |= 1 << j
                adj[j] |= 1 << i
        cost = 2 * n - matching(adj)
        assert cost == classified_cost(n, support)
        current.append(dict(n=n, support=sorted(support),
                            connected=math.gcd(n, a, b) == 1, cost=cost))
    connected = [r for r in current if r['connected']]
    factor = n
    power = 1
    while factor % 3 == 0:
        factor //= 3
        power *= 3
    expected = 3*n//2 if n % 2 == 0 else ((3*n+power)//2 if factor > 1 else 2*n)
    assert min(r['cost'] for r in current) == expected
    summary.append(dict(n=n, candidates=math.comb(n-1, 2),
                        invertible=len(current), connected=len(connected),
                        minimum=expected,
                        connected_minimum=min(r['cost'] for r in connected),
                        mismatches=0, rerun_seconds=time.perf_counter()-started))
    supports.extend(current)
assert len(supports) == 4617

circuits = []
for n in range(8, 129):
    inputs = [1 << i for i in range(n)]
    outputs = [None] * n
    depths = [0] * n
    gates = 0
    for start in range(0, 5 * (n // 5), 5):
        x = [inputs[(start+i) % n] for i in range(8)]
        t1, t2, t3 = x[1] ^ x[3], x[3] ^ x[4], x[4] ^ x[5]
        t4 = x[2] ^ t2
        values = [x[0] ^ t1, t4 ^ t1, t4 ^ t3, x[6] ^ t2, x[7] ^ t3]
        for offset, value in enumerate(values):
            outputs[start+offset] = value
            depths[start+offset] = [2, 3, 3, 2, 2][offset]
        gates += 9
    for i in range(5 * (n // 5), n):
        outputs[i] = inputs[i] ^ inputs[(i+1) % n] ^ inputs[(i+3) % n]
        depths[i] = 2
        gates += 2
    assert outputs == [inputs[i] ^ inputs[(i+1) % n] ^ inputs[(i+3) % n] for i in range(n)]
    invertible = gcd(0b1011, (1 << n) | 1) == 1
    assert invertible == (n % 7 != 0)
    assert gates == 2*n - n//5
    circuits.append(dict(n=n, groups=n//5, remainder=n % 5, gates=gates,
                         depth=max(depths), invertible=invertible,
                         outputs_checked=n, mismatches=0))

for row in circuits:
    n = row['n']
    factor, power = n, 1
    while factor % 3 == 0:
        factor //= 3
        power *= 3
    row['rectangle_class_minimum'] = (3*n//2 if n % 2 == 0 else
                                      (3*n+power)//2 if factor > 1 else 2*n)

for name, records in [('support_summary', summary), ('circuits', circuits)]:
    with (OUT / (name+'.csv')).open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
(OUT / 'all_supports.json').write_text(json.dumps(supports, indent=2), encoding='utf-8')
(OUT / 'verification.json').write_text(json.dumps(dict(
    support_summary=summary, circuits=circuits,
    timing_note='rerun_seconds measures this rerun, not the original experiment'), indent=2), encoding='utf-8')

tex = [r'\begin{longtable}{rrrrrr}',
       r'\caption{Complete support enumeration for $4\le n\le33$. Counts retain all supports containing position $0$.}\label{tab:appendix-weight-three-supports}\\',
       r'\hline',
       r'$n$ & Tested & Invertible & Connected & $\min C_{\mathrm{rect}}$ & $\min_{\mathrm{conn}} C_{\mathrm{rect}}$\\',
       r'\hline\endfirsthead', r'\hline',
       r'$n$ & Tested & Invertible & Connected & $\min C_{\mathrm{rect}}$ & $\min_{\mathrm{conn}} C_{\mathrm{rect}}$\\',
       r'\hline\endhead', r'\hline\endfoot']
for row in summary:
    tex.append(' & '.join(str(row[k]) for k in ('n','candidates','invertible','connected','minimum','connected_minimum')) + r'\\')
tex += [r'\end{longtable}',
        r'\begin{longtable}{rrrrrrr}',
        r'\caption{Nine-gate constructions and rectangle minima for odd $9\le n\le128$ with $3\mid n$ and $7\nmid n$.}\label{tab:appendix-weight-three-circuits}\\',
        r'\hline', r'$n$ & \shortstack{Groups\\of five} & \shortstack{Remaining\\outputs} & Gates & \multicolumn{2}{c}{$\min C_{\mathrm{rect}}$} & Depth\\',
        r' & & & & \shortstack{No connectivity\\constraint} & Connected & \\',
        r'\hline\endfirsthead', r'\hline',
        r'$n$ & \shortstack{Groups\\of five} & \shortstack{Remaining\\outputs} & Gates & \multicolumn{2}{c}{$\min C_{\mathrm{rect}}$} & Depth\\',
        r' & & & & \shortstack{No connectivity\\constraint} & Connected & \\',
        r'\hline\endhead', r'\hline\endfoot']
for row in circuits:
    if row['n'] % 2 == 0 or row['n'] % 3 != 0 or not row['invertible']:
        continue
    tex.append(' & '.join([str(row[k]) for k in ('n','groups','remainder','gates')]
                         + [str(row['rectangle_class_minimum']), str(2*row['n']), str(row['depth'])]) + r'\\')
tex += [r'\end{longtable}']
(RESULTS / 'appendix_weight_three_tables.tex').write_text('\n'.join(tex)+'\n', encoding='utf-8')
print(json.dumps(dict(invertible_supports=len(supports),
    circuit_orders=len(circuits), outputs_checked=sum(r['outputs_checked'] for r in circuits),
    n33=summary[-1]), indent=2))
