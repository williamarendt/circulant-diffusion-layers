# Section 3.1.4: Binary Field, B=4, w=3

- `verify_weight_three_appendix.py`: exhaustively enumerates small-order supports, checks the analytical rectangle-cost formulas using maximum matching, and verifies the nine-gate construction. Also generates the data in the current Appendix B.2 (formerly A.1, then B.1).
- `results/weight_three_verification/`: saved verification data.
- `results/gurobi/`: reports, checkpoints, and witnesses for binary B4/w3 cases from the earlier batches. Analytical shortcuts retain the `closed_form` label.
- `run_gurobi.py`: entry point to the shared `../common/circrect` search with this section's parameters. Example: `python run_gurobi.py --n-values 4:16 --dry-run`.

This section primarily uses analytical classification and maximum matching. The standalone verification script requires neither Gurobi nor SciPy. It regenerates verification files in this directory's `results/`, so inspect its output paths before running it.
