"""Audit saved finite optima and exact complete-cover exclusion certificates."""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("4.2.4") / "results"

from collections import defaultdict
from itertools import combinations
import json
from math import comb, gcd
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from circrect.algebra import circulant, inverse
from circrect.packing import rectangles
from circrect.witness import verify
from verify_section42 import attaining_factors, overlap_test

RUNS = RESULTS/'gurobi'


def load_report(n, p, connected=False):
    folder = RUNS/f'fp_p{p}_B5_n{n}_k4{"_connected" if connected else ""}'
    report = json.loads((folder/'report.json').read_text())
    assert report['config']['n'] == n and report['config']['prime'] == p
    assert report['config']['weight'] == 4 and report['config']['connected_only'] == connected
    assert report['status'] in ('GLOBAL_OPTIMUM', 'TARGET_ATTAINED', 'NO_FEASIBLE_FIXED_WEIGHT')
    if report['best_cost'] is not None:
        assert report['global_lower_bound'] == report['best_cost']
        witness = json.loads((folder/'best_witness.json').read_text())
        verify(witness)
        assert witness['cost'] == report['best_cost']
    return dict(n=n, p=p, connected=connected, cost=report['best_cost'],
                status=report['status'], source=str((folder/'report.json').relative_to(ROOT)))


def complete_cover(a):
    """Select one of three input-pair partitions per row, with propagation."""
    n = len(a)
    matrix = circulant(a, 3)
    items = rectangles(matrix, 3, 2, 2)
    paired = {}
    for j, item in enumerate(items):
        cols = tuple(item['cols'])
        for row in item['rows']:
            assert (row, cols) not in paired
            paired[row, cols] = j
    configurations = []
    row_rectangle_choice = {}
    for row in range(n):
        cols = [j for j in range(n) if matrix[row][j]]
        choices = []
        for other in range(1, 4):
            first = tuple(sorted((cols[0], cols[other])))
            second = tuple(c for c in cols if c not in first)
            if (row, first) in paired and (row, second) in paired:
                choice = (paired[row, first], paired[row, second])
                for rectangle in choice:
                    row_rectangle_choice[row, rectangle] = len(choices)
                choices.append(choice)
        if not choices:
            return False
        configurations.append(choices)

    def propagate(assigned, row, choice):
        pending = [(row, choice)]
        while pending:
            row, choice = pending.pop()
            if row in assigned:
                if assigned[row] != choice:
                    return False
                continue
            assigned[row] = choice
            for rectangle in configurations[row][choice]:
                for neighbor in items[rectangle]['rows']:
                    required = row_rectangle_choice.get((neighbor, rectangle))
                    if required is None:
                        return False
                    pending.append((neighbor, required))
        return True

    def search(assigned):
        if len(assigned) == n:
            return True
        row = min((i for i in range(n) if i not in assigned),
                  key=lambda i: len(configurations[i]))
        for choice in range(len(configurations[row])):
            trial = dict(assigned)
            if propagate(trial, row, choice) and search(trial):
                return True
        return False

    return search({})


def exclusion_audit(n):
    start = time.perf_counter()
    path = RUNS/f'fp_p3_B5_n{n}_k4'/'checkpoint.json'
    checkpoint = json.loads(path.read_text())
    assert checkpoint['enumeration_complete']
    assert not checkpoint['config']['connected_only']
    units = [u for u in range(1, n) if gcd(u, n) == 1]
    seen = set()
    counts = defaultdict(int)
    for key in checkpoint['records']:
        support = tuple(tuple(pair) for pair in json.loads(key))
        assert support not in seen
        seen.add(support)
        orbit = {tuple(sorted(((j-anchor)*u % n, value*anchor_value)
                              for j, value in support))
                 for u in units for anchor, anchor_value in support}
        assert min(orbit) == support
        size = len(orbit)
        counts['affine_classes'] += 1
        counts['normalized_generators'] += size
        a = [0]*n
        for j, value in support:
            a[j] = value
        if any(c+max(cp, cm) > 5 for c, cp, cm in overlap_test(a)):
            continue
        counts['two_column_classes'] += 1
        counts['two_column_generators'] += size
        if complete_cover(a):
            counts['complete_cover_classes'] += 1
            counts['complete_cover_generators'] += size
            if inverse(circulant(a, 3), 3) is not None:
                counts['invertible_complete_cover_classes'] += 1
                counts['invertible_complete_cover_generators'] += size
    assert counts['normalized_generators'] == 8*comb(n-1, 3)
    assert counts['invertible_complete_cover_classes'] == 0
    counts['seconds'] = round(time.perf_counter()-start, 3)
    print('exclusion', n, dict(counts), flush=True)
    return dict(n=n, counts=dict(counts), source=str(path.relative_to(ROOT)))


def main():
    for n in (9, 11, 12, 13, 15):
        assert complete_cover(attaining_factors(n, n % 2 == 0))
    optima = [load_report(n, p) for n in list(range(4, 17))+[32, 64] for p in (3, 5)]
    connected = [load_report(n, p, c) for n in (32, 64)
                 for p in (3, 5, 7, 11) for c in (False, True)]
    print('saved optimum reports and witnesses checked', len(optima)+len(connected), flush=True)
    excluded = [4, 5, 6, 7, 8, 10, 14, 16, 32, 64]
    certificates = [exclusion_audit(n) for n in excluded]
    result = dict(all_checks_passed=True, optima=optima,
                  connected_comparisons=connected, exclusions=certificates,
                  analytic_attainment_orders=[9, 11, 12, 13, 15])
    (RESULTS / 'section424_audit.json').write_text(
        json.dumps(result, indent=2)+'\n', encoding='utf-8')


if __name__ == '__main__':
    main()
