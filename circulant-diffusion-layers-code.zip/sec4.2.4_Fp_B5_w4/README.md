# Section 4.2.4: Odd Prime Fields, B=5, w=4

- `audit_section424.py`: reads this section's `results/gurobi/` and audits finite optimum reports, witnesses, and evidence excluding complete rectangle covers.
- `verify_section42.py`: reused by the audit; also verifies the branch number criteria, attaining constructions, and depth results in Section 4.2.
- `results/section424_audit.json`, `results/section42_verification.json`: saved audit and verification outputs.
- `run_gurobi.py`: entry point to the original shared Gurobi search. Example: `python run_gurobi.py --n-values 8 --primes 5 --dry-run`.

Finite minimum rectangle costs come from Gurobi rectangle-packing searches. To determine whether cost 2n is attainable, the code instead enumerates row pairings and complete rectangle covers, then checks rank. This is a cover-existence check, not a SciPy integer program.
