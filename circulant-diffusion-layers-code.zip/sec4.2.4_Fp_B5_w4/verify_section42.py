"""Exact finite verification of Section 4.2 constructions and lemmas."""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("4.2.4") / "results"

from collections import Counter
from itertools import combinations, product
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from circrect.algebra import circulant, components, inverse, security
from circrect.packing import rectangles


def brute_branch_five(matrix, p):
    n = len(matrix)
    # For invertible weight-four matrices, weights >=4 are automatic.
    for size in (2, 3):
        for cols in combinations(range(n), size):
            for tail in product(range(1, p), repeat=size-1):
                coeff = (1,)+tail
                weight = sum(sum(c*row[j] for c, j in zip(coeff, cols)) % p != 0
                             for row in matrix)
                if size+weight < 5:
                    return False
    return True


def overlap_test(a):
    n = len(a)
    details = []
    for d in range(1, n):
        products = [a[j]*a[(j+d) % n] for j in range(n) if a[j] and a[(j+d) % n]]
        positive, negative = products.count(1), products.count(-1)
        details.append((len(products), positive, negative))
    return details


def local_test(matrix, p):
    n = len(matrix)
    support = [{i for i in range(n) if matrix[i][j]} for j in range(n)]
    kind = {}
    for a, b in combinations(range(n), 2):
        common = support[a] & support[b]
        if len(common) > 2:
            return None
        if len(common) == 2:
            products = {matrix[i][a]*matrix[i][b] % p for i in common}
            kind[a, b] = len(products) == 1
    for a, b, c in combinations(range(n), 3):
        pairs = ((a, b), (a, c), (b, c))
        if all(pair in kind for pair in pairs) and not (support[a]&support[b]&support[c]):
            if sum(kind[pair] for pair in pairs) == 2:
                return False
    return True


def determinant_integer(matrix):
    a = [list(row) for row in matrix]
    n = len(a)
    previous, sign = 1, 1
    for k in range(n-1):
        pivot = next((i for i in range(k, n) if a[i][k]), None)
        if pivot is None:
            return 0
        if pivot != k:
            a[k], a[pivot] = a[pivot], a[k]
            sign = -sign
        value = a[k][k]
        for i in range(k+1, n):
            for j in range(k+1, n):
                numerator = a[i][j]*value-a[i][k]*a[k][j]
                assert numerator % previous == 0
                a[i][j] = numerator//previous
            a[i][k] = 0
        previous = value
    return sign*a[-1][-1]


def attaining_factors(n, even=False):
    if not even:
        assert n >= 9 and n % 2
        a = [int(j in (0, 1, 3, 4)) for j in range(n)]
        left = circulant([int(j in (0, 3)) for j in range(n)], 1000000007)
        right = circulant([int(j in (0, 1)) for j in range(n)], 1000000007)
    else:
        assert n >= 12 and n % 8 == 4
        k = n//2
        a = [0]*n
        a[0], a[1], a[2], a[k+1] = 1, 1, 1, -1
        right = []
        signals = {}
        for i in range(0, n, 2):
            for which in (1, 2):
                row = [0]*n
                if which == 1:
                    row[i], row[(i+1) % n] = 1, 1
                else:
                    row[(i+2) % n], row[(i+k+1) % n] = 1, -1
                signals[i, which] = len(right)
                right.append(row)
        left = [[0]*n for _ in range(n)]
        for i in range(n):
            if i % 2 == 0:
                left[i][signals[i, 1]] = 1
                left[i][signals[i, 2]] = 1
            else:
                left[i][signals[(i+1) % n, 1]] = 1
                left[i][signals[(i-k-1) % n, 2]] = -1

    used = set()
    for j in range(n):
        rows = [i for i in range(n) if left[i][j]]
        cols = [i for i in range(n) if right[j][i]]
        assert len(rows) == len(cols) == 2
        for i in rows:
            for c in cols:
                assert (i, c) not in used
                assert left[i][j]*right[j][c] == a[(c-i) % n]
                used.add((i, c))
    assert len(used) == 4*n
    assert all(sum(v != 0 for v in row) == 2 for row in left+right)
    assert all(sum(left[i][j] != 0 for i in range(n)) == 2 for j in range(n))
    assert all(sum(right[i][j] != 0 for i in range(n)) == 2 for j in range(n))
    for factor in (left, right):
        det = abs(determinant_integer(factor))
        assert det and det & (det-1) == 0
    return a


def ternary_example():
    n, p = 9, 3
    x = [tuple(int(i == j) for j in range(n)) for i in range(n)]
    signals = [(row, 0) for row in x]
    gates = []

    def gate(left, right, sign=1):
        a, da = signals[left]
        b, db = signals[right]
        signals.append((tuple((u+sign*v) % p for u, v in zip(a, b)), 1+max(da, db)))
        gates.append(len(signals)-1)
        return gates[-1]

    z = [None]*n
    for start in (0, 3, 6):
        t1 = gate((start+1) % n, (start+2) % n, -1)
        t2 = gate((start+2) % n, (start+3) % n)
        z[start] = gate(start, t1)
        z[start+1] = gate(t1, t2, -1)
        z[start+2] = gate(t2, (start+4) % n, -1)
    assert len(gates) == 15
    y = [gate(z[i], z[(i+2) % n]) for i in range(n)]
    a = [0]*n
    a[0], a[1], a[3], a[4] = 1, 1, 1, -1
    matrix = circulant(a, p)
    assert [signals[i][0] for i in y] == [tuple(row) for row in matrix]
    assert len(gates) == 24 and max(signals[i][1] for i in y) == 3
    assert inverse(matrix, p) is not None and brute_branch_five(matrix, p)
    assert rectangles(matrix, p, 2, 2) == []
    return dict(n=n, p=p, C_rect=27, C_g_upper_bound=24, depth=3)


def main():
    counts = Counter()
    for p, stop in ((3, 9), (5, 8)):
        for n in range(5, stop):
            for support in combinations(range(1, n), 3):
                for signs in product((1, -1), repeat=3):
                    a = [0]*n
                    a[0] = 1
                    for j, sign in zip(support, signs):
                        a[j] = sign
                    matrix = circulant(a, p)
                    inv = inverse(matrix, p)
                    if inv is None:
                        continue
                    actual = brute_branch_five(matrix, p)
                    details = overlap_test(a)
                    predicted = all(c+max(cp, cm) <= 5 for c, cp, cm in details)
                    predicted &= sum(v != 0 for v in inv[0]) >= 4
                    assert actual == predicted
                    counts['security_criterion_checks'] += 1
                    local = local_test(matrix, p)
                    if local is not None:
                        assert actual == local
                        counts['low_overlap_criterion_checks'] += 1

    for even, orders in ((False, range(9, 36, 2)), (True, range(12, 61, 8))):
        for n in orders:
            a = attaining_factors(n, even)
            assert components(a) == 1
            counts['integer_cover_and_factor_checks'] += 1
            for p in (3, 5, 7, 11):
                assert security(a, p, 5)['passed']
                counts['attaining_matrix_field_checks'] += 1

    for m, even in ((9, False), (11, False), (12, True), (20, True)):
        base = attaining_factors(m, even)
        for ell in (2, 3):
            n = ell*m
            a = [0]*n
            for j, value in enumerate(base):
                a[ell*j] = value
            assert components(a) == ell
            for p in (3, 5):
                assert security(a, p, 5)['passed']
                counts['step_lift_field_checks'] += 1

    report = dict(all_checks_passed=True, counts=dict(counts),
                  ternary_example=ternary_example())
    (RESULTS / 'section42_verification.json').write_text(
        json.dumps(report, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
