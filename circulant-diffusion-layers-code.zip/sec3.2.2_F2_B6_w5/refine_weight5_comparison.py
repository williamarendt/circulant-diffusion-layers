"""Refine comparison bounds and reuse exact component decompositions."""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("3.2.2") / "results"

import argparse
import json
import math
from pathlib import Path

from circrect.algebra import canonical, circulant, security
from circrect.packing import public_rectangle, rectangles
from circrect.storage import output_lock
from circrect.witness import make_witness, verify
from compare_weight5_families import solve_packing, summaries, write_comparison_summary
from search_weight5_small import save_json


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def apply_witness(state, out, support, packing, lower, info):
    n = state["n"]
    key = ",".join(map(str, support))
    record = state["records"][key]
    a = [int(i in support) for i in range(n)]
    witness = make_witness(a, 2, 6, packing, info)
    verify(witness)
    record["cost_lower_bound"] = max(record["cost_lower_bound"], lower)
    if witness["cost"] <= record["cost_upper_bound"]:
        path = out/f"n{n}_{key}_witness.json"
        save_json(path, witness)
        record.update(cost_upper_bound=witness["cost"], solver=info, witness_file=path.name)
    if record["cost_lower_bound"] > record["cost_upper_bound"]:
        raise RuntimeError("Contradictory bounds")


def lifted_packing(witness, n):
    """Lift identical components and transport to the affine representative."""
    m = witness["n"]
    g = n//m
    source = [g*i for i, a in enumerate(witness["generator"]) if a]
    a = [int(i in source) for i in range(n)]
    target = tuple(i for i, _ in canonical(a, 2))
    mapping = next((u, anchor) for u in range(1, n) if math.gcd(u, n) == 1
                   for anchor in source if tuple(sorted(u*(s-anchor)%n for s in source)) == target)
    u, anchor = mapping
    packing = []
    for component in range(g):
        for rect in witness["rectangles"]:
            rows = sorted(u*(component+g*i)%n for i in rect["rows"])
            cols = sorted(u*(component+g*j-anchor)%n for j in rect["cols"])
            packing.append(dict(rows=rows, cols=cols, alpha=[1]*len(rows),
                                beta=[1]*len(cols), gain=rect["gain"]))
    return target, packing


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path(str(RESULTS / 'weight5_family_comparison_20261105')))
    parser.add_argument("--seconds", type=float, default=20)
    parser.add_argument("--orders", default="16,18,20,21,24,27,28,30,32,40,44,52")
    args = parser.parse_args(argv)
    small = Path(str(RESULTS / 'weight5_f2_n_le16_20261105'))
    with output_lock(args.out):
        for n in map(int, args.orders.split(",")):
            state = load(args.out/f"n{n}.json")
            if not state["all_candidates_processed"]:
                raise RuntimeError("Finish the initial candidate enumeration first")
            # Previously completed full enumeration supplies rigorous global bounds.
            if (small/f"n{n:02d}.json").exists():
                known = load(small/f"n{n:02d}.json")["categories"]["unrestricted"]
                if known["status"] == "EXACT":
                    for r in state["records"].values():
                        if r["security"]["passed"]:
                            r["cost_lower_bound"] = max(r["cost_lower_bound"], known["lower_bound"])
                            r["additional_bound_source"] = str(small/f"n{n:02d}.json")
            # Each disconnected circulant is a sum of g identical order n/g blocks.
            for m in range(5, n):
                if n % m:
                    continue
                source_path = small/f"n{m:02d}.json" if m <= 16 else args.out/f"n{m}.json"
                if not source_path.exists():
                    continue
                source = load(source_path)
                result = source["categories"]["unrestricted"]
                feasible = result["status"] not in ("NO_FEASIBLE_MATRIX", "NO_CANDIDATE_BELOW_3N")
                if not feasible:
                    continue
                lower = result["lower_bound"]
                upper = result.get("best_cost", result.get("upper_bound"))
                for record in state["records"].values():
                    if record["security"]["passed"] and record["components"] == n//m:
                        record["cost_lower_bound"] = max(record["cost_lower_bound"], n//m*lower)
                        record["component_bound_source"] = str(source_path)
                if m <= 16:
                    witness = load(small/f"n{m:02d}_unrestricted_witness.json")
                else:
                    bestkey = ",".join(map(str, result["support"]))
                    witness = load(args.out/source["records"][bestkey]["witness_file"])
                support, packing = lifted_packing(witness, n)
                info = dict(backend="component_lift", base_order=m, components=n//m,
                            source=str(source_path), gain_upper_bound=4*n-n//m*lower,
                            gain=4*n-n//m*upper, optimal=lower == upper)
                apply_witness(state, args.out, support, packing, n//m*lower, info)
            # Solve a smaller connected component for remaining disconnected bounds.
            for record in list(state["records"].values()):
                if not record["security"]["passed"] or record["components"] == 1:
                    continue
                current = summaries(n, state["records"])["disconnected"]
                if record["cost_lower_bound"] >= current["upper_bound"]:
                    continue
                g = record["components"]
                m = n//g
                support = [i//g for i in record["support"]]
                a = [int(i in support) for i in range(m)]
                assert security(a, 2, 6)["passed"]
                items = rectangles(circulant(a, 2), 2, 3, 3)
                solved = solve_packing(items, m, args.seconds)
                base = [public_rectangle(items[j]) for j in solved["selected"]]
                packing = [dict(r, rows=[c+g*i for i in r["rows"]],
                                cols=[c+g*j for j in r["cols"]])
                           for c in range(g) for r in base]
                info = {k:v for k,v in solved.items() if k != "selected"}
                info.update(backend="component_scipy_highs", base_order=m, components=g,
                            gain_upper_bound=g*solved["gain_upper_bound"], gain=g*solved["gain"])
                apply_witness(state, args.out, record["support"], packing,
                              4*n-g*solved["gain_upper_bound"], info)
                print(f"component n={n}, {record['support']}: "
                      f"[{record['cost_lower_bound']},{record['cost_upper_bound']}]", flush=True)
            # Only candidates that could improve the connected minimum need refinement.
            for record in sorted(state["records"].values(), key=lambda r:r.get("cost_lower_bound", 10*n)):
                if not record["security"]["passed"] or record["components"] != 1:
                    continue
                current = summaries(n, state["records"])["connected"]
                if record["cost_lower_bound"] >= current["upper_bound"]:
                    continue
                a = [int(i in record["support"]) for i in range(n)]
                items = rectangles(circulant(a, 2), 2, 3, 3)
                prior = load(args.out/record["witness_file"])
                solved = solve_packing(items, n, args.seconds, prior)
                info = {k:v for k,v in solved.items() if k != "selected"}
                packing = [public_rectangle(items[j]) for j in solved["selected"]]
                apply_witness(state, args.out, record["support"], packing,
                              4*n-solved["gain_upper_bound"], info)
                print(f"refine n={n}, {record['support']}: "
                      f"[{record['cost_lower_bound']},{record['cost_upper_bound']}]", flush=True)
                state["categories"] = summaries(n, state["records"])
                save_json(args.out/f"n{n}.json", state)
            state["categories"] = summaries(n, state["records"])
            if all(m <= 16 and load(small/f"n{m:02d}.json")["categories"]["unrestricted"]["status"]
                   == "NO_FEASIBLE_MATRIX" for m in range(5,n) if n % m == 0):
                state["categories"]["disconnected"] = dict(
                    status="NO_FEASIBLE_MATRIX", lower_bound=None, upper_bound=None,
                    reason="every possible smaller component order has no feasible matrix")
            save_json(args.out/f"n{n}.json", state)
            print(f"REFINED n={n}: {state['categories']}", flush=True)
        write_comparison_summary(args.out)


if __name__ == "__main__":
    main()
