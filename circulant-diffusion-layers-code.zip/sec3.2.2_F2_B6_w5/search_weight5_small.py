"""Exhaustive F2 scalar-circulant search at weight 5, B=6, n<=16.

Run with Python containing scipy, or select an existing circrect backend.
Affine-equivalent supports are counted once; connected and disconnected
minima are reported separately. Results are certified only when the
per-candidate MILP bounds prove the global minimum.
"""
from __future__ import annotations

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("3.2.2") / "results"


import argparse
import csv
from itertools import combinations
import json
import math
from pathlib import Path
import time

from circrect.algebra import circulant, components, security
from circrect.packing import (available_backend, greedy, public_rectangle,
                              rectangles, solve)
from circrect.storage import atomic_write_text, output_lock
from circrect.witness import make_witness, verify


def save_json(path, data):
    atomic_write_text(path, json.dumps(data, indent=2, ensure_ascii=False))


def support_orbits(n):
    """Exhaust all 5-subsets modulo translations and multiplication by units.

    Translation lets us enumerate only supports containing 0. Every affine
    map is a row/column permutation and preserves B, components and C_rect.
    full_size counts original labelled supports, not just normalized ones.
    """
    seen = set()
    units = [u for u in range(1, n) if math.gcd(u, n) == 1]
    for tail in combinations(range(1, n), 4):
        support = (0,) + tail
        if support in seen:
            continue
        orbit = {tuple(sorted((u * (v - anchor)) % n for v in support))
                 for u in units for anchor in support}
        seen.update(orbit)
        assert len(orbit) * n % 5 == 0
        yield min(orbit), len(orbit) * n // 5


def exhaustive_branch(matrix):
    """Independent Gray-code check of every nonzero binary input."""
    n = len(matrix)
    columns = [sum(matrix[i][j] << i for i in range(n)) for j in range(n)]
    output, best = 0, n + 1
    for t in range(1, 1 << n):
        output ^= columns[(t & -t).bit_length() - 1]
        input_mask = t ^ (t >> 1)
        best = min(best, input_mask.bit_count() + output.bit_count())
    return best


def solve_scipy(items, n, time_limit):
    """The same position-disjoint rectangle MILP, using bundled HiGHS."""
    import numpy as np
    import scipy
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import csc_matrix

    started = time.monotonic()
    selected = greedy(items)
    gain = sum(items[j]["gain"] for j in selected)
    if not items:
        return dict(selected=[], gain=0, gain_upper_bound=0, optimal=True,
                    status="OPTIMAL", backend="scipy", version=scipy.__version__,
                    seconds=0)
    row_indices, col_indices = [], []
    for j, rect in enumerate(items):
        for r in rect["rows"]:
            for c in rect["cols"]:
                row_indices.append(r * n + c)
                col_indices.append(j)
    matrix = csc_matrix((np.ones(len(row_indices)), (row_indices, col_indices)),
                        shape=(n * n, len(items)))
    options = {"mip_rel_gap": 0.0}
    if time_limit:
        options["time_limit"] = time_limit
    result = milp(-np.array([r["gain"] for r in items], dtype=float),
                  integrality=np.ones(len(items)), bounds=Bounds(0, 1),
                  constraints=LinearConstraint(matrix, -np.inf, 1), options=options)
    if result.x is not None:
        chosen = [j for j, value in enumerate(result.x) if value > 0.5]
        used = 0
        for j in chosen:
            if used & items[j]["mask"]:
                raise RuntimeError("MILP returned overlapping rectangle positions")
            used |= items[j]["mask"]
        value = sum(items[j]["gain"] for j in chosen)
        if value >= gain:
            selected, gain = chosen, value
    dual = getattr(result, "mip_dual_bound", None)
    bound = (max(gain, math.floor(-dual + 1e-6))
             if dual is not None and math.isfinite(dual)
             else sum(r["gain"] for r in items))
    optimal = result.status == 0 or bound == gain
    if result.status == 0:
        if result.x is None or abs(-result.fun - gain) > 1e-5:
            raise RuntimeError("Optimal solver objective disagrees with checked packing")
        bound = gain
    return dict(selected=selected, gain=gain, gain_upper_bound=bound,
                optimal=optimal, status="OPTIMAL" if optimal else str(result.message),
                backend="scipy", version=scipy.__version__,
                seconds=time.monotonic() - started)


def summarize(records, category):
    chosen = [r for r in records if r["security"]["passed"] and
              (category == "unrestricted" or
               (r["components"] == 1) == (category == "connected"))]
    base = dict(feasible_orbits=len(chosen),
                feasible_labelled_supports=sum(r["labelled_supports"] for r in chosen))
    if not chosen:
        return dict(base, status="NO_FEASIBLE_MATRIX", lower_bound=None,
                    best_cost=None, support=None, components=None)
    best = min(chosen, key=lambda r: (r["cost_upper_bound"], r["support"]))
    lower = min(r["cost_lower_bound"] for r in chosen)
    upper = best["cost_upper_bound"]
    return dict(base, status="EXACT" if lower == upper else "INCOMPLETE",
                lower_bound=lower, best_cost=upper, support=best["support"],
                components=best["components"],
                unresolved_orbits=sum(r["cost_lower_bound"] < upper for r in chosen))


def search_order(n, output, backend, env, seconds):
    started = time.monotonic()
    records = []
    witnesses = {}
    for support, orbit_size in support_orbits(n):
        a = [int(i in support) for i in range(n)]
        matrix = circulant(a, 2)
        sec = security(a, 2, 6)
        record = dict(support=list(support), labelled_supports=orbit_size,
                      components=components(a), security=sec)
        if sec.get("full_rank"):
            # Audit BOTH accepted and rejected invertible representatives.
            branch = exhaustive_branch(matrix)
            if (branch == 6) != sec["passed"]:
                raise RuntimeError(f"Branch tests disagree: n={n}, support={support}")
            record["exhaustive_branch"] = branch
        if sec["passed"]:
            items = rectangles(matrix, 2, max_rows=3, max_cols=3)
            solution = (solve_scipy(items, n, seconds) if backend == "scipy" else
                        solve(items, backend, env, time_limit=seconds or None))
            packing = [public_rectangle(items[j]) for j in solution["selected"]]
            solver_info = {k: v for k, v in solution.items() if k != "selected"}
            witness = make_witness(a, 2, 6, packing, solver_info)
            verify(witness)  # Re-evaluate the actual circuit and every coefficient.
            witnesses[support] = witness
            record.update(cost_lower_bound=max((12 * n + 4) // 5,
                                                4 * n - solution["gain_upper_bound"]),
                          cost_upper_bound=witness["cost"], solver=solver_info,
                          rectangle_count=len(items),
                          packing_sizes={f"{r}x{c}": sum(len(x["rows"]) == r and
                                          len(x["cols"]) == c for x in packing)
                                         for r, c in ((2, 2), (2, 3), (3, 2), (3, 3))})
        records.append(record)
        if len(records) % 10 == 0:
            print(f"  n={n}: {len(records)} affine orbits checked", flush=True)
    labelled = sum(r["labelled_supports"] for r in records)
    if labelled != math.comb(n, 5):
        raise RuntimeError(f"Incomplete orbit enumeration: n={n}, count={labelled}")
    categories = {name: summarize(records, name)
                  for name in ("connected", "disconnected", "unrestricted")}
    for name, summary in categories.items():
        if summary["support"] is not None:
            witness = witnesses[tuple(summary["support"])]
            save_json(output / f"n{n:02d}_{name}_witness.json", witness)
    report = dict(format="weight5-small-v1", n=n, field="F2", weight=5,
                  branch=6, model="C_rect", enumeration_complete=True,
                  labelled_supports=labelled, affine_orbits=len(records),
                  branch_audit="all nonzero inputs for every invertible affine representative",
                  backend=backend, seconds=time.monotonic() - started,
                  categories=categories, records=records)
    save_json(output / f"n{n:02d}.json", report)
    return report


def write_summary(output, reports):
    rows = []
    lines = ["# F2 weight 5, branch number 6: exhaustive search", "",
             "Scalar circulants only. Connected and disconnected are disjoint categories.",
             "NO_FEASIBLE_MATRIX means the exhaustive search found no matrix in that category.",
             "EXACT requires matching global lower and upper bounds; a time limit alone does not certify a minimum.",
             "", "| n | connected | disconnected | unrestricted | universal bound |",
             "|---:|---:|---:|---:|---:|"]
    for report in reports:
        cells = []
        for name, result in report["categories"].items():
            rows.append(dict(n=report["n"], category=name, **result))
            if result["status"] == "NO_FEASIBLE_MATRIX":
                cells.append("none")
            elif result["status"] == "EXACT":
                cells.append(str(result["best_cost"]))
            else:
                cells.append(f"[{result['lower_bound']}, {result['best_cost']}]")
        lines.append(f"| {report['n']} | {' | '.join(cells)} | {(12*report['n']+4)//5} |")
    save_json(output / "summary.json", rows)
    atomic_write_text(output / "summary.md", "\n".join(lines) + "\n")
    with (output / "summary.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        fields = list(dict.fromkeys(key for row in rows for key in row))
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--min-n", type=int, default=1)
    parser.add_argument("--max-n", type=int, default=16)
    parser.add_argument("--out", type=Path, default=Path(str(RESULTS / 'weight5_f2_n_le16_20261105')))
    parser.add_argument("--backend", choices=("scipy", "gurobi", "cpsat", "brute"), default="scipy")
    parser.add_argument("--per-matrix", type=float, default=30,
                        help="seconds per packing solve; 0 means no time limit")
    parser.add_argument("--resume", action="store_true", help="reuse completed exact order reports")
    args = parser.parse_args(argv)
    if not 1 <= args.min_n <= args.max_n <= 16 or args.per_matrix < 0:
        parser.error("Require 1 <= min-n <= max-n <= 16 and a nonnegative time limit")
    args.out.mkdir(parents=True, exist_ok=True)
    backend, env = args.backend, None
    if backend != "scipy":
        backend, env, _ = available_backend(backend)
    reports = []
    try:
        with output_lock(args.out):
            for n in range(args.min_n, args.max_n + 1):
                path = args.out / f"n{n:02d}.json"
                if path.exists() and not args.resume:
                    raise FileExistsError(f"{path} exists; use --resume or another --out")
                report = json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
                if report is not None and report.get("format") != "weight5-small-v1":
                    raise ValueError("Unrecognized saved report")
                if report is None or any(r["status"] == "INCOMPLETE" for r in report["categories"].values()):
                    report = search_order(n, args.out, backend, env, args.per_matrix)
                reports.append(report)
                write_summary(args.out, reports)
                print(f"n={n}: " + "; ".join(
                    f"{name}={value['best_cost']} ({value['status']})"
                    for name, value in report["categories"].items()), flush=True)
    finally:
        if env is not None:
            env.dispose()
    return reports


if __name__ == "__main__":
    main()
