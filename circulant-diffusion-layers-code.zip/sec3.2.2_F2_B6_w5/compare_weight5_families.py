"""Compare explicit families with small/moderate-order global C_rect minima.

Complete structural reduction: a feasible matrix costing <3n must have
an overlap of three. Its five-point support, up to translation, is one
of the three normal forms proved in Section 3.2.3. Other supports cost
at least 3n. Thus this is a global search below 3n, not a family sample.
"""
from __future__ import annotations

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("3.2.2") / "results"


import argparse
import csv
import io
from itertools import combinations
import json
import math
from pathlib import Path
import time

from circrect.algebra import circulant, components, security
from circrect.packing import greedy, public_rectangle, rectangles
from circrect.storage import output_lock
from circrect.witness import make_witness, verify
from search_weight5_small import save_json


def reduced_supports(n):
    raw = set()
    for d in range(1, n):
        for e in range(n):
            for support in ({0, d, 2*d % n, 3*d % n, e},
                            {0, d, 2*d % n, e, (e+d) % n}):
                if len(support) == 5:
                    raw.add(tuple(sorted(support)))
    if n % 3 == 0:
        for d, e in combinations(range(1, n), 2):
            support = {0, n//3, 2*n//3, d, e}
            if len(support) == 5:
                raw.add(tuple(sorted(support)))
    units = [u for u in range(1, n) if math.gcd(u, n) == 1]
    seen, result = set(), []
    for support in sorted(raw):
        if support in seen:
            continue
        orbit = {tuple(sorted(u*(v-anchor) % n for v in support))
                 for u in units for anchor in support}
        seen.update(orbit)
        result.append(min(orbit))
    return sorted(result)


def solve_packing(items, n, seconds, prior=None):
    """Position packing with valid rank-budget and incidence cuts."""
    import numpy as np
    import scipy
    from scipy.optimize import Bounds, LinearConstraint, milp
    from scipy.sparse import csc_matrix

    start = time.monotonic()
    selected = greedy(items)
    if prior:
        lookup = {(tuple(r["rows"]), tuple(r["cols"])): j for j, r in enumerate(items)}
        warm = [lookup[(tuple(r["rows"]), tuple(r["cols"]))] for r in prior["rectangles"]]
        if sum(items[j]["gain"] for j in warm) > sum(items[j]["gain"] for j in selected):
            selected = warm
    gain = sum(items[j]["gain"] for j in selected)
    rr, cc, vv = [], [], []
    for j, r in enumerate(items):
        for row in r["rows"]:
            for col in r["cols"]:
                rr.append(row*n+col); cc.append(j); vv.append(1)
            rr.append(n*n+row); cc.append(j); vv.append(1)
        for col in r["cols"]:
            rr.append(n*n+n+col); cc.append(j); vv.append(1)
        rr.append(n*n+2*n); cc.append(j)
        vv.append(len(r["rows"])*len(r["cols"])-1)
    if not items:
        return dict(selected=[], gain=0, gain_upper_bound=0, optimal=True,
                    status="OPTIMAL", backend="scipy_highs", seconds=0)
    # The checked incumbent is feasible, so restricting gain to be at least
    # its value cannot remove an optimum.
    for j, r in enumerate(items):
        rr.append(n*n+2*n+1); cc.append(j); vv.append(r["gain"])
    upper = [1]*(n*n) + [2]*(2*n) + [4*n, np.inf]
    lower = [-np.inf]*(n*n+2*n+1) + [gain]
    if gain > n:
        # Gain > n requires a rectangle larger than 2x2. Simultaneous cyclic
        # translation and (I,J)->(-J,-I) both preserve this binary circulant.
        # Any optimum can be transformed to include a chosen representative
        # of one of the larger-rectangle orbits. This is a WLOG symmetry cut.
        representatives = {}
        for j, r in enumerate(items):
            if r["gain"] <= 1:
                continue
            shapes = [(r["rows"], r["cols"]),
                      ([-c % n for c in r["cols"]], [-i % n for i in r["rows"]])]
            orbit = min((tuple(sorted((i+t)%n for i in rows)),
                         tuple(sorted((c+t)%n for c in cols)))
                        for rows, cols in shapes for t in range(n))
            representatives.setdefault(orbit, j)
        for j in representatives.values():
            rr.append(n*n+2*n+2); cc.append(j); vv.append(1)
        lower.append(1); upper.append(np.inf)
    matrix = csc_matrix((np.array(vv, float), (rr, cc)), shape=(len(upper), len(items)))
    result = milp(-np.array([r["gain"] for r in items], float),
                  integrality=np.ones(len(items)), bounds=Bounds(0, 1),
                  constraints=LinearConstraint(matrix, lower, upper),
                  options={"mip_rel_gap": 0., "time_limit": seconds})
    if result.x is not None:
        chosen = [j for j, value in enumerate(result.x) if value > .5]
        used = 0
        for j in chosen:
            if used & items[j]["mask"]:
                raise RuntimeError("Overlapping rectangle solution")
            used |= items[j]["mask"]
        value = sum(items[j]["gain"] for j in chosen)
        if value >= gain:
            gain, selected = value, chosen
    dual = getattr(result, "mip_dual_bound", None)
    bound = max(gain, math.floor(-dual+1e-6)) if dual is not None and math.isfinite(dual) else 8*n//5
    if result.status == 0:
        if result.x is None or abs(-result.fun-gain) > 1e-5:
            raise RuntimeError("MILP objective disagrees with packing")
        bound = gain
    if prior:
        bound = min(bound, prior["solver"].get("gain_upper_bound", bound))
    if bound < gain:
        raise RuntimeError("Stored bound contradicts verified packing")
    return dict(selected=selected, gain=gain, gain_upper_bound=bound,
                optimal=bound == gain, status="OPTIMAL" if bound == gain else str(result.message),
                backend="scipy_highs", version=scipy.__version__, seconds=time.monotonic()-start)


def family_cost(n):
    return {"core_8n_over_3": 8*n//3 if n%3 == 0 and n >= 15 else None,
            "even_11n_over_4": 11*n//4 if n%4 == 0 and n%3 and n >= 16 else None}


def write_comparison_summary(out):
    reports = [json.loads(p.read_text(encoding="utf-8")) for p in out.glob("n[0-9]*.json")
               if p.stem[1:].isdigit()]
    reports.sort(key=lambda r:r["n"])
    save_json(out/"summary.json", [{k:v for k,v in r.items() if k != "records"} for r in reports])
    rows = []
    lines = ["# Weight-five family comparison", "",
             "Complete normal-form search below 3n; all other matrices cost at least 3n.",
             "EXACT means global lower and upper bounds coincide, not that each candidate's cost is exact.",
             "", "| n | 8n/3 family | 11n/4 family | connected minimum | disconnected minimum | unrestricted minimum |",
             "|---:|---:|---:|---:|---:|---:|"]
    for report in reports:
        if not report["all_candidates_processed"]:
            raise RuntimeError("Cannot publish a global comparison with unprocessed candidates")
        row = dict(n=report["n"], **report["families"])
        cells = []
        for kind, result in report["categories"].items():
            row.update({f"{kind}_{k}":v for k,v in result.items()})
            if result["status"] == "NO_FEASIBLE_MATRIX":
                cells.append("none")
            elif result["status"] == "EXACT":
                cells.append(str(result["upper_bound"]))
            else:
                cells.append(f"[{result['lower_bound']}, {result['upper_bound']}]")
            if result.get("support"):
                key = ",".join(map(str, result["support"]))
                source = out/report["records"][key]["witness_file"]
                save_json(out/f"best_n{report['n']}_{kind}.json",
                          json.loads(source.read_text(encoding="utf-8")))
        family_cells = [str(v) if v is not None else "--" for v in report["families"].values()]
        lines.append(f"| {report['n']} | {' | '.join(family_cells+cells)} |")
        rows.append(row)
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=list(dict.fromkeys(k for r in rows for k in r)))
    writer.writeheader(); writer.writerows(rows)
    from circrect.storage import atomic_write_text
    atomic_write_text(out/"summary.csv", stream.getvalue(), encoding="utf-8-sig")
    atomic_write_text(out/"summary.md", "\n".join(lines)+"\n")


def summaries(n, records):
    result = {}
    for kind in ("connected", "disconnected", "unrestricted"):
        candidates = [r for r in records.values() if r["security"]["passed"] and
                      (kind == "unrestricted" or (r["components"] == 1) == (kind == "connected"))]
        if not candidates:
            result[kind] = dict(status="NO_CANDIDATE_BELOW_3N", lower_bound=3*n, upper_bound=None)
            continue
        best = min(candidates, key=lambda r: (r["cost_upper_bound"], r["support"]))
        lower = min([3*n] + [r["cost_lower_bound"] for r in candidates])
        upper = best["cost_upper_bound"]
        result[kind] = dict(status="EXACT" if lower == upper else "INCOMPLETE",
                            lower_bound=lower, upper_bound=upper, support=best["support"],
                            components=best["components"], feasible_candidates=len(candidates),
                            unresolved=sum(r["cost_lower_bound"] < upper for r in candidates))
    return result


def run_order(n, out, seconds, resume):
    start = time.monotonic()
    path = out/f"n{n}.json"
    if path.exists() and not resume:
        raise FileExistsError(f"{path}: use --resume or another output directory")
    state = json.loads(path.read_text()) if path.exists() else dict(
        format="weight5-family-comparison-v1", n=n, records={}, seconds=0)
    if state.get("format") != "weight5-family-comparison-v1" or state["n"] != n:
        raise ValueError("Saved scope differs")
    supports = reduced_supports(n)
    state.update(enumeration_complete=True, reduced_candidates=len(supports), families=family_cost(n))
    records = state["records"]
    seeds = [{0,1,2,4,n-2}, {0,1,2,3,n//2}]
    supports.sort(key=lambda s: (not any(set(s)==x for x in seeds), s))
    for count, support in enumerate(supports, 1):
        key = ",".join(map(str, support))
        prior = records.get(key)
        if prior and (not prior["security"]["passed"] or prior["cost_lower_bound"] == prior["cost_upper_bound"]):
            continue
        if prior:
            current = summaries(n, records)
            kind = "connected" if prior["components"] == 1 else "disconnected"
            if prior["cost_lower_bound"] >= current[kind]["upper_bound"]:
                continue
        a = [int(i in support) for i in range(n)]
        sec = security(a, 2, 6)
        record = dict(support=list(support), components=components(a), security=sec)
        if sec["passed"]:
            items = rectangles(circulant(a, 2), 2, 3, 3)
            witness_path = out/f"n{n}_{key}_witness.json"
            warm = json.loads(witness_path.read_text()) if witness_path.exists() else None
            # Reuse an existing independently checked witness when its generator matches.
            if warm is None:
                old = Path(f"{RESULTS}/gurobi/f2_p2_B6_n{n}_k5_connected/best_witness.json")
                if old.exists():
                    trial = json.loads(old.read_text())
                    if trial["generator"] == a:
                        verify(trial)
                        warm = trial
            solved = solve_packing(items, n, seconds, warm)
            info = {k: v for k, v in solved.items() if k != "selected"}
            packing = [public_rectangle(items[j]) for j in solved["selected"]]
            witness = make_witness(a, 2, 6, packing, info)
            verify(witness)
            save_json(witness_path, witness)
            low = max((12*n+4)//5, 4*n-solved["gain_upper_bound"])
            if prior:
                low = max(low, prior["cost_lower_bound"])
            record.update(cost_lower_bound=low, cost_upper_bound=witness["cost"],
                          solver=info, rectangle_count=len(items), witness_file=witness_path.name)
        records[key] = record
        state["categories"] = summaries(n, records)
        state["processed_candidates"] = len(records)
        state["seconds_current_run"] = time.monotonic()-start
        # Do not call an unprocessed candidate set a certified global minimum.
        state["all_candidates_processed"] = len(records) == len(supports)
        save_json(path, state)
        if sec["passed"]:
            print(f"n={n} [{count}/{len(supports)}] {support}: "
                  f"C_rect=[{record['cost_lower_bound']},{record['cost_upper_bound']}]", flush=True)
    state["categories"] = summaries(n, records)
    state["all_candidates_processed"] = len(records) == len(supports)
    state["seconds"] += time.monotonic()-start
    save_json(path, state)
    print(f"FINISHED n={n}: {state['categories']}", flush=True)
    return state


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--orders", default="18,20,21,24,27,28,30,32,40,44,52")
    parser.add_argument("--per-matrix", type=float, default=2.)
    parser.add_argument("--out", type=Path, default=Path(str(RESULTS / 'weight5_family_comparison_20261105')))
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args(argv)
    if args.per_matrix <= 0:
        parser.error("per-matrix must be positive")
    args.out.mkdir(parents=True, exist_ok=True)
    with output_lock(args.out):
        results = []
        for n in map(int, args.orders.split(",")):
            if n < 10:
                parser.error("orders must be at least 10")
            results.append(run_order(n, args.out, args.per_matrix, args.resume))
            write_comparison_summary(args.out)
    return results


if __name__ == "__main__":
    main()
