# Section 3.2.2: Binary Field, B=6, w=5

| Code | Purpose | Saved results |
|---|---|---|
| `search_weight5_small.py`, `weight5_small_search.ipynb` | Complete search for n=1–16; recorded runs used SciPy/HiGHS, and the script also supports Gurobi | `results/weight5_f2_n_le16_20261105/` |
| `compare_weight5_families.py`, `refine_weight5_comparison.py` | Supplementary searches using structural reductions and component lower bounds; recorded runs used SciPy/HiGHS | `results/weight5_family_comparison_20261105/` |
| `verify_section32.py` | Checks supports, overlaps, and constructions in Section 3.2, and audits the original n=64 checkpoint | `results/section32_verification.json` |
| `run_gurobi.py` | Entry point to the original shared Gurobi search | Original records in `results/gurobi/`; new runs default to `results/repeat_gurobi/` |

This directory also includes verification code for Section 3.2.1. The `auxiliary/`
directory contains historical supplementary work: discovery and verification of
core certificates, generation of proof tables, and depth-three circuit searches.
Results are in `results/core_optimality_investigation_20261105/` and
`results/weight5_depth3_20261105/`. Here `linprog` solves continuous LPs, while
`search_weight5_depth3.py` solves a MILP for restricted general circuits, a task
distinct from the rectangle-packing optimization reported in the main tables.

Example: `python search_weight5_small.py --min-n 10 --max-n 10 --backend scipy --out results/repeat_scipy`.
Saved batches include additional orders not listed in the paper. Their original
status is retained; no conclusions are extrapolated to other parameter values.
