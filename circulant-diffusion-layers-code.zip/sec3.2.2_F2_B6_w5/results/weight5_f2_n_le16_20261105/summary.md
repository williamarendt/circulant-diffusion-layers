# F2 weight 5, branch number 6: exhaustive search

Scalar circulants only. Connected and disconnected are disjoint categories.
NO_FEASIBLE_MATRIX means the exhaustive search found no matrix in that category.
EXACT requires matching global lower and upper bounds; a time limit alone does not certify a minimum.

| n | connected | disconnected | unrestricted | universal bound |
|---:|---:|---:|---:|---:|
| 1 | none | none | none | 3 |
| 2 | none | none | none | 5 |
| 3 | none | none | none | 8 |
| 4 | none | none | none | 10 |
| 5 | none | none | none | 12 |
| 6 | none | none | none | 15 |
| 7 | none | none | none | 17 |
| 8 | none | none | none | 20 |
| 9 | none | none | none | 22 |
| 10 | 27 | none | 27 | 24 |
| 11 | 30 | none | 30 | 27 |
| 12 | 31 | none | 31 | 29 |
| 13 | 35 | none | 35 | 32 |
| 14 | 38 | none | 38 | 34 |
| 15 | 40 | none | 40 | 36 |
| 16 | 44 | none | 44 | 39 |
