# Small-order weight-five search (2026-11-05)

Scope: scalar circulants over F2, exactly five nonzero entries per row,
invertible, differential and linear branch numbers exactly six.
`connected` and `disconnected` are disjoint classes; `unrestricted` is
their union. The objective is the existing project's position-disjoint
rectangle-reuse model C_rect, not unrestricted XOR circuit complexity.

The search completed at all orders 1 through 16. There are 12,376 labelled
five-element supports in total, grouped into 169 affine equivalence classes.
Translation and multiplication of indices by a unit preserve this scope
and the objective. Each order's sum of affine-orbit sizes was checked
against binomial(n,5).

All 135 invertible representatives were independently checked by evaluating
every nonzero binary input using a Gray-code traversal, including those
rejected by the existing weight-five branch-number criterion. Both tests
agreed in every case. For scalar circulants the transpose is obtained by
reversing row and column indices, so the linear branch number agrees too.
The remaining 96 feasible representatives were all solved to optimality
by SciPy 1.16.2 / HiGHS, without any time-limited unresolved instances.
Every returned packing and its actual XOR circuit were checked using
`circrect.witness.verify`. The results are solver-certified MILP optima;
no claim of a separately checked formal lower-bound proof is made.

Results: no feasible matrix at orders 1 through 9. Connected minima at
orders 10 through 16 are respectively 27,30,31,35,38,40,44. There are no
feasible disconnected matrices at any of these orders. None reaches
ceil(12n/5). One minimum-cost representative and its full rectangle
packing/circuit are saved for each feasible order.

Files:

- `summary.md`, `summary.csv`, `summary.json`: minima by order and class.
- `nXX.json`: every affine representative, feasibility, brute-force branch
  audit, packing optimum and solver bounds.
- `nXX_connected_witness.json`, `nXX_unrestricted_witness.json`: best matrices,
  selected rectangles, complete XOR circuits and solver metadata.

Run from the project root using the Python installation with SciPy:

```powershell
& 'C:\Users\dell\AppData\Local\Programs\Python\Python313\python.exe' search_weight5_small.py --resume
```

For a fresh independent run, choose a new directory:

```powershell
& 'C:\Users\dell\AppData\Local\Programs\Python\Python313\python.exe' search_weight5_small.py --out runs/weight5_small_repeat
```

Or open `weight5_small_search.ipynb` at the project root. The notebook
imports the same script; by default it loads the completed results.
`--per-matrix 30` is the default solve time limit; `0` removes this limit.
If a solve times out, its feasible cost and rigorous solver bound are kept
separate, and the global status is EXACT only when the aggregate bounds
coincide. `--resume` skips completed exact orders and re-solves an incomplete
order. Progress is saved after each completed order.

No manuscript sources or PDF were changed for this experiment.
