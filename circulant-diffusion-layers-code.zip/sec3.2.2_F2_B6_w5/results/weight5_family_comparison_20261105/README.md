# Comparing the 8n/3 and 11n/4 families (2026-11-05)

See `summary.md` or `summary.csv`. All reported global minima are EXACT;
there are no unresolved global minima in this experiment. Individual
candidates that cannot improve the minimum need not have their own exact
cost determined. Connected and disconnected classes are reported separately.

## Results

- 8n/3: at n=18,21,24,27,30 the connected minima are 48,56,64,72,80,
  respectively, matching the family. The earlier exhaustive n=15 minimum
  is 40 and also matches. At n=24 the unrestricted minimum is 62, obtained
  from two copies of the twelve-order optimum. Thus connected optimality
  and unrestricted optimality are different questions.
- 11n/4: connected minima at n=16,20,28,32,40,44,52 are
  44,55,75,86,110,118,140. The family costs are
  44,55,77,88,110,121,143, respectively. It matches at 16,20,40 and fails
  to match at 28,32,44,52 even when connectivity is required.
- At n=20 and 40 the unrestricted minima 54 and 108 are smaller still,
  using two and four copies of a ten-order optimum.
- At n=44 and 52 the disconnected minima equal the connected minima,
  namely 118 and 140. At n=28 and 32 the disconnected minima are 76 and 88.
- No feasible disconnected matrices exist at the tested orders 16,18,21,27,
  because every possible component order was already proved infeasible.

The n=12 cost 31 is outside the core-family theorem's hypothesis n>=15.
It does not contradict the exact cost theorem for connected core matrices.
Matching at finitely many orders does not prove optimality for an infinite
family. No manuscript changes were made for this experiment.

## Search coverage and certificates

The search reuses the exact weight-five branch criterion, component test,
complete rectangle enumeration and circuit verification from `circrect`.
It uses the three normal forms proved in manuscript Section 3.2.3:

1. {0,d,2d,3d,e};
2. {0,d,2d,e,e+d};
3. {0,n/3,2n/3,d,e} when 3 divides n.

Every feasible matrix with C_rect<3n has an overlap of three, hence belongs
to one of these forms up to translation. All other matrices have cost at
least 3n. These forms were fully enumerated and reduced by affine support
equivalence. All found global minima are below 3n, so the reduction is
complete for deciding them, rather than merely sampling constructions.
As a separate check, every class with cost below 3n from the full n<=16
enumeration was found in this reduction (32 classes at orders 10--16).

There are 775 reduced classes over the twelve tested orders; 562 pass
the invertibility/branch tests. The integer program maximizes rectangle
savings with disjoint matrix positions. It also adds valid cuts: at most
two rectangle incidences per row and column, and total rank-budget use
at most 4n. It runs using SciPy/HiGHS, without Gurobi license access.

For refinement, a verified incumbent supplies a gain lower bound. When
its gain exceeds n, some selected rectangle must be larger than 2x2.
Simultaneous row/column translation and (I,J)->(-J,-I) preserve the
circulant. Up to these symmetries an optimum may therefore include one
chosen representative of a larger-rectangle orbit. This WLOG symmetry
constraint reduces duplicate branching without changing the optimum.

Disconnected matrices split into identical smaller circulants. Their costs
are additive over components, because no rectangle can cross components.
Previously certified small-order minima supply component lower bounds and
lifted witnesses; several remaining component problems were solved directly.
Every saved best packing was converted into a complete XOR circuit and
checked by `circrect.witness.verify`. The final 32 class-best witness files
were verified again. Bounds are solver-certified MILP results, not a claim
of independently machine-checked formal lower-bound certificates.

## Files and running

- `nNN.json`: all reduced candidate records, bounds and security tests.
- `nNN_..._witness.json`: candidate packings and complete XOR circuits.
- `best_nNN_connected.json`, `best_nNN_disconnected.json`,
  `best_nNN_unrestricted.json`: convenient class-best witnesses.
- `summary.json`, `summary.csv`, `summary.md`: final aggregate results.

From the project root, using the Python installation with SciPy:

```powershell
& 'C:\Users\dell\AppData\Local\Programs\Python\Python313\python.exe' compare_weight5_families.py --orders 16,18,20,21,24,27,28,30,32,40,44,52 --per-matrix 1 --resume
& 'C:\Users\dell\AppData\Local\Programs\Python\Python313\python.exe' refine_weight5_comparison.py --seconds 20
```

Use a new `--out` directory in both commands for a fresh run. The first
pass uses short per-candidate limits and may report intervals. The second
pass propagates exact component results and refines only candidates that
can still improve a class minimum. `summary.md` explicitly distinguishes
intervals from exact minima. The original small-order results under
`runs/weight5_f2_n_le16_20261105` are retained and reused as certified inputs.
