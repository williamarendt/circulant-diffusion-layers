# Weight-five family comparison

Complete normal-form search below 3n; all other matrices cost at least 3n.
EXACT means global lower and upper bounds coincide, not that each candidate's cost is exact.

| n | 8n/3 family | 11n/4 family | connected minimum | disconnected minimum | unrestricted minimum |
|---:|---:|---:|---:|---:|---:|
| 16 | -- | 44 | 44 | none | 44 |
| 18 | 48 | -- | 48 | none | 48 |
| 20 | -- | 55 | 55 | 54 | 54 |
| 21 | 56 | -- | 56 | none | 56 |
| 24 | 64 | -- | 64 | 62 | 62 |
| 27 | 72 | -- | 72 | none | 72 |
| 28 | -- | 77 | 75 | 76 | 75 |
| 30 | 80 | -- | 80 | 80 | 80 |
| 32 | -- | 88 | 86 | 88 | 86 |
| 40 | -- | 110 | 110 | 108 | 108 |
| 44 | -- | 121 | 118 | 118 | 118 |
| 52 | -- | 143 | 140 | 140 | 140 |
