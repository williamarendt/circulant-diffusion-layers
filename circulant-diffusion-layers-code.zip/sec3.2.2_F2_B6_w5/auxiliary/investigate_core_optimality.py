"""Explore exact rational, translation-invariant packing dual certificates.

This is evidence and certificate discovery, not an all-orders proof.
"""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("3.2.2") / "results"

from fractions import Fraction
import json
from pathlib import Path

from scipy.optimize import linprog
from circrect.algebra import circulant
from circrect.packing import rectangles
from search_weight5_small import save_json


def offset_dual(n, support):
    support = tuple(sorted(support))
    position = {v:i for i,v in enumerate(support)}
    items = rectangles(circulant([int(i in support) for i in range(n)],2),2,3,3)
    constraints = set()
    for rect in items:
        counts = [0]*5
        for i in rect["rows"]:
            for j in rect["cols"]:
                counts[position[(j-i)%n]] += 1
        constraints.add((tuple(counts), rect["gain"]))
    constraints = sorted(constraints)
    if not constraints:
        weights = [Fraction(0)]*5
    else:
        result = linprog([1]*5, A_ub=[[-x for x in c] for c,g in constraints],
                         b_ub=[-g for c,g in constraints], bounds=(0,None), method="highs")
        if not result.success:
            raise RuntimeError(result.message)
        weights = [Fraction(float(x)).limit_denominator(1000000) for x in result.x]
    if not all(sum(w*c for w,c in zip(weights, counts)) >= gain for counts,gain in constraints):
        raise RuntimeError("Rational reconstruction does not satisfy the dual")
    return dict(n=n, support=list(support), weights=list(map(str,weights)),
                weight_sum=str(sum(weights)),
                proves_8n_over_3=sum(weights)<=Fraction(4,3),
                constraint_signature=[[list(c),g] for c,g in constraints])


def main():
    root = Path(str(RESULTS / 'weight5_family_comparison_20261105'))
    output = Path(str(RESULTS / 'core_optimality_investigation_20261105'))
    output.mkdir(parents=True, exist_ok=True)
    results=[]
    for path in sorted(root.glob("n[0-9]*.json")):
        if not path.stem[1:].isdigit():
            continue
        state = json.loads(path.read_text())
        for record in state["records"].values():
            if not record["security"]["passed"] or record["components"]!=1:
                continue
            n, support = state["n"], record["support"]
            core = n%3 == 0 and any({(i+j*n//3)%n for j in range(3)}<=set(support) for i in support)
            if core:
                continue
            result = offset_dual(n,support)
            results.append(result)
            if not result["proves_8n_over_3"]:
                print("EXCEPTION",n,support,result["weight_sum"],result["weights"], flush=True)
    save_json(output/"offset_dual_certificates.json",results)
    print("no-core connected matrices checked",len(results),"exceptions",
          sum(not r["proves_8n_over_3"] for r in results),flush=True)
    return results


if __name__ == "__main__":
    main()
