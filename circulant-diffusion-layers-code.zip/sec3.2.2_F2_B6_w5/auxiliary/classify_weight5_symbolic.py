"""Exact finite classification of difference collisions for n>12.

For each normal form, differences are vectors in Z^2 evaluated at (d,e).
Two linearly independent collision relations force n to divide their
determinant when gcd(n,d,e)=1. The largest possible determinant is 12.
Thus at connected orders n>12 all additional collisions have rank <=1.
This script enumerates every such rank-one collision pattern, reconstructs
and checks rational dual weights, and identifies exceptional supports.
"""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("3.2.2") / "results"

from fractions import Fraction
from itertools import combinations
import math
from pathlib import Path

from search_weight5_small import save_json


TEMPLATES = {
    "four_plus_one": [(0,0),(1,0),(2,0),(3,0),(0,1)],
    "three_plus_two": [(0,0),(1,0),(2,0),(0,1),(1,1)],
}


def sub(a,b):
    return a[0]-b[0],a[1]-b[1]


def add(a,b):
    return a[0]+b[0],a[1]+b[1]


def scale(k,a):
    return k*a[0],k*a[1]


def same(a,b,p=None,h=1):
    v=sub(a,b)
    if p is None:
        return v==(0,0)
    q=scale(h,p)
    if q[0]:
        return v[0]%q[0]==0 and v[1]==v[0]//q[0]*q[1]
    return v[0]==0 and v[1]%q[1]==0


def constraints(points,p=None,h=1):
    if any(same(a,b,p,h) for a,b in combinations(points,2)):
        return None,"repeated_support_position"
    groups=[]
    for i in range(5):
        for j in range(5):
            if i==j:
                continue
            vector=sub(points[j],points[i])
            group=next((g for g in groups if same(vector,g[0],p,h)),None)
            if group is None:
                group=[vector,[]]
                groups.append(group)
            group[1].append((i,j))
    if any(len(g[1])>3 for g in groups):
        return None,"overlap_above_three"
    for vector,edges in groups:
        if len(edges)==3 and len({i for i,j in edges})==3 and len({j for i,j in edges})==3:
            if {i for i,j in edges}=={j for i,j in edges}:
                return None,"order_three_core"
    result=set()
    for vector,edges in groups:
        for size in range(2,len(edges)+1):
            for selected in combinations(edges,size):
                counts=[0]*5
                for i,j in selected:
                    counts[i]+=1;counts[j]+=1
                result.add((tuple(counts),size-1))
    return sorted(result),None


def centered_progression(points,p,h):
    for anchor in points:
        for a,b in combinations(points,2):
            for step in (sub(a,b),sub(b,a)):
                target=[add(anchor,scale(k,step)) for k in (0,2,3,4,6)]
                if all(any(same(t,s,p,h) for s in points) for t in target):
                    if all(not same(a,b,p,h) for a,b in combinations(target,2)):
                        return dict(anchor=list(anchor),step=list(step))
    return None


def dual(cons):
    from scipy.optimize import linprog
    solved=linprog([1]*5,A_ub=[[-c for c in counts] for counts,gain in cons],
                   b_ub=[-gain for counts,gain in cons],bounds=(0,None),method="highs")
    assert solved.success
    weights=[Fraction(float(x)).limit_denominator(10000) for x in solved.x]
    assert all(sum(w*c for w,c in zip(weights,counts))>=gain for counts,gain in cons)
    return weights


def main():
    results=[]
    for name,points in TEMPLATES.items():
        vectors={sub(a,b) for a in points for b in points}
        relations={sub(a,b) for a in vectors for b in vectors}
        detmax=max(abs(a*d-b*c) for a,b in relations for c,d in relations)
        assert detmax==12
        cases={(None,1)}
        for a,b in relations-{(0,0)}:
            g=math.gcd(a,b)
            p=(a//g,b//g)
            if p[0]<0 or p[0]==0 and p[1]<0:
                p=scale(-1,p)
            for h in range(1,g+1):
                if g%h==0:
                    cases.add((p,h))
        for p,h in sorted(cases,key=str):
            cons,excluded=constraints(points,p,h)
            record=dict(template=name,relation_direction=p,order=h,determinant_bound=detmax)
            if excluded:
                record["excluded"]=excluded
            else:
                weights=dual(cons)
                record.update(weights=list(map(str,weights)),weight_sum=str(sum(weights)),
                              constraints=[[list(c),g] for c,g in cons])
                if sum(weights)>Fraction(4,3):
                    record["centered_progression"]=centered_progression(points,p,h)
                    print("EXCEPTION",name,p,h,record["weight_sum"],record["centered_progression"],flush=True)
                else:
                    print("CERTIFICATE",name,p,h,record["weights"],record["weight_sum"],flush=True)
            results.append(record)
    output=Path(str(RESULTS / 'core_optimality_investigation_20261105'))
    output.mkdir(parents=True,exist_ok=True)
    save_json(output/"symbolic_collision_classification.json",results)
    print("total",len(results),"valid",sum("weights" in r for r in results),
          "exceptions",sum("centered_progression" in r for r in results),flush=True)
    return results


if __name__=="__main__":
    main()
