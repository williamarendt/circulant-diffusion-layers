"""Find depth-three circuits with nested pair/triple sharing.

This searches a cancellation-free subclass of general XOR circuits, which
is sufficient to disprove a claimed depth >=4 lower bound if a witness
beats the independently known C_rect of the same matrix.
"""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("3.2.2") / "results"

from itertools import combinations
import json
from pathlib import Path

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import csc_matrix

from circrect.algebra import circulant, security
from search_weight5_small import save_json


def search(n, support, seconds=10):
    matrix=circulant([int(i in support) for i in range(n)],2)
    rows=[tuple(j for j,v in enumerate(row) if v) for row in matrix]
    pairs=sorted({p for row in rows for p in combinations(row,2)})
    triples=sorted({t for row in rows for t in combinations(row,3)})
    variables=[]
    objective=[]
    def var(name,cost=0):
        variables.append(name);objective.append(cost)
        return len(variables)-1
    pv={p:var(("pair",p),1) for p in pairs}
    tv={t:var(("triple",t),1) for t in triples}
    constraints=[]
    def constrain(terms,low=-np.inf,high=np.inf):
        constraints.append((terms,low,high))
    choices={}
    for t in triples:
        z=[]
        for p in combinations(t,2):
            j=var(("triple_choice",t,p))
            choices[t,p]=j;z.append((j,1))
            constrain([(j,1),(pv[p],-1)],high=0)
        constrain(z+[(tv[t],-1)],low=0,high=0)
    output_choices={}
    for i,row in enumerate(rows):
        options=[]
        for t in combinations(row,3):
            p=tuple(j for j in row if j not in t)
            j=var(("output_choice",i,t,p))
            output_choices[i,t]=j;options.append((j,1))
            constrain([(j,1),(tv[t],-1)],high=0)
            constrain([(j,1),(pv[p],-1)],high=0)
        constrain(options,low=1,high=1)
    rr=[];cc=[];vv=[];lower=[];upper=[]
    for r,(terms,low,high) in enumerate(constraints):
        lower.append(low);upper.append(high)
        for j,v in terms:
            rr.append(r);cc.append(j);vv.append(v)
    A=csc_matrix((np.array(vv,float),(rr,cc)),shape=(len(constraints),len(variables)))
    result=milp(np.array(objective,float),integrality=np.ones(len(variables)),
                bounds=Bounds(0,1),constraints=LinearConstraint(A,lower,upper),
                options={"time_limit":seconds,"mip_rel_gap":0.})
    if result.x is None:
        return dict(n=n,support=support,status=str(result.message))
    selected={j for j,value in enumerate(result.x) if value>.5}
    masks=[1<<j for j in range(n)]
    depths=[0]*n
    gates=[]
    def gate(left,right,kind):
        out=len(masks)
        masks.append(masks[left]^masks[right])
        depths.append(1+max(depths[left],depths[right]))
        gates.append(dict(out=out,left=left,right=right,kind=kind,depth=depths[-1]))
        return out
    pair_signals={p:gate(*p,"pair") for p,j in pv.items() if j in selected}
    triple_signals={}
    for t,j in tv.items():
        if j not in selected:
            continue
        p=next(p for p in combinations(t,2) if choices[t,p] in selected)
        other=next(k for k in t if k not in p)
        triple_signals[t]=gate(pair_signals[p],other,"triple")
    outputs=[]
    for i,row in enumerate(rows):
        t=next(t for t in combinations(row,3) if output_choices[i,t] in selected)
        p=tuple(j for j in row if j not in t)
        out=gate(triple_signals[t],pair_signals[p],"output")
        assert masks[out]==sum(1<<j for j in row)
        outputs.append(out)
    cost=len(gates)
    assert cost==n+sum(objective[j] for j in selected)
    assert max(depths[o] for o in outputs)==3
    sec=security([int(i in support) for i in range(n)],2,6)
    assert sec["passed"]
    return dict(n=n,support=list(support),cost=cost,depth=3,
                status=str(result.message),subclass_optimal=result.status==0,
                security=sec,gates=gates,outputs=outputs,
                pair_count=len(pair_signals),triple_count=len(triple_signals))


def main():
    source=Path(str(RESULTS / 'weight5_f2_n_le16_20261105'))
    out=Path(str(RESULTS / 'weight5_depth3_20261105'));out.mkdir(parents=True,exist_ok=True)
    for n in range(10,17):
        report=json.loads((source/f"n{n:02d}.json").read_text())
        best=report["categories"]["connected"]
        result=search(n,best["support"],10)
        result["C_rect"]=best["best_cost"]
        save_json(out/f"n{n}.json",result)
        print(n,"depth3 cost",result.get("cost"),"C_rect",result["C_rect"],flush=True)
        if result.get("cost",100*n)<result["C_rect"]:
            print("COUNTEREXAMPLE FOUND",flush=True)
            return result


if __name__=="__main__":
    main()
