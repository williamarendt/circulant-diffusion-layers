"""Exact rational checker for the finite part of the all-orders proof.

No optimizer is used. The 13 weight rows below and their reflections cover
every valid rank-zero/rank-one collision pattern of the two normal forms.
The only exception is 3d=2e, which is singular at connected orders 3|n.
"""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("3.2.2") / "results"

from fractions import Fraction as Q
import math

from classify_weight5_symbolic import TEMPLATES, constraints, scale, sub


# Index order A: 0,d,2d,3d,e. B: 0,d,2d,e,e+d.
WEIGHTS = {
    "four_plus_one": {
        (None,1): (0,1,0,0,0),
        ((0,1),2): (Q(1,2),Q(1,2),Q(1,4),0,0),
        ((1,-1),2): (0,Q(1,3),Q(2,3),0,Q(1,6)),
        ((1,-2),1): (0,1,0,0,0),
        ((1,0),5): (0,Q(1,3),Q(1,3),Q(2,3),0),
        ((1,0),6): (Q(1,2),Q(1,2),Q(1,4),0,0),
        ((2,1),1): (Q(2,3),Q(1,3),Q(1,3),0,0),
        ((3,1),1): (Q(1,2),Q(1,2),Q(1,4),0,0),
    },
    "three_plus_two": {
        (None,1): (0,1,0,0,0),
        ((1,0),4): (Q(1,4),Q(3,4),Q(1,4),0,0),
        ((1,1),2): (0,Q(3,4),0,0,Q(1,2)),
        ((1,2),1): (Q(1,3),Q(2,3),0,0,Q(1,3)),
        ((3,1),1): (Q(1,3),Q(2,3),0,0,Q(1,3)),
    },
}


def normalize(p):
    if p[0]<0 or p[0]==0 and p[1]<0:
        return scale(-1,p)
    return p


def check():
    checked=excluded=exception=0
    for name,points in TEMPLATES.items():
        differences={sub(a,b) for a in points for b in points}
        relations={sub(a,b) for a in differences for b in differences}
        assert max(abs(a*d-b*c) for a,b in relations for c,d in relations)==12
        cases={(None,1)}
        for a,b in relations-{(0,0)}:
            g=math.gcd(a,b)
            direction=normalize((a//g,b//g))
            cases.update((direction,q) for q in range(1,g+1) if g%q==0)
        for direction,q in cases:
            cons,reason=constraints(points,direction,q)
            if reason:
                excluded+=1
                continue
            if name=="four_plus_one" and direction==(3,-2) and q==1:
                # 3d=2e. Set t=e-d; then d=2t, e=3t. The support is
                # {0,2t,3t,4t,6t}. Connectedness implies gcd(n,t)=1.
                # For 3|n, a nonzero period-three vector (1,1,0) is killed.
                exception+=1
                continue
            weights=WEIGHTS[name].get((direction,q))
            if weights is None:
                a,b=direction
                if name=="four_plus_one":
                    reflected=normalize((a+3*b,-b))
                    permutation=(3,2,1,0,4)
                else:
                    reflected=normalize((a+b,-b))
                    permutation=(2,1,0,4,3)
                base=WEIGHTS[name][reflected,q]
                weights=tuple(base[j] for j in permutation)
            assert all(w>=0 for w in weights)
            assert sum(weights)<=Q(4,3)
            for counts,gain in cons:
                assert sum(c*w for c,w in zip(counts,weights))>=gain, (name,direction,q,counts)
            checked+=1
    assert (checked,excluded,exception)==(21,22,1)
    print("Exact rational verification passed: 21 dual certificates, 22 excluded patterns,")
    print("one centered-progression exception; determinant bound 12 for both templates.")
    return dict(dual_certificates=checked,excluded_patterns=excluded,exceptional_patterns=exception)


def audit_saved_small_matrices():
    """Check endpoint constraints against independent full rectangle generation."""
    from itertools import combinations
    import json
    from pathlib import Path
    from circrect.algebra import circulant
    from circrect.packing import rectangles
    checked=0
    root=Path(str(RESULTS / 'weight5_f2_n_le16_20261105'))
    for path in root.glob("n[0-9][0-9].json"):
        report=json.loads(path.read_text())
        n=report["n"]
        for record in report["records"]:
            if not record["security"]["passed"]:
                continue
            support=record["support"]
            if n%3==0 and any({(i+j*n//3)%n for j in range(3)}<=set(support) for i in support):
                continue
            grouped={}
            for i,u in enumerate(support):
                for j,v in enumerate(support):
                    if i!=j:
                        grouped.setdefault((v-u)%n,[]).append((i,j))
            endpoint=set()
            for edges in grouped.values():
                for size in range(2,len(edges)+1):
                    for chosen in combinations(edges,size):
                        counts=[0]*5
                        for i,j in chosen:
                            counts[i]+=1;counts[j]+=1
                        endpoint.add((tuple(counts),size-1))
            full=set()
            matrix=circulant([int(i in support) for i in range(n)],2)
            for rect in rectangles(matrix,2,3,3):
                counts=[0]*5
                for i in rect["rows"]:
                    for j in rect["cols"]:
                        counts[support.index((j-i)%n)]+=1
                full.add((tuple(counts),rect["gain"]))
            assert endpoint==full,(n,support)
            checked+=1
    print("Independent endpoint/full-matrix rectangle audit passed:",checked,"supports.")
    return checked


if __name__=="__main__":
    check()
    import sys
    if "--audit-small" in sys.argv:
        audit_saved_small_matrices()
