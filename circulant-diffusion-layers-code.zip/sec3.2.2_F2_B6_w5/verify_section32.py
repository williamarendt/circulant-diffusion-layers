"""Targeted independent checks for the Section 3.2 draft."""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("3.2.2") / "results"

import json
import math
import random
import sys
from fractions import Fraction
from itertools import combinations
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT.parent))
from circrect.algebra import canonical, circulant, inverse, security
from circrect.packing import rectangles, solve, public_rectangle


def rem(a, b):
    while a and a.bit_length() >= b.bit_length():
        a ^= b << (a.bit_length() - b.bit_length())
    return a


def gcd(a, b):
    while b:
        a, b = b, rem(a, b)
    return a


def generator(n, support):
    return [int(i in support) for i in range(n)]


result = {}
tested = 0
for n in range(6, 19):
    for tail in combinations(range(1, n), 4):
        support = {0, *tail}
        rows = [sum(1 << ((i+d) % n) for d in support) for i in range(n)]
        overlaps = [(rows[0] & rows[i]).bit_count() for i in range(1, n)]
        if max(overlaps) > 3:
            continue
        has_core = n % 3 == 0 and any(
            {(i+j*n//3) % n for j in range(3)} <= support for i in support)
        has_rectangle = any(
            any((rows[0] & rows[i] & rows[j]).bit_count() == 3
                for j in range(i+1, n))
            for i in range(1, n) if (rows[0] & rows[i]).bit_count() == 3)
        assert has_core == has_rectangle, (n, support)
        tested += 1
result['core_classification_supports_checked'] = tested

rng = random.Random(20261031)
tested = invertible_count = 0
for m in range(3, 17):
    n = 3*m
    for _ in range(18):
        d, ell = rng.sample([v for v in range(1, n) if v % m], 2)
        if d % m == ell % m:
            continue
        support = {0, m, 2*m, d, ell}
        polynomial = 1 ^ (1 << (d % m)) ^ (1 << (ell % m))
        predicted = gcd(polynomial, (1 << m) | 1) == 1 and m % math.gcd(n, ell-d) == 0
        a = generator(n, support)
        actual = inverse(circulant(a, 2), 2) is not None
        assert actual == predicted, (n,d,ell)
        if actual:
            assert security(a, 2, 6)['passed'], (n,d,ell)
            invertible_count += 1
        tested += 1
result['core_rank_tests'] = tested
result['core_branch_tests'] = invertible_count

for n in (16,20,28,32,40,64):
    support = {0,1,2,3,n//2}
    assert security(generator(n,support), 2, 6)['passed']
    rects = rectangles(circulant(generator(n,support),2),2,3,3)
    weights = {0:Fraction(1,2),1:Fraction(1,2),2:Fraction(1,4),3:0,n//2:0}
    for rect in rects:
        assert sum(weights[(j-i)%n] for i in rect['rows'] for j in rect['cols']) >= rect['gain']
    selected = []
    for i in range(0,n,2):
        selected.append(([(i-2)%n,(i-1)%n,i], [i,(i+1)%n]))
    for i in range(1,n//2,2):
        selected.append(([i,i+n//2],[i,i+n//2]))
    used = set()
    gain = 0
    for rr, cc in selected:
        positions = {(i,j) for i in rr for j in cc}
        assert all((j-i)%n in support for i,j in positions)
        assert not used & positions
        used |= positions
        gain += (len(rr)-1)*(len(cc)-1)
    assert 4*n-gain == 11*n//4
result['even_family_certificate_orders'] = [16,20,28,32,40,64]

backend, env = 'brute', None
try:
    a = generator(12,{0,1,2,4,8})
    assert security(a,2,6)['passed']
    rects = rectangles(circulant(a,2),2,3,3)
    weights = {0:11,1:0,2:1,4:0,8:5}
    for rect in rects:
        assert sum(weights[(j-i)%12] for i in rect['rows'] for j in rect['cols']) >= 12*rect['gain']
    solved = solve(rects,backend,env,time_limit=2)
    # The independently verified position weights prove the upper bound 17.
    assert solved['gain'] == 17
    result['H12'] = dict(rectangles=len(rects),cost=31,
                         packing=[public_rectangle(rects[i]) for i in solved['selected']])
finally:
    if env is not None:
        env.dispose()

for n in range(16,65):
    if n % 31:
        assert security(generator(n,{0,1,3,4,5}),2,6)['passed']
for n in range(19,75):
    if n % 7 and n % 9:
        assert security(generator(n,{0,1,4,7,9}),2,6)['passed']
result['other_families_security'] = True

candidate_counts = {}
for n in (16,32,64):
    candidates = {}
    for d in range(n):
        for support in ({0,1,2,3,d},{0,d,2*d%n,3*d%n,1},
                        {0,1,2,d,(d+1)%n},{0,d,2*d%n,1,(1+d)%n}):
            if len(support) != 5 or math.gcd(n,*support) != 1:
                continue
            a = generator(n,support)
            key = json.dumps(canonical(a,2),separators=(',',':'))
            if key not in candidates and security(a,2,6)['passed']:
                candidates[key] = a
    candidate_counts[n] = len(candidates)
    assert len(candidates) == {16:14,32:38,64:86}[n]
    if n == 64:
        records = json.loads((ROOT.parent/str(RESULTS / 'gurobi/f2_p2_B6_n64_k5_connected/checkpoint.json')).read_text(encoding='utf-8'))['records']
        covered = [records[k] for k in candidates if k in records]
        missing = [a for k,a in candidates.items() if k not in records]
        assert len(covered) == 85 and len(missing) == 1
        assert all(r['cost_lower_bound'] >= 171 for r in covered)
        support = {0,1,16,25,40}
        representative = generator(64,support)
        assert canonical(missing[0],2) == canonical(representative,2)
        rects = rectangles(circulant(representative,2),2,3,3)
        assert len(rects) == 448
        assert all(sum((j-i)%64 == 40 for i in r['rows'] for j in r['cols']) >= r['gain'] for r in rects)
        result['n64_checkpoint_audit'] = dict(covered=85,missing_support=sorted(support),
                                             missing_rectangle_count=len(rects),minimum_stored_lower_bound=min(r['cost_lower_bound'] for r in covered))
result['power_two_candidate_counts'] = candidate_counts
(RESULTS/'section32_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k != 'H12'},indent=2))
print('H12 exact cost:',result['H12']['cost'])
