"""Section 4.1.4: run the existing shared Gurobi search with local presets."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "common"))
from gurobi_entry import main

if __name__ == "__main__":
    raise SystemExit(main('4.1.4', 'fp', 4, 3))
