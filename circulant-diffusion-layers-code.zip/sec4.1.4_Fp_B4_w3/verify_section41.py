"""Exact finite checks for the odd-prime weight-three draft; no optimizer."""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("4.1.4") / "results"

from collections import Counter
from functools import lru_cache
from itertools import combinations, product
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from circrect.algebra import circulant, inverse


def branch_four(matrix, p):
    n = len(matrix)
    # Invertibility and column weight three handle input weights >=3 and 1.
    # Check every normalized input of weight two explicitly.
    return all(sum((matrix[i][a] + t*matrix[i][b]) % p != 0
                   for i in range(n)) >= 2
               for a, b in combinations(range(n), 2) for t in range(1, p))


def matching_cost(matrix, p):
    n = len(matrix)
    edges = [0]*n
    for a, b in combinations(range(n), 2):
        common = [j for j in range(n) if matrix[a][j] and matrix[b][j]]
        if len(common) == 2:
            j, k = common
            if (matrix[a][j]*matrix[b][k]-matrix[a][k]*matrix[b][j]) % p == 0:
                edges[a] |= 1 << b
                edges[b] |= 1 << a

    @lru_cache(None)
    def best(mask):
        if not mask:
            return 0
        bit = mask & -mask
        i = bit.bit_length()-1
        rest = mask ^ bit
        value = best(rest)
        neighbors = edges[i] & rest
        while neighbors:
            partner = neighbors & -neighbors
            neighbors ^= partner
            value = max(value, 1+best(rest ^ partner))
        return value

    return 2*n-best((1 << n)-1)


def predicted_cost(a):
    from math import gcd
    n = len(a)
    D = {i for i, v in enumerate(a) if v}
    if n % 2 == 0 and any((i+n//2) % n in D for i in D):
        return 3*n//2
    for u in D:
        for d in range(1, n):
            if {(u+j*d) % n for j in range(3)} == D:
                g = gcd(n, d)
                return 2*n-g*((n//g)//2) if a[u] == a[(u+2*d) % n] else 2*n
    return 2*n


def check_circuit(a, p, kind):
    n = len(a)
    x = [tuple(int(i == j) for j in range(n)) for i in range(n)]
    depth = {v: 0 for v in x}
    gates = []

    def gate(left, right, sign=1):
        v = tuple((b+sign*c) % p for b, c in zip(left, right))
        d = 1+max(depth[left], depth[right])
        # Track signal occurrences, not optimized circuit costs.
        depth[v] = min(depth.get(v, d), d)
        gates.append((v, d))
        return v

    def signed(v, sign):
        w = tuple(sign*b % p for b in v)
        depth[w] = depth[v]
        return w

    y = [None]*n
    if kind == 'odd':
        h = (n-1)//2
        for j in range(h):
            t = gate(x[2*j+1], x[2*j+2], -1)
            y[2*j] = gate(x[2*j], t, -1)
            y[2*j+1] = gate(t, x[(2*j+3) % n])
        y[n-1] = gate(gate(x[n-1], x[0], -1), x[1])
        expected = (3*n+1)//2
    elif kind == 'even':
        h = n//2
        delta = a[h]
        for i in range(h):
            t = gate(x[i], x[i+h], delta)
            y[i] = gate(t, x[i+1])
            y[i+h] = gate(signed(t, delta), x[(i+h+1) % n])
        expected = 3*n//2
    else:
        for j in range(n//3):
            start = 3*j
            at = lambda k: x[(start+k) % n]
            u = gate(at(1), at(2), -1)
            v = gate(at(2), at(3))
            y[start] = gate(at(0), u)
            y[start+1] = gate(u, v, -1)
            y[start+2] = gate(v, at(4), -1)
        for i in range(3*(n//3), n):
            y[i] = gate(gate(x[i], x[(i+1) % n]), x[(i+2) % n], -1)
        expected = 2*n-n//3
    assert y == [tuple(row) for row in circulant(a, p)]
    assert len(gates) == expected
    assert max(d for _, d in gates) == 2
    return expected


def main():
    counts = Counter()
    for p in (3, 5, 7):
        for n in range(4, 13):
            for j, k in combinations(range(1, n), 2):
                for sj, sk in product((1, -1), repeat=2):
                    a = [0]*n
                    a[0], a[j], a[k] = 1, sj, sk
                    matrix = circulant(a, p)
                    counts['signed_supports'] += 1
                    if inverse(matrix, p) is None:
                        continue
                    D = {0, j, k}
                    coset = n % 3 == 0 and any(
                        {(u+t*n//3) % n for t in range(3)} == D for u in D)
                    ok = branch_four(matrix, p)
                    assert ok == (not coset), (p, n, a)
                    counts['invertible_branch_checks'] += 1
                    if ok:
                        assert matching_cost(matrix, p) == predicted_cost(a), (p, n, a)
                        counts['matching_classification_checks'] += 1

    representatives = []
    for p in (3, 5, 7, 11):
        for n in list(range(4, 33)) + [64]:
            a = [0]*n
            if n % 2:
                a[0], a[1], a[2] = 1, -1, 1
                kind = 'odd'
            else:
                h = n//2
                delta = 1 if pow(-2, h, p) != 1 else -1
                a[0], a[1], a[h] = 1, 1, delta
                kind = 'even'
            matrix = circulant(a, p)
            assert inverse(matrix, p) is not None
            assert branch_four(matrix, p)
            cost = check_circuit(a, p, kind)
            assert cost == (3*n+1)//2
            counts['attaining_circuits'] += 1
            if n in (4, 5, 6, 9, 15, 16, 32, 64):
                representatives.append(dict(p=p, n=n, cost=cost, depth=2))

    for n in range(5, 65):
        a = [0]*n
        a[0], a[1], a[2] = 1, 1, -1
        matrix = circulant(a, 3)
        assert (inverse(matrix, 3) is not None) == (n % 8 != 0)
        if n % 8:
            assert branch_four(matrix, 3)
            check_circuit(a, 3, 'exception')
            counts['ternary_separation_circuits'] += 1

    result = dict(scope='signed weight-three scalar circulants',
                  counts=dict(counts), representative_constructions=representatives,
                  all_checks_passed=True)
    path = (RESULTS / 'section41_verification.json')
    path.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(dict(counts), indent=2))
    return result


if __name__ == '__main__':
    main()
