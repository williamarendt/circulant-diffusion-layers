# Section 4.1.4: Odd Prime Fields, B=4, w=3

- `verify_section41.py`: independently checks the sign/support classification, maximum matching, attaining constructions, and characteristic-three examples. It does not invoke an integer programming solver.
- `results/section41_verification.json`, `results/odd_weight3_theorem/`: saved verification records.
- `results/gurobi/`: reports, checkpoints, and witnesses for odd-prime B4/w3 cases from the earlier batches.
- `run_gurobi.py`: entry point to the shared search with this section's parameters. Example: `python run_gurobi.py --n-values 4:16 --primes 3,5 --dry-run`.

The table in Section 4.1.4 lists optimal constructions established analytically; its optimality claims do not depend on integer programming. The script also includes checks for the other subsections of Section 4.1.
