"""Bounded, resumable complete low-cost signed searches at power-of-two orders.

At weight five and B=6, costs below 3n require a 2x3 (or transposed)
rectangle. Its three support edges have a common coefficient ratio s.
At a power-of-two order they form paths of vertex sizes 4+1 or 3+2;
an order-three cycle is impossible. After translating and changing the
overall sign, this gives templates A and B below. All omitted matrices
have cost at least 3n. This reduction applies to disconnected matrices too.
"""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("4.3.2") / "results"

import argparse
from itertools import product
import json
from pathlib import Path
import time

import circrect.search as search
from circrect.algebra import canonical, check_time, components, circulant, inverse, weight
from circrect.witness import verify
from run_odd_weight5_remaining import scipy_adapter
from signed_packing_cache import PackingCache


def fast_security(a, p, b, deadline=None):
    """Exact B>=6 test: circulant shifts reduce column pairs to (0,d).

    For either the matrix or its inverse, a pair has union size 2w-c.
    Each nonzero coefficient ratio cancels one bucket of shared entries.
    Thus its minimum output weight is 2w-c-largest_bucket. Checking both
    directions on supports of size at most two is sufficient for B>=6.
    """
    assert p != 2 and b == 6 and weight(a) == 5
    inv = inverse(circulant(a,p),p,deadline)
    if inv is None:
        return dict(passed=False,reason='singular')
    inverse_weight=weight(inv[0])
    if inverse_weight < 5:
        return dict(passed=False,reason='inverse_column_too_sparse',inverse_weight=inverse_weight)
    reciprocals={v:pow(v,-1,p) for v in range(1,p)}
    for direction,row in (('forward',a),('inverse',inv[0])):
        row=[v%p for v in row]
        w=weight(row)
        n=len(row)
        for d in range(1,n):
            check_time(deadline)
            counts={}
            overlap=0
            for j,u in enumerate(row):
                v=row[(j+d)%n]
                if u and v:
                    overlap+=1
                    ratio=(-u*reciprocals[v])%p
                    counts[ratio]=counts.get(ratio,0)+1
            minimum=2*w-overlap-max(counts.values(),default=0)
            if minimum<4:
                return dict(passed=False,reason='circulant_pair_counterexample',
                            direction=direction,displacement=d,output_weight=minimum)
    return dict(passed=True,full_rank=True,reason='circulant_bidirectional_ratio_counts',
                inverse_weight=inverse_weight,certified_branch_lower_bound=6)


def reduced_generators(n, k, p, deadline):
    assert n >= 16 and n & (n-1) == 0 and k == 5 and p != 2
    seen = set()

    def emit(positions, values):
        positions = [j % n for j in positions]
        if len(set(positions)) != 5:
            return None
        a = [0]*n
        for j, v in zip(positions, values):
            a[j] = v
        key = canonical(a, p)
        if key in seen:
            return None
        seen.add(key)
        return a

    # Promising supports first; all signs are explored, without assuming
    # that a binary branch-number certificate transfers to an odd field.
    for support in ([0, 1, 2, 4, n-2], [0, 1, 2, 3, n//2]):
        for tail in product((1, -1), repeat=4):
            check_time(deadline)
            a = emit(support, (1,)+tail)
            if a is not None:
                yield a
    for d in range(1, n):
        for e in range(n):
            for s, t in product((1, -1), repeat=2):
                check_time(deadline)
                for positions, values in (
                    ([0,d,2*d,3*d,e], [1,s,1,s,t]),
                    ([0,d,2*d,e,e+d], [1,s,1,t,s*t])):
                    a = emit(positions, values)
                    if a is not None:
                        yield a


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--orders', default='32,64')
    parser.add_argument('--primes', default='3,5,7,11')
    parser.add_argument('--seconds', type=float, default=180)
    parser.add_argument('--per-matrix', type=float, default=8)
    parser.add_argument('--output', default=str(RESULTS / 'odd_weight5_power_two_20261107'))
    args = parser.parse_args()
    root = Path(args.output)
    root.mkdir(parents=True, exist_ok=True)
    packing_cache=PackingCache(root)
    search.solve = packing_cache.solve
    search.generators = reduced_generators
    def contextual_security(a,p,b,deadline=None):
        packing_cache.active_generator=a
        packing_cache.active_prime=p
        return fast_security(a,p,b,deadline)
    search.security = contextual_security
    reduction = dict(name='signed_weight5_low_cost_two_path_templates',
        threshold='3n', outside_cost_lower_bound='3n',
        templates=['1+sX^d+X^(2d)+sX^(3d)+tX^e',
                   '1+sX^d+X^(2d)+tX^e+stX^(e+d)'],
        signs='s,t in {1,-1}',
        rationale='See run_odd_weight5_power_two.py and reduction.md')
    rows = []
    for n in map(int,args.orders.split(',')):
        for p in map(int,args.primes.split(',')):
            folder = root/f'fp_p{p}_B6_n{n}_k5'
            config = dict(model='C_rect',field='fp',prime=p,n=n,branch_min=6,
                          effective_branch_target=6,weight=5,connected_only=False,mode='exact')
            path = folder/'report.json'
            previous = json.loads(path.read_text()) if path.exists() else None
            if previous and previous.get('status') in ('GLOBAL_OPTIMUM','TARGET_ATTAINED'):
                report = previous
            else:
                print(f'START n={n} p={p}',flush=True)
                cp_path=folder/'checkpoint.json'
                cp_before=json.loads(cp_path.read_text()) if cp_path.exists() else {}
                packing_cache.active_best=(cp_before.get('best') or {}).get('cost')
                report = search.run_search(config,'scipy',None,folder,
                    (folder/'checkpoint.json').exists(),args.seconds,args.per_matrix,1,0,False)
                if report['best_cost'] is not None:
                    assert report['best_cost'] < 3*n
                report['search_scope'] = ('Complete signed affine representatives from the two '
                    'necessary low-cost templates; omitted matrices have C_rect >=3n.')
                report['candidate_reduction'] = reduction
                report['packing_cache_hits']=packing_cache.hits
                search.write_json(path,report)
                cp = json.loads((folder/'checkpoint.json').read_text())
                cp['candidate_reduction'] = reduction
                search.write_json(folder/'checkpoint.json',cp)
            row = dict(n=n,p=p,status=report['status'],lower=report['global_lower_bound'],
                upper=report['best_cost'],enumeration_complete=report['enumeration_complete'],
                unresolved=report['unresolved_matrices'],records=report['canonical_records'],
                seconds=report['seconds_this_run'],report=str(path))
            if row['upper'] is not None:
                w=json.loads((folder/'best_witness.json').read_text())
                verify(w)
                row.update(witness_components=components(w['generator']),depth=w['circuit']['depth'])
                if row['witness_components']==1:
                    row.update(connected_lower=row['lower'],connected_upper=row['upper'])
            rows.append(row)
            search.write_json(root/'summary.json',rows)
            print('RESULT '+json.dumps(row),flush=True)
    print('DONE',flush=True)


if __name__=='__main__':
    main()
