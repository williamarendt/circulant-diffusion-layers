"""Reuse identical signed rectangle packing problems across odd primes.

Only integer packing evidence is shared. Field-dependent rank and branch
checks are always run afresh. A matching problem has precisely the same
position masks and rectangle savings.
"""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("4.3.2") / "results"

import hashlib
import json
from pathlib import Path

from circrect.algebra import circulant, components
from circrect.packing import greedy, rectangles
from circrect.search import write_json
from run_odd_weight5_remaining import scipy_adapter


def fingerprint(items):
    payload=';'.join(f'{q["mask"]}:{q["gain"]}' for q in sorted(items,key=lambda r:r['mask']))
    return hashlib.sha256(payload.encode()).hexdigest()


class PackingCache:
    def __init__(self, root):
        self.path=Path(root)/'packing_cache.json'
        self.data=json.loads(self.path.read_text()) if self.path.exists() else {}
        self.active_best=None
        self.active_generator=None
        self.active_prime=None
        self.component_bounds={}
        self.hits=0
        checkpoints=list(Path(root).glob('*/checkpoint.json'))
        workspace=Path(__file__).resolve().parent
        for size,base in ((8,section_dir('4.3.2')/'results'/'gurobi'),
                          (16,RESULTS/'odd_weight5_remaining_20261107'),
                          (32,Path(root))):
            for prime in (3,5,7,11):
                path=base/f'fp_p{prime}_B6_n{size}_k5'/'report.json'
                if path.exists():
                    report=json.loads(path.read_text())
                    if report['status']=='GLOBAL_OPTIMUM':
                        self.component_bounds[size,prime]=(report['best_cost'],str(path))
        # Old binary certificates also apply when the full rectangle mask
        # set and savings match exactly; no binary security claim transfers.
        for n in (32,64):
            for suffix in ('','_connected'):
                external=section_dir('3.2.2')/'results'/'gurobi'/f'f2_p2_B6_n{n}_k5{suffix}'/'checkpoint.json'
                if external.exists():
                    checkpoints.append(external)
        for path in checkpoints:
            cp=json.loads(path.read_text())
            n=cp['config']['n']
            p=cp['config']['prime']
            for record in cp['records'].values():
                if not record.get('feasible'):
                    continue
                # Signed admissibility is identical over every odd field.
                field=2 if p==2 else 3
                items=rectangles(circulant(record['generator'],field),field,3,3)
                key=fingerprint(items)
                bound=record['solver']['gain_upper_bound']
                prior=self.data.get(key)
                if prior is None or bound<prior['bound']:
                    self.data[key]=dict(bound=bound,source=str(path),n=n)
            witness=cp.get('best')
            if witness:
                field=2 if p==2 else 3
                items=rectangles(circulant(witness['generator'],field),field,3,3)
                key=fingerprint(items)
                if key in self.data:
                    masks=[str(sum(1<<(i*n+j) for i in q['rows'] for j in q['cols']))
                           for q in witness['rectangles']]
                    self.data[key]['selected_masks']=masks
        write_json(self.path,self.data)

    def solve(self, items, backend, env=None, time_limit=None, threads=1, seed=0,
              deadline=None, model_path=None):
        key=fingerprint(items)
        prior=self.data.get(key)
        n=1+max((i for q in items for i in q['rows']+q['cols']),default=-1)
        if not items:
            return scipy_adapter(items,backend,env,time_limit,threads,seed,deadline,model_path)
        if self.active_generator is not None:
            g=components(self.active_generator)
            if g>1 and (n//g,self.active_prime) in self.component_bounds:
                minimum,source=self.component_bounds[n//g,self.active_prime]
                bound=4*n-g*minimum
                if prior is None or bound<prior['bound']:
                    prior=dict(bound=bound,n=n,source=source,components=g,
                               component_order=n//g,component_field=self.active_prime)
                    self.data[key]=prior
        selected=greedy(items)
        by_mask={str(q['mask']):j for j,q in enumerate(items)}
        if prior and 'selected_masks' in prior:
            candidate=[by_mask[m] for m in prior['selected_masks']]
            if sum(items[j]['gain'] for j in candidate)>sum(items[j]['gain'] for j in selected):
                selected=candidate
        gain=sum(items[j]['gain'] for j in selected)
        used=0
        for j in selected:
            assert not used & items[j]['mask']
            used |= items[j]['mask']
        if prior:
            assert gain<=prior['bound']
        sufficient=(prior is not None and (gain==prior['bound'] or
            (self.active_best is not None and 4*n-prior['bound']>=self.active_best)))
        if sufficient:
            self.hits+=1
            result=dict(selected=selected,gain=gain,gain_upper_bound=prior['bound'],
                        optimal=gain==prior['bound'],status='CACHED_INTEGER_PACKING_BOUND',
                        backend='scipy_cached',version='integer-mask-cache-v1',seconds=0,
                        source=prior['source'],threads=1,seed=seed,mip_gap=0,int_feas_tol=None)
        else:
            result=scipy_adapter(items,backend,env,time_limit,threads,seed,deadline,model_path)
            if prior:
                result['gain_upper_bound']=min(result['gain_upper_bound'],prior['bound'])
                assert result['gain']<=result['gain_upper_bound']
                result['optimal']=result['gain']==result['gain_upper_bound']
            self.data[key]=dict(bound=result['gain_upper_bound'],n=n,
                selected_masks=[str(items[j]['mask']) for j in result['selected']],
                source='packing_cache.json:'+key,solver=result['backend'])
            write_json(self.path,self.data)
        cost=4*n-result['gain']
        self.active_best=cost if self.active_best is None else min(self.active_best,cost)
        return result
