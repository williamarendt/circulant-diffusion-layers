"""Inventory existing odd-prime weight-five searches; start no new searches."""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("4.3.2") / "results"

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from circrect.witness import verify
from circrect.algebra import canonical
from run_odd_weight5_power_two import reduced_generators


def main():
    rows = []
    reduced_keys = {}
    for path in sorted(RESULTS.rglob('report.json')):
        report = json.loads(path.read_text(encoding='utf-8'))
        config = report.get('config', {})
        if (config.get('field'), config.get('weight'), config.get('branch_min')) != ('fp', 5, 6):
            continue
        checkpoint = json.loads(path.with_name('checkpoint.json').read_text(encoding='utf-8'))
        assert checkpoint['config'] == config
        assert report['enumeration_complete'] == checkpoint['enumeration_complete']
        if config['n'] in (32,64):
            n=config['n']
            assert checkpoint['candidate_reduction']['name']=='signed_weight5_low_cost_two_path_templates'
            if n not in reduced_keys:
                reduced_keys[n]={json.dumps(canonical(a,3),separators=(',',':'))
                                 for a in reduced_generators(n,5,3,None)}
            assert set(checkpoint['records'])==reduced_keys[n]
            assert report['best_cost'] < 3*n
        feasible = [r for r in checkpoint['records'].values() if r.get('feasible')]
        if report['status'] == 'NO_FEASIBLE_FIXED_WEIGHT':
            assert report['enumeration_complete'] and not feasible
        elif report['status'] == 'GLOBAL_OPTIMUM':
            assert report['enumeration_complete']
            assert report['global_lower_bound'] == report['best_cost']
            assert all(r['cost_lower_bound'] >= report['best_cost'] for r in feasible)
        witness_verified = False
        depth = None
        witness_components = None
        if report['best_cost'] is not None:
            witness = json.loads(path.with_name('best_witness.json').read_text(encoding='utf-8'))
            verify(witness)
            assert witness['cost'] == report['best_cost']
            witness_verified = True
            depth = witness['circuit']['depth']
            witness_components = witness['support_components']
        n = config['n']
        rows.append(dict(n=n, p=config['prime'], connected=config['connected_only'],
                         status=report['status'], lower_bound=report['global_lower_bound'],
                         best_cost=report['best_cost'], enumeration_complete=report['enumeration_complete'],
                         unresolved_matrices=report.get('unresolved_matrices'),
                         canonical_records=len(checkpoint['records']),
                         general_rectangle_bound=(20*n+8)//9,
                         witness_verified=witness_verified, depth=depth,
                         witness_components=witness_components,
                         source=str(path.relative_to(ROOT))))
    rows.sort(key=lambda r: (r['n'], r['p'], r['connected']))
    for row in rows:
        peer = next((r for r in rows if (r['n'], r['p'], r['connected']) ==
                     (row['n'], row['p'], not row['connected'])), None)
        if peer is not None:
            row['connected_scope_matches'] = row['best_cost'] == peer['best_cost']
        elif not row['connected']:
            row['connected_scope_matches'] = (
                row['status'] == 'NO_FEASIBLE_FIXED_WEIGHT' or row['witness_components'] == 1)
    out = RESULTS / 'section43_search_inventory.json'
    out.write_text(json.dumps(rows, indent=2), encoding='utf-8')
    unrestricted = {(r['n'], r['p']): r for r in rows if not r['connected']}
    orders=list(range(1,17))+[32,64]
    assert set(unrestricted) == {(n, p) for n in orders for p in (3, 5, 7, 11)}
    assert all(r['connected_scope_matches'] for r in rows)
    manuscript = (ROOT/'reference'/'section43_weight_five.tex').read_text(encoding='utf-8')
    table_rows = re.findall(r'^\s*(\d+)\s*&\s*(---|\d+)\s*&\s*(---|\d+)\s*&\s*(---|\d+)\s*&\s*(---|\d+)\\\\', manuscript, re.M)
    assert [int(r[0]) for r in table_rows] == list(range(7, 17))+[32,64]
    for n, *costs in table_rows:
        assert [None if c == '---' else int(c) for c in costs] == [
            unrestricted[int(n), p]['best_cost'] for p in (3, 5, 7, 11)]
    assert all(unrestricted[n, p]['status'] == 'NO_FEASIBLE_FIXED_WEIGHT'
               for n in range(1, 7) for p in (3, 5, 7, 11))
    print(json.dumps(dict(reports=len(rows), witnesses_verified=sum(r['witness_verified'] for r in rows),
                          orders=sorted({r['n'] for r in rows}),
                          unfinished=[r['source'] for r in rows if not r['enumeration_complete']],
                          output=str(out)), indent=2))


if __name__ == '__main__':
    main()
