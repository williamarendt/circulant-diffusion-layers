# Section 4.3.2: Odd Prime Fields, B=6, w=5

| Code | Purpose | Saved results |
|---|---|---|
| `run_gurobi.py` | Entry point to the original shared search | `results/gurobi/` contains the earlier Gurobi reports and witnesses |
| `run_odd_weight5_remaining.py` | 48 supplementary cases: p=3,5,7,11 and n=1–6,9,12–16; recorded runs used SciPy | `results/odd_weight5_remaining_20261107/` |
| `run_odd_weight5_power_two.py` | Eight searches at n=32,64 using structural reductions; recorded runs used SciPy | `results/odd_weight5_power_two_20261107/` |
| `signed_packing_cache.py` | Caches identical integer packing problems; invokes the SciPy adapter on a cache miss | Cache JSON files in the same result directory |
| `refine_odd_weight5_power_two.py` | Propagates known component lower bounds without solving a MILP | Refinement records in the same result directory |
| `audit_section43_records.py` | Audits 88 reports and 62 feasible witnesses, regenerates large-order candidate sets, and compares them with the paper's table | `results/section43_search_inventory.json` |

The SciPy packing function is reused from
`../sec3.2.2_F2_B6_w5/search_weight5_small.py::solve_scipy`; shared import paths are
configured automatically. The cache can also read original checkpoints from the
binary section, but reuses them only when the entire integer packing problem is
identical. Binary-field security conclusions are not transferred to prime fields.

`reference/section43_weight_five.tex` is a snapshot of the paper's table input used
by the audit, not a second active manuscript. Old paths in historical results
describe their original locations; use this directory layout to locate the files.
