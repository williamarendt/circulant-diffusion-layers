"""Resume missing odd-prime weight-five searches using installed SciPy/HiGHS."""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("4.3.2") / "results"

import argparse
import json
from pathlib import Path
import time

import circrect.search as search
from circrect.algebra import components
from circrect.witness import verify
from search_weight5_small import solve_scipy

COMPLETE = {'GLOBAL_OPTIMUM', 'TARGET_ATTAINED', 'NO_FEASIBLE_FIXED_WEIGHT'}


def scipy_adapter(items, backend, env=None, time_limit=None, threads=1, seed=0,
                  deadline=None, model_path=None):
    assert backend == 'scipy' and model_path is None
    remaining = None if deadline is None else max(0.001, deadline-time.monotonic())
    seconds = time_limit if remaining is None else min(time_limit or remaining, remaining)
    n = 1+max((i for q in items for i in q['rows']+q['cols']), default=-1)
    result = solve_scipy(items, n, seconds)
    result.update(threads=threads, seed=seed, mip_gap=0, int_feas_tol=None)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--seconds', type=float, default=90)
    parser.add_argument('--per-matrix', type=float, default=8)
    parser.add_argument('--orders', default='1,2,3,4,5,6,9,12,13,14,15,16')
    parser.add_argument('--primes', default='3,5,7,11')
    parser.add_argument('--output', default=str(RESULTS / 'odd_weight5_remaining_20261107'))
    args = parser.parse_args()
    root = Path(args.output)
    root.mkdir(parents=True, exist_ok=True)
    search.solve = scipy_adapter
    rows = []
    summary = root/'summary.json'
    for n in map(int, args.orders.split(',')):
        for p in map(int, args.primes.split(',')):
            config = dict(model='C_rect', field='fp', prime=p, n=n, branch_min=6,
                          effective_branch_target=6, weight=5, connected_only=False, mode='exact')
            folder = root/f'fp_p{p}_B6_n{n}_k5'
            path = folder/'report.json'
            report = json.loads(path.read_text()) if path.exists() else None
            if not report or report['status'] not in COMPLETE:
                print(f'START n={n} p={p}', flush=True)
                report = search.run_search(config, 'scipy', None, folder,
                            (folder/'checkpoint.json').exists(), args.seconds,
                            args.per_matrix, 1, 0, False)
            row = dict(n=n, p=p, status=report['status'], lower=report['global_lower_bound'],
                       upper=report['best_cost'], enumeration_complete=report['enumeration_complete'],
                       unresolved=report['unresolved_matrices'], report=str(path))
            if row['upper'] is not None:
                witness = json.loads((folder/'best_witness.json').read_text())
                verify(witness)
                count = components(witness['generator'])
                row['witness_components'] = count
                row['depth'] = witness['circuit']['depth']
                if count == 1:
                    row['connected_lower'] = row['lower']
                    row['connected_upper'] = row['upper']
                    row['connected_status'] = ('GLOBAL_OPTIMUM' if row['status'] in COMPLETE
                                               else 'INCOMPLETE_WITH_WITNESS')
                else:
                    connected_folder = folder.with_name(folder.name+'_connected')
                    config['connected_only'] = True
                    cp = connected_folder/'report.json'
                    connected = json.loads(cp.read_text()) if cp.exists() else None
                    if not connected or connected['status'] not in COMPLETE:
                        connected = search.run_search(config, 'scipy', None, connected_folder,
                            (connected_folder/'checkpoint.json').exists(), args.seconds,
                            args.per_matrix, 1, 0, False)
                    row.update(connected_lower=connected['global_lower_bound'],
                               connected_upper=connected['best_cost'], connected_status=connected['status'],
                               connected_report=str(cp))
            elif row['status'] == 'NO_FEASIBLE_FIXED_WEIGHT':
                row['connected_status'] = 'NO_FEASIBLE_FIXED_WEIGHT'
            rows.append(row)
            search.write_json(summary, rows)
            print('RESULT '+json.dumps(row), flush=True)
    print('DONE '+str(summary), flush=True)


if __name__ == '__main__':
    main()
