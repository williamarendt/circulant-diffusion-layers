# Complete candidate reduction for signed weight-five power-of-two orders

This run uses odd prime fields, signed scalar circulants, weight five, branch number six, and no connectivity restriction. A per-case time limit is enforced. A time-limited result is an interval, not an optimum.

## Why the omitted matrices cost at least 3n

The branch-number rectangle dimension bound permits only 2x2, 2x3, 3x2, and 3x3 rectangles. If only 2x2 rectangles are admissible, their disjoint positions allow at most two rectangles per row. Counting their two rows gives at most n rectangles. Each saves one gate, hence C_rect>=4n-n=3n.

Thus a matrix with C_rect<3n admits a 2x3 or 3x2 rectangle. Transposition and reversal of circulant indices show that it admits a 2x3 rectangle in either case.

Its two rows share three positions of the same coefficient ratio s in {1,-1}. If their total support overlap is c, canceling these three positions leaves at most 10-c-3 nonzero outputs for an input of weight two in the transpose. Since the transpose has the same branch number, this number is at least four. Therefore c=3, and these are exactly the three support edges of their nonzero displacement d.

The displacement graph on the five support points has in-degree and out-degree at most one. A step of order two has an even number of edges and cannot give three. At power-of-two orders no cycle of length three exists, and all longer cycles require at least four edges. Consequently there are no cycles: the three edges form two paths of vertex sizes 4+1 or 3+2.

Translate the start of the longer path to zero and normalize its coefficient to +1. Propagating the common ratio s along the paths gives exactly:

- A: 1+sX^d+X^(2d)+sX^(3d)+tX^e;
- B: 1+sX^d+X^(2d)+tX^e+stX^(e+d).

Both s and t range over {1,-1}; all exponents are modulo n and must be distinct. Every nonzero d and every e are enumerated. The runner removes duplicates only by the existing signed affine canonicalization, which preserves rank, branch number, rectangle cost, and connectivity. This also includes disconnected candidates; no odd-step assumption is made.

## Meaning of completion

The checkpoint's enumeration_complete refers to enumeration of these necessary low-cost templates. Every report explicitly records this reduction. Once a verified incumbent below 3n exists, all omitted matrices have strictly greater cost. If every enumerated candidate's saved lower bound also excludes improvement, the incumbent is globally optimal in the full signed weight-five class, not just within a construction family. Otherwise the run reports an incomplete interval.

## Implementation cross-check

At n=16 the reduced enumeration has 105 signed affine classes. Comparing against the prior complete full-generator checkpoints at p=3,5,7,11 found that all feasible candidate classes with saved cost lower bound below 48 are included: 10,4,22,22 classes respectively, with zero omissions. This finite cross-check supplements the general proof above.

The same security, signed rectangle enumeration, position-capacity MILP, and independent circuit/witness verification as the earlier searches are used. The only new mathematical reduction is the proven candidate generation above. SciPy/HiGHS is used because the Gurobi token server was unavailable.

## Exact circulant security acceleration

The first n=32,p=3 run completed with the original general security routine. Subsequent runs use fast_security in the runner. The mathematical criterion is unchanged: test inputs of weight at most two in the matrix and its inverse. Both matrices are circulant, so simultaneous translation reduces every column pair to columns 0,d. If the common support size is c and each column has weight w, the union has size 2w-c. Group common entries by their cancellation ratio -u/v. For every nonzero two-input coefficient ratio, precisely one such group cancels; hence the minimum output weight is 2w-c minus the largest group size. It must be at least four in both directions, and inverse column weight must be at least five. These tests are necessary and sufficient for branch number at least six by the existing bidirectional small-support criterion. A unit input gives branch number at most six.

The accelerated test was checked against every canonical representative in each of the four complete n=16 checkpoints: 622 per prime, 2488 total, including both accepted and rejected matrices. All decisions agree (fast_security_crosscheck.json). Published improved witnesses are still independently verified by the original general security routine, including full column-pair enumeration. The initial slower run was stopped at its next parameter case and resumed from saved atomic candidate checkpoints; no old evidence was discarded.

## Reusing packing bounds

signed_packing_cache.py identifies a packing problem by the sorted list of integer position masks and rectangle savings (SHA-256 of an unambiguous serialization). A bound or packing is reused only when that entire list agrees. The signs and field-specific security tests are not reused. The cache can therefore also use prior binary packing bounds when the complete mask lists agree, as well as prior odd-prime bounds. Stored selected masks are checked for disjointness before constructing a circuit. The independent witness verifier still checks all coefficients and security in the destination field.

If the cached saving upper bound already excludes improvement over the current verified cost, the runner need not solve that candidate to its own exact optimum. Its saved lower bound suffices for the global proof. All candidate records retain their own gain upper bound; global optimality requires every feasible candidate lower bound to exclude improvement, full completion of the reduced enumeration, and an incumbent below 3n.

## Bounds from smaller components

If the support has g components of order m=n/g, coordinate permutations give g identical signed scalar circulant blocks. Each block has the same branch number and is invertible, and rectangle costs add across the blocks. Thus the known field-specific minimum at order m gives a rigorous lower bound g times that minimum for this candidate. The runner uses the completed minima at orders 8 and16, and at order32 once it is proven. The two difficult n32,p=7/11 candidates are four copies of order-eight blocks, so their costs are at least 4*22=88; this excludes improvement over86. The same reasoning handles the corresponding disconnected order64 candidates. No exact solution of their larger disconnected MILP is needed.

## Final results

All eight cases are GLOBAL_OPTIMUM, with reduced enumeration complete, no unresolved candidate bounds, and connected independently verified depth-three witnesses. There are 269 candidate classes at n32 and625 at n64 (including priority seeds). In prime order3,5,7,11, the minima are n32=(88,88,86,86), n64=(176,176,171,171). These are full-class minima in the tested fields; no claim for other primes is made.
