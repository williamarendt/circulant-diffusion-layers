"""Refine saved bounds using exact smaller-order minima and component additivity."""

# Local import paths for the section-based Paper 1 bundle.
import sys as _bundle_sys
from pathlib import Path as _BundlePath
_bundle_root = next(p for p in _BundlePath(__file__).resolve().parents
                    if (p / "common" / "bundle_paths.py").is_file())
_bundle_sys.path.insert(0, str(_bundle_root / "common"))
from bundle_paths import setup_imports, section_dir
setup_imports()
RESULTS = section_dir("4.3.2") / "results"

import json
from pathlib import Path
from circrect.algebra import components
from circrect.search import write_json


def refine(root=str(RESULTS / 'odd_weight5_power_two_20261107')):
    root=Path(root)
    known={}
    for n,base in ((8,RESULTS / 'gurobi'),(16,RESULTS / 'odd_weight5_remaining_20261107')):
        for p in (3,5,7,11):
            path=base/f'fp_p{p}_B6_n{n}_k5'/'report.json'
            d=json.loads(path.read_text())
            assert d['status']=='GLOBAL_OPTIMUM'
            known[n,p]=(d['best_cost'],str(path))
    rows=[]
    for n in (32,64):
        for p in (3,5,7,11):
            folder=root/f'fp_p{p}_B6_n{n}_k5'
            path=folder/'report.json'
            if not path.exists(): continue
            report=json.loads(path.read_text())
            cp=json.loads((folder/'checkpoint.json').read_text())
            changes=0
            for record in cp['records'].values():
                if not record.get('feasible'): continue
                g=components(record['generator'])
                if g>1 and (n//g,p) in known:
                    lower,source=known[n//g,p]
                    bound=g*lower
                    if bound>record['cost_lower_bound']:
                        assert bound<=record['cost']
                        record['cost_lower_bound']=bound
                        record['component_bound']=dict(components=g,component_order=n//g,
                            component_minimum=lower,source=source)
                        changes+=1
            if cp.get('best'):
                best=cp['best']['cost']
                unresolved=[r for r in cp['records'].values() if r.get('feasible') and r['cost_lower_bound']<best]
                report['unresolved_matrices']=len(unresolved)
                if cp['enumeration_complete']:
                    report['global_lower_bound']=min([best]+[r['cost_lower_bound'] for r in cp['records'].values() if r.get('feasible')])
                    if not unresolved:
                        report['status']='GLOBAL_OPTIMUM'
                report['component_refinement']=True
                if report['status']=='GLOBAL_OPTIMUM':
                    known[n,p]=(best,str(path))
            write_json(folder/'checkpoint.json',cp)
            write_json(path,report)
            row=dict(n=n,p=p,status=report['status'],lower=report['global_lower_bound'],
                     upper=report['best_cost'],enumeration_complete=report['enumeration_complete'],
                     unresolved=report['unresolved_matrices'],records=report['canonical_records'],
                     report=str(path),component_bounds_improved=changes)
            if cp.get('best'):
                row.update(witness_components=components(cp['best']['generator']),depth=cp['best']['circuit']['depth'])
            rows.append(row)
    write_json(root/'summary.json',rows)
    for r in rows: print(json.dumps(r),flush=True)


if __name__=='__main__':
    refine()
