"""Shared paths for the section-organized Paper 1 code bundle."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent.parent
SECTIONS = {
    '3.1.4': 'sec3.1.4_F2_B4_w3', '3.2.2': 'sec3.2.2_F2_B6_w5',
    '4.1.4': 'sec4.1.4_Fp_B4_w3', '4.2.4': 'sec4.2.4_Fp_B5_w4',
    '4.3.2': 'sec4.3.2_Fp_B6_w5',
}


def section_dir(section):
    return ROOT / SECTIONS[section]


def setup_imports():
    paths = [ROOT / 'common']
    for name in SECTIONS.values():
        paths.extend((ROOT / name, ROOT / name / 'auxiliary'))
    for path in paths:
        if str(path) not in sys.path:
            sys.path.append(str(path))
