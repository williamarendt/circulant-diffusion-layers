import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from circrect.batch import cases, integers, run_batch
from circrect.cli import parser


class BatchTests(unittest.TestCase):
    def args(self, directory, *extra):
        return parser().parse_args(["batch", "--field", "f2", "--n-values", "7,9",
                                    "--branch-values", "4", "--backend", "brute",
                                    "--output", directory, *extra])

    def test_grid_and_inclusive_ranges(self):
        self.assertEqual(integers("8:12:2,12,17"), [8, 10, 12, 17])
        with self.assertRaises(ValueError):
            integers("12:8")
        args = parser().parse_args(["batch", "--field", "fp", "--primes", "3,5",
                                    "--n-values", "8:10", "--branch-values", "4,5"])
        self.assertEqual(len(cases(args)), 12)
        args.primes = "9"
        with self.assertRaises(ValueError):
            cases(args)
        args = self.args("unused", "--branch-values", "5,6")
        self.assertEqual([j["config"]["effective_branch_target"] for j in cases(args)], [6] * 4)

    def test_resume_summary_and_skip_completed(self):
        with tempfile.TemporaryDirectory() as d:
            args = self.args(d, "--max-candidates", "1")
            first = run_batch(args)
            self.assertEqual(first["status"], "BATCH_INCOMPLETE")
            args.max_candidates = None
            final = run_batch(args)
            self.assertEqual(final["status"], "BATCH_COMPLETE")
            final = run_batch(args)
            rows = json.loads((Path(d) / "summary.json").read_text(encoding="utf-8"))
            self.assertTrue(all(r["action"] == "skipped_completed" for r in rows))
            self.assertEqual(next(r for r in rows if r["n"] == 9)["best_cost"], 18)
            self.assertTrue((Path(d) / "summary.csv").exists())

    def test_dry_run_and_interrupt_stop_batch(self):
        with tempfile.TemporaryDirectory() as d:
            args = self.args(str(Path(d) / "dry"), "--dry-run")
            with patch("circrect.batch.available_backend", side_effect=AssertionError("solver initialized")):
                self.assertEqual(run_batch(args)["status"], "DRY_RUN")
            self.assertFalse(Path(args.output).exists())
            args = self.args(str(Path(d) / "interrupt"))
            report = {"status": "INCOMPLETE_NO_WITNESS", "global_lower_bound": 11,
                      "best_cost": None, "seconds_this_run": 0.01, "interrupted": True}
            with patch("circrect.batch.run_search", return_value=report) as search:
                result = run_batch(args)
            self.assertEqual(search.call_count, 1)
            self.assertTrue(result["interrupted"])
            self.assertEqual(result["pending_cases"], 1)

    def test_case_error_retains_persisted_witness_in_summary(self):
        with tempfile.TemporaryDirectory() as d:
            args = self.args(d, "--n-values", "9")
            run_batch(args)
            report_path = Path(d) / "f2_p2_B4_n9_k3" / "report.json"
            report = json.loads(report_path.read_text(encoding="utf-8"))
            report["status"] = "INCOMPLETE_WITH_WITNESS"
            report_path.write_text(json.dumps(report), encoding="utf-8")
            with patch("circrect.batch.run_search", side_effect=OSError("simulated save failure")):
                result = run_batch(args)
            rows = json.loads((Path(d) / "summary.json").read_text(encoding="utf-8"))
            self.assertEqual(rows[0]["status"], "ERROR")
            self.assertEqual(rows[0]["best_cost"], 18)
            self.assertEqual(rows[0]["lower_bound"], 18)
            self.assertEqual(len(result["errors"]), 1)


if __name__ == "__main__":
    unittest.main()
