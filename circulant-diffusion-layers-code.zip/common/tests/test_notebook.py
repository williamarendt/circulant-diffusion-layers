from pathlib import Path
import contextlib
import importlib.util
import io
import json
import tempfile
import unittest
from unittest.mock import patch

from circrect.notebook import search


class NotebookTests(unittest.TestCase):
    def test_native_inputs_preview_and_domain_validation(self):
        with tempfile.TemporaryDirectory() as d:
            result = search(n=range(8, 13, 2), B=[4, 5], field="Fp", p=[3, 5],
                            output=Path(d) / "preview", dry_run=True)
            self.assertEqual(len(result.rows), 12)
            self.assertIn("Case preview", result._repr_html_())
            self.assertIsNone(result.witness())
            self.assertFalse(result.output.exists())
        for kwargs in ({"n": 9.5, "B": 4}, {"n": [], "B": 4},
                       {"n": 9, "B": 5, "field": "Fp"},
                       {"n": 9, "B": 4, "field": "F9"}):
            with self.assertRaises(ValueError):
                search(**kwargs, dry_run=True)

    def test_search_display_witness_and_resume(self):
        with tempfile.TemporaryDirectory() as d:
            result = search(n=[7, 9], B=4, field="F2", backend="brute", output=d)
            self.assertEqual(result.report["status"], "BATCH_COMPLETE")
            self.assertEqual([r["best_cost"] for r in result.rows], [11, 18])
            self.assertIn("Complete search, optimality proved", result._repr_html_())
            self.assertEqual(result.verify(1)["cost"], 18)
            repeated = search(n=[7, 9], B=4, backend="brute", output=d)
            self.assertTrue(all(r["action"] == "skipped_completed" for r in repeated.rows))

    @unittest.skipUnless(importlib.util.find_spec("IPython"), "Notebook execution needs IPython")
    def test_notebook_cells_execute_in_order(self):
        path = Path(__file__).resolve().parents[1] / "notebooks" / "C_rect_interactive.ipynb"
        notebook = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(notebook["nbformat"], 4)
        scope = {}
        with tempfile.TemporaryDirectory() as d, contextlib.redirect_stdout(io.StringIO()), \
                patch("IPython.display.display"):
            for index, cell in enumerate(notebook["cells"]):
                if cell["cell_type"] != "code":
                    continue
                exec(compile("".join(cell["source"]), f"{path.name}:cell{index}", "exec"), scope)
                if index == 2:  # Use a tiny real search to exercise every cell without a license.
                    scope.update(n=[7, 9], B=4, backend="brute", output=Path(d))
            self.assertEqual(scope["results"].report["status"], "BATCH_COMPLETE")
            self.assertEqual(scope["witness"]["cost"], 11)


if __name__ == "__main__":
    unittest.main()
