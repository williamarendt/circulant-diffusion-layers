import copy
from itertools import combinations, product
import json
from pathlib import Path
import sys
import tempfile
import unittest

from circrect.algebra import (canonical, circulant, inverse, lower_bound, matvec,
                              security, weight)
from circrect.packing import (available_backend, greedy, public_rectangle,
                              rectangles, solve)
from circrect.search import run_search
from circrect.witness import make_witness, verify

GUROBI = "--gurobi" in sys.argv
if GUROBI:
    sys.argv.remove("--gurobi")


def exhaustive_branch(m, p):
    return min(weight(x) + weight(matvec(m, x, p))
               for x in product(range(p), repeat=len(m)) if any(x))


def binary_gray_branch(m):
    """All 2^n-1 inputs; independently update output by Gray-code column flips."""
    n = len(m)
    cols = [sum(m[i][j] << i for i in range(n)) for j in range(n)]
    y, previous, best = 0, 0, 2 * n
    for t in range(1, 1 << n):
        x = t ^ (t >> 1)
        changed = x ^ previous
        y ^= cols[changed.bit_length() - 1]
        best = min(best, x.bit_count() + y.bit_count())
        previous = x
    return best


def direct_rectangles(m, p):
    """Independent reference: enumerate row/column subsets directly."""
    n = len(m)
    keys = set()
    for r in range(2, n + 1):
        for rows in combinations(range(n), r):
            for s in range(2, n + 1):
                for cols in combinations(range(n), s):
                    if not all(m[i][j] for i in rows for j in cols):
                        continue
                    if all((m[i][j] * m[rows[0]][cols[0]] -
                            m[i][cols[0]] * m[rows[0]][j]) % p == 0
                           for i in rows for j in cols):
                        keys.add((rows, cols))
    return keys


class CoreTests(unittest.TestCase):
    def test_candidate_completeness_including_subrectangles(self):
        for m, p in (([[1, 1, 1], [1, 1, 1], [1, 1, 0]], 2),
                     ([[1, -1, 1], [-1, 1, -1], [1, 1, 0]], 5)):
            m = [[x % p for x in row] for row in m]
            actual = {(tuple(r["rows"]), tuple(r["cols"])) for r in rectangles(m, p)}
            self.assertEqual(actual, direct_rectangles(m, p))

    def test_three_use_gain_and_corner_packing(self):
        m = [[1, 1, 1, 0], [1, 1, 1, 1], [1, 1, 0, 0]]
        items = rectangles(m, 2)
        three = next(r for r in items if r["rows"] == [0, 1, 2] and r["cols"] == [0, 1])
        self.assertEqual(three["gain"], 2)
        # The wider 2x3 candidate and each 2x2 proper subrectangle coexist in the model.
        sol = solve(items, "brute")
        self.assertTrue(sol["optimal"])
        self.assertEqual(sol["gain"], 2)  # baseline 6, C_rect 4, nested model would give 3
        for subset in combinations(range(len(items)), 2):
            a, b = (items[j] for j in subset)
            self.assertEqual(bool(a["mask"] & b["mask"]),
                             bool(set(a["rows"]) & set(b["rows"])) and
                             bool(set(a["cols"]) & set(b["cols"])))

    def test_binary_fast_security_against_all_inputs(self):
        for supp in combinations(range(7), 5):
            a = [int(i in supp) for i in range(7)]
            m = circulant(a, 2)
            actual = inverse(m, 2) is not None and exhaustive_branch(m, 2) >= 6
            self.assertEqual(security(a, 2, 6)["passed"], actual)

    def test_signed_security_and_general_fallback(self):
        for signs in product((1, -1), repeat=3):
            a = [1, *signs, 0]
            m = circulant(a, 3)
            actual = inverse(m, 3) is not None and exhaustive_branch(m, 3) >= 5
            self.assertEqual(security(a, 3, 5)["passed"], actual)
        # b=4, nonminimum k=5 must use the general check, not reject by B>=6 criteria.
        for p, a, b in ((2, [1, 1, 1, 1, 1, 0, 0], 4),
                        (3, [1, 1, 0, -1], 4), (2, [1, 1, 0, 1, 0, 0, 0], 6)):
            m = circulant(a, p)
            actual = inverse(m, p) is not None and exhaustive_branch(m, p) >= b
            self.assertEqual(security(a, p, b)["passed"], actual)

    def test_signed_canonical_invariance(self):
        a = [1, -1, 0, 1, 0, 0, -1]
        expected = canonical(a, 5)
        for u in range(1, 7):
            for shift in range(7):
                transformed = [0] * 7
                for j, v in enumerate(a):
                    transformed[(u * j + shift) % 7] = -v
                self.assertEqual(canonical(transformed, 5), expected)

    def test_n15_witness_and_tamper_rejection(self):
        a = [int(i in (0, 1, 2, 5, 10)) for i in range(15)]
        items = rectangles(circulant(a, 2), 2)
        chosen = greedy(items)
        w = make_witness(a, 2, 5, [public_rectangle(items[j]) for j in chosen], {})
        result = verify(w)
        self.assertEqual(result["cost"], 40)
        self.assertEqual(exhaustive_branch(circulant(a, 2), 2), 6)
        self.assertEqual(lower_bound(15, 5, 6)[0], 34)
        mutations = [lambda z: z["rectangles"].append(copy.deepcopy(z["rectangles"][0])),
                     lambda z: z["rectangles"][0]["beta"].__setitem__(0, -1),
                     lambda z: z["circuit"]["gates"][0].__setitem__("left", 999),
                     lambda z: z.__setitem__("cost", 39)]
        for mutate in mutations:
            bad = copy.deepcopy(w)
            mutate(bad)
            with self.assertRaises(AssertionError):
                verify(bad)

    def test_brute_packing_against_subset_enumeration(self):
        m = [[1, 1, 1], [1, 1, 0], [0, 1, 1]]
        items = rectangles(m, 2)
        expected = 0
        for flags in product((0, 1), repeat=len(items)):
            used, val, good = 0, 0, True
            for flag, item in zip(flags, items):
                if flag:
                    if used & item["mask"]:
                        good = False
                        break
                    used |= item["mask"]
                    val += item["gain"]
            if good:
                expected = max(expected, val)
        self.assertEqual(solve(items, "brute")["gain"], expected)

    def test_search_resume_and_fixed_weight_scope(self):
        config = {"model": "C_rect", "field": "f2", "prime": 2, "n": 9,
                  "branch_min": 4, "effective_branch_target": 4, "weight": 3,
                  "connected_only": False, "mode": "exact"}
        with tempfile.TemporaryDirectory() as d:
            first = run_search(config, "brute", None, d, seed_known=False, max_candidates=1)
            self.assertTrue(first["status"].startswith("INCOMPLETE"))
            final = run_search(config, "brute", None, d, resume=True, seed_known=False)
            self.assertEqual(final["status"], "GLOBAL_OPTIMUM")
            self.assertEqual(final["best_cost"], 18)
            w = json.loads((Path(d) / "best_witness.json").read_text(encoding="utf-8"))
            self.assertTrue(verify(w)["valid"])
            changed = dict(config, connected_only=True)
            with self.assertRaises(ValueError):
                run_search(changed, "brute", None, d, resume=True)
        with tempfile.TemporaryDirectory() as d:
            result = run_search(dict(config, weight=2), "brute", None, d)
            self.assertEqual(result["status"], "NO_FEASIBLE_FIXED_WEIGHT")


@unittest.skipUnless(GUROBI, "pass --gurobi to run licensed backend regressions")
class GurobiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.backend, cls.env, _ = available_backend("gurobi")

    @classmethod
    def tearDownClass(cls):
        cls.env.dispose()

    def test_tiny_against_brute(self):
        for m, p in (([[1, 1, 1], [1, 1, 0], [0, 1, 1]], 2),
                     ([[1, 4, 1], [4, 1, 4], [1, 1, 0]], 5)):
            items = rectangles(m, p)
            self.assertEqual(solve(items, "gurobi", self.env)["gain"], solve(items, "brute")["gain"])

    def test_n15_rectangle40_pair45(self):
        a = [int(i in (0, 1, 2, 5, 10)) for i in range(15)]
        for max_cols, cost in ((3, 40), (2, 45)):
            items = rectangles(circulant(a, 2), 2, max_rows=3, max_cols=max_cols)
            sol = solve(items, "gurobi", self.env, time_limit=30)
            self.assertTrue(sol["optimal"])
            self.assertEqual(60 - sol["gain"], cost)

    def test_signed_known_seeds_including_repeated_roots(self):
        for p in (3, 5):
            for n in (9, 11, 12):
                d = {0: 1, 1: 1, 3: 1, 4: 1} if n != 12 else {0: 1, 1: 1, 2: 1, 7: -1}
                a = [d.get(i, 0) for i in range(n)]
                self.assertTrue(security(a, p, 5)["passed"])
                items = rectangles(circulant(a, p), p, max_rows=2, max_cols=2)
                sol = solve(items, "gurobi", self.env, time_limit=30)
                w = make_witness(a, p, 5, [public_rectangle(items[j]) for j in sol["selected"]], {})
                self.assertEqual(verify(w)["cost"], 2 * n)

    def test_n15_global_search_against_full_input_security(self):
        # Independent complete support enumeration, without fixing 0 in the support.
        keys = set()
        for supp in combinations(range(15), 5):
            keys.add(canonical([int(i in supp) for i in range(15)], 2))
        self.assertEqual(len(keys), 34)
        costs = []
        for key in sorted(keys):
            a = [0] * 15
            for j, v in key:
                a[j] = v
            m = circulant(a, 2)
            # Exact rank + all 32767 inputs, rather than the fast overlap criterion.
            reference = inverse(m, 2) is not None and binary_gray_branch(m) >= 6
            self.assertEqual(security(a, 2, 6)["passed"], reference)
            if reference:
                all_items = rectangles(m, 2)  # No branch-derived dimension cap.
                sol = solve(all_items, "gurobi", self.env)
                self.assertTrue(sol["optimal"])
                costs.append(60 - sol["gain"])
        self.assertTrue(costs)
        self.assertEqual(min(costs), 40)


if __name__ == "__main__":
    unittest.main()
