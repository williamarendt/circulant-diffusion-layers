import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from circrect.cli import main
from circrect.closed_form import odd_weight3_parameters, odd_weight3_witness
from circrect.notebook import search
from circrect.search import run_search
from circrect.witness import verify
from tests.test_circrect import binary_gray_branch
from circrect.algebra import circulant
from circrect.packing import rectangles, solve


def config(n, **overrides):
    c = {"model": "C_rect", "field": "f2", "prime": 2, "n": n, "branch_min": 4,
         "effective_branch_target": 4, "weight": 3, "connected_only": False, "mode": "exact"}
    return dict(c, **overrides)


class ClosedFormTests(unittest.TestCase):
    def test_explicit_witness_cost_rank_and_branch(self):
        for n in (5, 7, 11, 15, 21, 35, 45, 63, 135):
            c = config(n)
            proof = odd_weight3_parameters(c)
            witness = odd_weight3_witness(c, proof)
            self.assertEqual(verify(witness)["cost"], (3 * n + proof["g"]) // 2)
            self.assertEqual(len(witness["rectangles"]), (n - proof["g"]) // 2)
            self.assertEqual(witness["support_components"], proof["g"])
            if n <= 15:
                self.assertEqual(binary_gray_branch(circulant(witness["generator"], 2)), 4)
                items = rectangles(circulant(witness["generator"], 2), 2)
                self.assertEqual(2 * n - solve(items, "brute")["gain"], witness["cost"])

    def test_scope_excludes_other_models_and_disconnected_restriction(self):
        self.assertIsNotNone(odd_weight3_parameters(config(7, connected_only=True)))
        for c in (config(9), config(27), config(16), config(15, connected_only=True),
                  config(15, weight=5, branch_min=5, effective_branch_target=6),
                  config(15, prime=3, field="fp")):
            self.assertIsNone(odd_weight3_parameters(c))

    def test_notebook_and_cli_never_initialize_solver(self):
        with tempfile.TemporaryDirectory() as d, contextlib.redirect_stdout(io.StringIO()), \
                patch("circrect.batch.available_backend", side_effect=AssertionError("license probe")), \
                patch("circrect.search.solve", side_effect=AssertionError("MILP called")):
            result = search(n=[15, 21, 45], B=4, field="F2", backend="gurobi", output=d)
            self.assertEqual([r["best_cost"] for r in result.rows], [24, 33, 72])
            self.assertTrue(all(r["status"] == "THEOREM_OPTIMUM" for r in result.rows))
            self.assertIn("Theorem construction", result._repr_html_())
            self.assertEqual(result.verify(0)["cost"], 24)
            report = json.loads((Path(result.rows[0]["directory"]) / "report.json").read_text())
            self.assertEqual(report["attempted_this_run"], 0)
            self.assertFalse(report["enumeration_complete"])
            report_path = Path(result.rows[0]["directory"]) / "report.json"
            report["status"] = "GLOBAL_OPTIMUM"
            report_path.write_text(json.dumps(report), encoding="utf-8")
            again = search(n=[15, 21, 45], B=4, output=d)
            self.assertEqual(again.rows[0]["action"], "resumed")
            self.assertEqual(again.rows[0]["status"], "THEOREM_OPTIMUM")
            self.assertTrue(all(r["action"] == "skipped_completed" for r in again.rows[1:]))
        with tempfile.TemporaryDirectory() as d, contextlib.redirect_stdout(io.StringIO()), \
                patch("circrect.cli.available_backend", side_effect=AssertionError("license probe")):
            self.assertEqual(main(["search", "--field", "f2", "--n", "15", "--branch-min", "4",
                                   "--backend", "gurobi", "--output", d]), 0)

    def test_resume_older_checkpoint_upgrades_bound(self):
        with tempfile.TemporaryDirectory() as d, contextlib.redirect_stdout(io.StringIO()):
            c = config(15)
            w = odd_weight3_witness(c, odd_weight3_parameters(c))
            old = {"format": "circrect-checkpoint-v1", "config": c, "best": w,
                   "enumeration_complete": True, "elapsed_seconds": 0,
                   "records": {"old": {"feasible": True, "cost": 24, "cost_lower_bound": 23}}}
            (Path(d) / "checkpoint.json").write_text(json.dumps(old), encoding="utf-8")
            report = run_search(c, "gurobi", None, d, resume=True)
            self.assertEqual(report["status"], "THEOREM_OPTIMUM")
            self.assertEqual(report["global_lower_bound"], 24)
            self.assertEqual(report["unresolved_matrices"], 0)


if __name__ == "__main__":
    unittest.main()
