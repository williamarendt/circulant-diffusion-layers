"""Research-model regression tests."""
