import contextlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from circrect.notebook import search
from circrect.scope import normalize_config, same_scope, scope_difference
from circrect.search import run_search


class ScopeTests(unittest.TestCase):
    def test_only_none_and_false_are_equivalent(self):
        c = {"connected_only": False, "prime": 5, "n": 32}
        self.assertTrue(same_scope(c, dict(c, connected_only=None)))
        self.assertFalse(same_scope(c, dict(c, connected_only=True)))
        self.assertFalse(same_scope(c, dict(c, prime=7)))
        self.assertEqual(scope_difference(c, dict(c, n=64)), {"n": {"stored": 32, "requested": 64}})
        with self.assertRaises(ValueError):
            normalize_config(dict(c, connected_only="False"))

    def test_notebook_reuses_false_checkpoint_with_none_without_solver(self):
        with tempfile.TemporaryDirectory() as d, contextlib.redirect_stdout(io.StringIO()):
            first = search(n=9, B=4, backend="brute", connected_only=False, output=d)
            folder = Path(first.rows[0]["directory"])
            original = {name: (folder / name).read_bytes() for name in ("checkpoint.json", "report.json", "best_witness.json")}
            with patch("circrect.batch.available_backend", side_effect=AssertionError("solver initialized")):
                repeated = search(n=9, B=4, connected_only=None, output=d)
            self.assertEqual(repeated.rows[0]["action"], "skipped_completed")
            self.assertEqual(repeated.rows[0]["best_cost"], 18)
            for name, data in original.items():
                self.assertEqual((folder / name).read_bytes(), data)

    def test_legacy_none_checkpoint_and_report_reused_and_resume_normalizes(self):
        with tempfile.TemporaryDirectory() as d, contextlib.redirect_stdout(io.StringIO()):
            result = search(n=9, B=4, backend="brute", output=d)
            folder = Path(result.rows[0]["directory"])
            for filename in ("checkpoint.json", "report.json", "best_witness.json"):
                path = folder / filename
                x = json.loads(path.read_text(encoding="utf-8"))
                if "config" in x:
                    x["config"]["connected_only"] = None
                if x.get("best"):
                    x["best"]["connected_only"] = None
                if "connected_only" in x:
                    x["connected_only"] = None
                path.write_text(json.dumps(x), encoding="utf-8")
            with patch("circrect.batch.available_backend", side_effect=AssertionError("solver initialized")):
                repeated = search(n=9, B=4, connected_only=False, output=d)
            self.assertEqual(repeated.rows[0]["action"], "skipped_completed")
            state = json.loads((folder / "checkpoint.json").read_text(encoding="utf-8"))
            c = dict(state["config"], connected_only=False)
            report = run_search(c, "brute", None, folder, resume=True)
            self.assertEqual(report["status"], "GLOBAL_OPTIMUM")
            state = json.loads((folder / "checkpoint.json").read_text(encoding="utf-8"))
            self.assertIs(state["config"]["connected_only"], False)
            self.assertIs(state["best"]["connected_only"], False)
            self.assertTrue(same_scope(state["config"], c))


if __name__ == "__main__":
    unittest.main()
