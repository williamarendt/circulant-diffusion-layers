from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from circrect.storage import atomic_write_text, output_lock


class StorageTests(unittest.TestCase):
    def test_transient_windows_replace_error_retries_without_losing_original(self):
        import os
        real_replace = os.replace
        attempts = []
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "checkpoint.json"
            path.write_text("old", encoding="utf-8")

            def replace(source, target):
                attempts.append(source)
                if len(attempts) < 3:
                    self.assertEqual(path.read_text(), "old")
                    error = PermissionError("simulated Windows sharing denial")
                    error.winerror = 5
                    raise error
                real_replace(source, target)

            with patch("circrect.storage.os.replace", side_effect=replace), patch("circrect.storage.time.sleep"):
                atomic_write_text(path, "new")
            self.assertEqual(path.read_text(), "new")
            self.assertEqual(len(attempts), 3)
            self.assertEqual(len(set(attempts)), 1)
            atomic_write_text(path, "next")
            self.assertEqual(list(Path(d).glob("*.tmp")), [])

    def test_permanent_denial_preserves_old_and_recoverable_temporary(self):
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "checkpoint.json"
            path.write_text("old", encoding="utf-8")
            with patch("circrect.storage.os.replace", side_effect=PermissionError("permanent")):
                with self.assertRaisesRegex(OSError, "recoverable temporary"):
                    atomic_write_text(path, "new")
            self.assertEqual(path.read_text(), "old")
            temporaries = list(Path(d).glob("*.tmp"))
            self.assertEqual(len(temporaries), 1)
            self.assertEqual(temporaries[0].read_text(), "new")

    def test_same_output_rejects_second_writer_and_lock_releases(self):
        with tempfile.TemporaryDirectory() as d:
            with output_lock(d):
                with self.assertRaisesRegex(RuntimeError, "another search"):
                    with output_lock(d):
                        self.fail("second writer acquired lock")
            with output_lock(d):
                pass


if __name__ == "__main__":
    unittest.main()
