"""Section presets for the existing shared Gurobi batch-search implementation."""
import argparse
from pathlib import Path
from bundle_paths import section_dir, setup_imports


def main(section, field, branch, weight):
    parser = argparse.ArgumentParser(description=f'Section {section}: Gurobi rectangle search')
    parser.add_argument('--n-values', required=True, help='Orders, e.g. 8,12,16 or 4:16')
    parser.add_argument('--primes', default='3,5,7,11', help='Used only over odd prime fields')
    parser.add_argument('--seconds', type=float, default=60)
    parser.add_argument('--connected-only', action='store_true')
    parser.add_argument('--output', type=Path, default=section_dir(section)/'results'/'repeat_gurobi')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    setup_imports()
    from circrect.cli import main as cli_main
    command = ['batch', '--field', field, '--branch-values', str(branch),
               '--weight', str(weight), '--n-values', args.n_values, '--backend', 'gurobi',
               '--time-limit-per-case', str(args.seconds), '--output', str(args.output)]
    if field == 'fp':
        command += ['--primes', args.primes]
    if args.connected_only:
        command += ['--connected-only']
    if args.dry_run:
        command += ['--dry-run']
    return cli_main(command)
