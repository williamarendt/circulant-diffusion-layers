# Shared Code

- `circrect/`: finite-field and circulant-matrix operations, branch number screening, complete rectangle enumeration, Gurobi packing, persistence, and gate-by-gate circuit verification. Reused across sections.
- `bundle_paths.py`: section paths and imports between sections. The supplementary odd-prime SciPy searches reuse `solve_scipy` from the binary small-order script instead of maintaining duplicate implementations.
- `gurobi_entry.py`: argument handling for each section's `run_gurobi.py`, without changing the underlying search algorithm.
- `notebooks/`: the two original Gurobi notebooks for searches over multiple parameter values. The small-order weight-five notebook is in `sec3.2.2_F2_B6_w5`.
- `tests/`: the existing tests. From this directory, run `python -m unittest tests.test_circrect tests.test_closed_form tests.test_notebook tests.test_storage`.
- `original_batch_metadata/`: summary metadata for the original 156 cases spanning multiple sections. Individual reports and witnesses are stored in each section's `results/gurobi/`.
- `requirements-gurobi.txt`, `requirements-scipy.txt`: dependencies grouped by solver.
- `check_bundle.py`: checks collected-file hashes and syntax without starting a solver.
- `index_records.py`: regenerates historical solver statistics from section results and writes `../docs/solver_inventory.json`.

Section 2 uses these shared methods and basic checks; it has no separate experiment. Sections 5 and 6 introduce no independent experiments.
