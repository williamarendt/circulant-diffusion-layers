"""Solver-independent witness construction and validation."""
import heapq
from .algebra import circulant, components, security, weight


def circuit(m, rects, p):
    n = len(m)
    gates, depths = [], [0] * n
    terms = [[] for _ in range(n)]
    occupied = set()

    def merge(inputs, owner):
        heap = [(depths[s], j, s, c) for j, (s, c) in enumerate(inputs)]
        heapq.heapify(heap)
        counter = len(heap)
        while len(heap) > 1:
            d1, _, s1, c1 = heapq.heappop(heap)
            d2, _, s2, c2 = heapq.heappop(heap)
            signal = n + len(gates)
            depth = max(d1, d2) + 1
            gates.append({"out": signal, "left": s1, "left_sign": c1,
                          "right": s2, "right_sign": c2, "owner": owner})
            depths.append(depth)
            heapq.heappush(heap, (depth, counter, signal, 1))
            counter += 1
        _, _, s, c = heap[0]
        return s, c

    for q, rect in enumerate(rects):
        shared, sign = merge(list(zip(rect["cols"], rect["beta"])), f"rectangle:{q}")
        for i, alpha in zip(rect["rows"], rect["alpha"]):
            terms[i].append((shared, alpha * sign))
            for j in rect["cols"]:
                occupied.add((i, j))
    outputs = []
    for i, row in enumerate(m):
        for j, v in enumerate(row):
            if v and (i, j) not in occupied:
                terms[i].append((j, 1 if v == 1 else -1))
        s, c = merge(terms[i], f"output:{i}")
        outputs.append({"signal": s, "sign": c})
    return {"gates": gates, "outputs": outputs, "gate_count": len(gates),
            "depth": max(depths[o["signal"]] for o in outputs)}


def make_witness(a, p, b, rects, solver, *, connected_only=False):
    m = circulant(a, p)
    c0 = len(a) * (weight(a) - 1)
    return {"format": "circrect-witness-v1", "model": "C_rect",
            "field": "f2" if p == 2 else "fp", "prime": p, "n": len(a),
            "generator": list(a), "weight": weight(a), "branch_min": b,
            "connected_only": connected_only, "support_components": components(a),
            "direct_cost": c0, "cost": c0 - sum(r["gain"] for r in rects),
            "rectangles": rects, "circuit": circuit(m, rects, p), "solver": solver}


def verify(w, deadline=None):
    """Recheck field, security, corner packing, private trees and every coefficient."""
    if not __debug__:
        raise RuntimeError("witness validation requires assertions enabled; do not use python -O")
    from .algebra import prime
    assert w["format"] == "circrect-witness-v1" and w["model"] == "C_rect", "format"
    p, a, n = w["prime"], w["generator"], w["n"]
    assert type(p) is int and prime(p), "prime field"
    assert n == len(a) and n > 0, "dimension"
    assert w["field"] == ("f2" if p == 2 else "fp"), "field label"
    allowed = (0, 1) if p == 2 else (-1, 0, 1)
    assert all(type(v) is int and v in allowed for v in a), "generator coefficients"
    assert w["weight"] == weight(a) and weight(a) > 0, "weight"
    assert type(w["branch_min"]) is int and w["branch_min"] >= 4, "branch target"
    b = w["branch_min"]
    if p == 2:
        b += b % 2
    sec = security(a, p, b, deadline)
    assert sec["passed"], f"security: {sec}"
    assert components(a) == w["support_components"], "components"
    assert not w["connected_only"] or components(a) == 1, "connected-only"
    m = circulant(a, p)
    occupied = set()
    saving = 0
    for r in w["rectangles"]:
        rows, cols = r["rows"], r["cols"]
        assert len(rows) >= 2 and len(cols) >= 2, "rectangle dimensions"
        assert len(set(rows)) == len(rows) and len(set(cols)) == len(cols), "duplicates"
        assert all(type(i) is int and 0 <= i < n for i in rows + cols), "indices"
        assert len(r["alpha"]) == len(rows) and len(r["beta"]) == len(cols), "sign lengths"
        assert all(type(v) is int and v in (-1, 1) for v in r["alpha"] + r["beta"]), "signs"
        if p == 2:
            assert all(v == 1 for v in r["alpha"] + r["beta"]), "binary signs"
        for i, alpha in zip(rows, r["alpha"]):
            for j, beta in zip(cols, r["beta"]):
                assert m[i][j] and m[i][j] == alpha * beta % p, "rank-one coefficients"
                assert (i, j) not in occupied, "overlapping corners"
                occupied.add((i, j))
        gain = (len(rows) - 1) * (len(cols) - 1)
        assert r["gain"] == gain, "gain"
        saving += gain
    expected = circuit(m, w["rectangles"], p)
    assert w["circuit"] == expected, "private rectangle/output trees"
    signals = [[int(i == j) for j in range(n)] for i in range(n)]
    depths = [0] * n
    for gate in expected["gates"]:
        u, v = gate["left"], gate["right"]
        assert 0 <= u < len(signals) and 0 <= v < len(signals), "gate order"
        signals.append([(gate["left_sign"] * x + gate["right_sign"] * y) % p
                        for x, y in zip(signals[u], signals[v])])
        depths.append(max(depths[u], depths[v]) + 1)
    for row, out in zip(m, expected["outputs"]):
        assert row == [out["sign"] * v % p for v in signals[out["signal"]]], "output coefficients"
    c0 = n * (weight(a) - 1)
    assert w["direct_cost"] == c0, "baseline"
    assert w["cost"] == c0 - saving == expected["gate_count"], "gate cost"
    return {"valid": True, "cost": w["cost"], "depth": expected["depth"], "security": sec}
