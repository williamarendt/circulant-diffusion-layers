"""Sequential parameter grids with a shared solver environment and resumable cases."""
import csv
import io
import json
from pathlib import Path
import time

from .algebra import prime
from .packing import available_backend
from .search import run_search, write_json
from .witness import verify
from .closed_form import odd_weight3_parameters
from .storage import atomic_write_text, output_lock
from .scope import normalize_config, same_scope, scope_difference


COMPLETE = {"TARGET_ATTAINED", "GLOBAL_OPTIMUM", "THEOREM_OPTIMUM", "NO_FEASIBLE_FIXED_WEIGHT"}


def integers(spec, minimum=1):
    """Comma-separated integers or inclusive start:stop[:step] ranges."""
    result = []
    for token in spec.split(","):
        parts = [int(v.strip()) for v in token.strip().split(":")]
        if len(parts) == 1:
            values = parts
        elif len(parts) in (2, 3):
            start, stop = parts[:2]
            step = parts[2] if len(parts) == 3 else 1
            if step < 1 or start > stop:
                raise ValueError("ranges require start <= stop and positive step")
            values = range(start, stop + 1, step)
        else:
            raise ValueError("use comma-separated values or inclusive start:stop[:step] ranges")
        for v in values:
            if v < minimum:
                raise ValueError(f"values must be >= {minimum}")
            if v not in result:
                result.append(v)
    return result


def cases(args):
    ns = integers(args.n_values)
    bs = integers(args.branch_values, 4)
    if args.field == "f2":
        if args.primes is not None:
            raise ValueError("--primes is only used with --field fp")
        primes = [2]
    else:
        if args.primes is None:
            raise ValueError("--field fp requires --primes, e.g. --primes 3,5,7")
        primes = integers(args.primes, 3)
        if not all(prime(p) and p % 2 for p in primes):
            raise ValueError("--primes must contain odd primes")
    jobs = []
    for p in primes:
        for requested_b in bs:
            b = requested_b + (requested_b % 2 if p == 2 else 0)
            k = args.weight if args.weight is not None else b - 1
            for n in ns:
                config = normalize_config({"model": "C_rect", "field": args.field, "prime": p, "n": n,
                          "branch_min": requested_b, "effective_branch_target": b,
                          "weight": k, "connected_only": args.connected_only, "mode": "exact"})
                name = f"{args.field}_p{p}_B{requested_b}_n{n}_k{k}"
                if args.connected_only:
                    name += "_connected"
                jobs.append({"name": name, "config": config})
    return jobs


def run_batch(args):
    if args.dry_run:
        return _run_batch(args)
    with output_lock(args.output):
        return _run_batch(args)


def _run_batch(args):
    jobs = cases(args)
    if args.weight is not None and args.weight < 1:
        raise ValueError("weight must be positive")
    if args.threads < 1 or args.seed < 0:
        raise ValueError("threads must be positive; seed must be nonnegative")
    for key in ("time_limit_per_case", "time_limit_total", "time_limit_per_matrix", "max_candidates"):
        value = getattr(args, key)
        if value is not None and value <= 0:
            raise ValueError(f"{key} must be positive")
    if args.dry_run:
        return {"status": "DRY_RUN", "case_count": len(jobs), "cases": jobs}
    root = Path(args.output)
    # Validate every existing checkpoint before any solver or case execution.
    for job in jobs:
        cp = root / job["name"] / "checkpoint.json"
        if cp.exists():
            stored = json.loads(cp.read_text(encoding="utf-8"))["config"]
            if not same_scope(stored, job["config"]):
                raise ValueError(f"checkpoint scope mismatch: {cp}; differences: {scope_difference(stored, job['config'])}")
    root.mkdir(parents=True, exist_ok=True)
    write_json(root / "plan.json", {"cases": jobs, "time_limit_per_case": args.time_limit_per_case})
    rows = []
    for job in jobs:
        config = job["config"]
        rows.append({"case": job["name"], "field": config["field"], "prime": config["prime"],
                     "B_requested": config["branch_min"], "B_effective": config["effective_branch_target"],
                     "n": config["n"], "weight": config["weight"], "status": "PENDING",
                     "lower_bound": None, "best_cost": None, "seconds_this_run": 0,
                     "action": "pending", "error": "", "directory": str(root / job["name"])})

    def save():
        write_json(root / "summary.json", rows)
        stream = io.StringIO(newline="")
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
        target = root / "summary.csv"
        atomic_write_text(target, stream.getvalue(), encoding="utf-8-sig")

    save()
    env = None
    interrupted = False
    errors = []
    try:
        backend = None
        started = time.monotonic()
        for i, (job, row) in enumerate(zip(jobs, rows)):
            remaining = None if args.time_limit_total is None else args.time_limit_total - (time.monotonic() - started)
            if remaining is not None and remaining <= 0:
                break
            folder = root / job["name"]
            cp = folder / "checkpoint.json"
            report_path = folder / "report.json"
            print(f"[{i + 1}/{len(jobs)}] {job['name']}", flush=True)
            previous = None
            try:
                previous = json.loads(report_path.read_text(encoding="utf-8")) if report_path.exists() else None
                # A completed report is usable only with the matching checkpoint.
                done = cp.exists() and previous and previous.get("config") and same_scope(previous["config"], job["config"]) and previous.get("status") in COMPLETE
                if done and odd_weight3_parameters(job["config"]) and previous["status"] != "THEOREM_OPTIMUM":
                    done = False  # Upgrade older search results to the explicit theorem construction.
                if done:
                    state = json.loads(cp.read_text(encoding="utf-8"))
                    if state.get("best") is not None:
                        verify(state["best"])
                    report = previous
                    row["action"] = "skipped_completed"
                else:
                    if odd_weight3_parameters(job["config"]):
                        case_backend = "closed_form"
                    else:
                        if backend is None:
                            init_started = time.monotonic()
                            try:
                                backend, env, fallback = available_backend(args.backend)
                            finally:
                                started += time.monotonic() - init_started
                            if fallback:
                                print(json.dumps({"backend_fallback": fallback, "selected": backend}), flush=True)
                        case_backend = backend
                    row["action"] = "resumed" if cp.exists() else "started"
                    budget = args.time_limit_per_case
                    if remaining is not None:
                        budget = min(budget, remaining)
                    report = run_search(job["config"], case_backend, env, folder, cp.exists(),
                                        budget, args.time_limit_per_matrix, args.threads,
                                        args.seed, args.seed_known, args.max_candidates, args.export_model)
                    row["seconds_this_run"] = report["seconds_this_run"]
                row.update(status=report["status"], lower_bound=report["global_lower_bound"],
                           best_cost=report["best_cost"])
                print(f"  {row['status']}: lower={row['lower_bound']}, best={row['best_cost']}", flush=True)
                if report.get("interrupted"):
                    interrupted = True
                    break
            except Exception as e:
                row.update(status="ERROR", error=str(e))
                # A save error must not hide a witness already persisted by this case.
                try:
                    recovery = json.loads(cp.read_text(encoding="utf-8"))
                    if recovery.get("best"):
                        row["best_cost"] = recovery["best"]["cost"]
                    if previous and previous.get("config") and same_scope(previous["config"], job["config"]):
                        row["lower_bound"] = previous.get("global_lower_bound")
                except (OSError, ValueError, KeyError):
                    pass
                errors.append({"case": job["name"], "error": str(e)})
                print(f"  ERROR: {e}", flush=True)
            finally:
                save()
    except KeyboardInterrupt:
        interrupted = True
    finally:
        save()
        if env is not None:
            env.dispose()
    complete = sum(r["status"] in COMPLETE for r in rows)
    result = {"status": "BATCH_COMPLETE" if complete == len(jobs) else "BATCH_INCOMPLETE",
              "case_count": len(jobs), "completed_cases": complete,
              "pending_cases": sum(r["status"] == "PENDING" for r in rows),
              "interrupted": interrupted, "errors": errors,
              "summary_csv": str(root / "summary.csv"), "summary_json": str(root / "summary.json")}
    write_json(root / "batch_report.json", result)
    return result
