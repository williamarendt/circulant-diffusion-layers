"""Exact single-layer rectangle reuse for scalar circulant linear layers."""

__version__ = "1.0.0"
