"""User-proved exact minimum for odd-order binary weight-three circulants."""
from .algebra import check_time
from .witness import make_witness


def odd_weight3_parameters(config):
    """Return theorem parameters only when its entire scope is satisfied."""
    if (config["prime"] != 2 or config["field"] != "f2" or config["weight"] != 3
            or config["effective_branch_target"] != 4 or config["n"] % 2 == 0):
        return None
    n = config["n"]
    a, g, t = 0, 1, n
    while t > 0 and t % 3 == 0:
        a, g, t = a + 1, g * 3, t // 3
    if t <= 1 or (config["connected_only"] and g != 1):
        return None
    return {"name": "binary_odd_weight3_exact_minimum", "model": "C_rect",
            "a": a, "g": g, "t": t, "minimum": (3 * n + g) // 2,
            "formula": "(3*n + 3**a)/2", "support": [0, g, 2 * g],
            "basis": "user-supplied structural classification and explicit attaining construction"}


def odd_weight3_witness(config, proof, deadline=None):
    """One maximum matching per odd row cycle yields corner-disjoint 2x2s."""
    n, g, t = config["n"], proof["g"], proof["t"]
    row = [int(j in (0, g, 2 * g)) for j in range(n)]
    rects = []
    for residue in range(g):
        check_time(deadline)
        for j in range(0, t - 1, 2):
            i = residue + j * g
            rects.append({"rows": [i, (i + g) % n],
                          "cols": [(i + g) % n, (i + 2 * g) % n],
                          "alpha": [1, 1], "beta": [1, 1], "gain": 1})
    saving = (n - g) // 2
    solver = {"backend": "closed_form", "status": "THEOREM_OPTIMUM", "optimal": True,
              "gain": saving, "gain_upper_bound": saving, "milp_used": False}
    witness = make_witness(row, 2, config["branch_min"], rects, solver,
                           connected_only=config["connected_only"])
    if witness["cost"] != proof["minimum"]:
        raise RuntimeError("theorem construction does not attain the claimed cost")
    witness["optimality_proof"] = proof
    return witness
