"""Canonical search scope, including legacy null connectivity flags."""


def normalize_config(config):
    result = dict(config)
    flag = result["connected_only"]
    if flag is not None and type(flag) is not bool:
        raise ValueError("connected_only must be True, False or None (None means unrestricted)")
    result["connected_only"] = flag is True
    return result


def same_scope(left, right):
    return normalize_config(left) == normalize_config(right)


def scope_difference(left, right):
    left, right = normalize_config(left), normalize_config(right)
    return {key: {"stored": left.get(key), "requested": right.get(key)}
            for key in sorted(left.keys() | right.keys()) if left.get(key) != right.get(key)}
