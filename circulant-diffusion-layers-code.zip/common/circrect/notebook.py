"""Notebook-facing API: native Python inputs, automatic resume and rich results."""
from dataclasses import dataclass
from html import escape
import json
from numbers import Integral
from pathlib import Path
from types import SimpleNamespace

from .batch import run_batch
from .witness import verify


def _values(values, name):
    if isinstance(values, str):
        return values
    if isinstance(values, Integral) and not isinstance(values, bool):
        return str(int(values))
    try:
        items = list(values)
    except TypeError:
        raise ValueError(f"{name} must be an integer, a list/range, or a range string") from None
    if not items or any(not isinstance(v, Integral) or isinstance(v, bool) for v in items):
        raise ValueError(f"{name} must contain integers")
    return ",".join(str(int(v)) for v in items)


STATUS = {
    "PENDING": "Not run yet", "PLANNED": "Preview",
    "THEOREM_OPTIMUM": "Theorem construction, C_rect optimality proved",
    "TARGET_ATTAINED": "Lower bound attained, optimality proved", "GLOBAL_OPTIMUM": "Complete search, optimality proved",
    "NO_FEASIBLE_FIXED_WEIGHT": "No feasible matrix at the fixed weight",
    "INCOMPLETE_WITH_WITNESS": "Incomplete, witness available", "INCOMPLETE_NO_WITNESS": "Incomplete, no witness yet",
    "ERROR": "Error",
}


@dataclass
class SearchResult:
    """Rich notebook output; raw records, paths and witnesses remain accessible."""
    report: dict
    rows: list
    output: Path

    @property
    def table(self):
        """A pandas DataFrame when available; otherwise a list of dictionaries."""
        try:
            import pandas as pd
        except ImportError:
            return self.rows
        return pd.DataFrame(self.rows)

    def witness(self, index=0):
        """Load the witness for a zero-based result row, or return None."""
        row = self.rows[index]
        if row["status"] in ("PENDING", "PLANNED", "ERROR") or row.get("best_cost") is None:
            return None
        path = Path(row["directory"]) / "best_witness.json"
        return json.loads(path.read_text(encoding="utf-8"))

    def verify(self, index=0):
        witness = self.witness(index)
        if witness is None:
            raise ValueError("this row has no witness yet")
        return verify(witness)

    def _repr_html_(self):
        fields = [("field", "Field"), ("prime", "p"), ("B_requested", "Requested B"),
                  ("B_effective", "Effective B"), ("n", "n"), ("weight", "Weight k"),
                  ("lower_bound", "Lower bound"), ("best_cost", "Best C_rect"),
                  ("status", "Status"), ("seconds_this_run", "Seconds this run")]
        heading = "Case preview" if self.report["status"] == "DRY_RUN" else "Search results"
        parts = [f"<div><strong>{heading}: {len(self.rows)} cases</strong>",
                 "<table><thead><tr><th>Index</th>"]
        parts.extend(f"<th>{label}</th>" for _, label in fields)
        parts.append("</tr></thead><tbody>")
        for index, row in enumerate(self.rows):
            parts.append(f"<tr><td>{index}</td>")
            for key, _ in fields:
                value = row.get(key)
                if key == "status":
                    value = STATUS.get(value, value)
                elif key == "seconds_this_run" and value is not None:
                    value = f"{value:.2f}"
                parts.append(f"<td>{escape('—' if value is None else str(value))}</td>")
            parts.append("</tr>")
        parts.append("</tbody></table>")
        if self.report["status"] != "DRY_RUN":
            parts.append(f"<p>Saved to: <code>{escape(str(self.output))}</code>; rerun the search cell to resume.</p>")
        errors = [row for row in self.rows if row.get("error")]
        for row in errors:
            parts.append(f"<p>{escape(row['case'])}: {escape(row['error'])}</p>")
        parts.append("</div>")
        return "".join(parts)


def search(n, B, field="F2", p=None, *, time_limit=60, total_time_limit=None,
           per_matrix_time_limit=None, output="runs/notebook", backend="gurobi",
           threads=1, seed=0, weight=None, connected_only=False, seed_known=True,
           max_candidates=None, export_model=False, dry_run=False):
    """Search one case or a Cartesian grid directly from a notebook cell.

    n, B, and (for Fp) p accept integers, lists, ranges, or 'start:stop:step'.
    time_limit is the budget per case in seconds. Repeated calls resume unfinished
    cases and skip completed cases in the same output directory.
    """
    field = str(field).lower().replace("_", "")
    if field not in ("f2", "fp"):
        raise ValueError('field must be "F2" or "Fp"')
    if field == "fp" and p is None:
        raise ValueError('field="Fp" requires p, e.g. p=3 or p=[3,5,7]')
    if backend not in ("gurobi", "cpsat", "brute", "auto"):
        raise ValueError("unknown backend")
    root = Path(output).expanduser().resolve()
    args = SimpleNamespace(field=field, primes=_values(p, "p") if field == "fp" else None,
                           n_values=_values(n, "n"), branch_values=_values(B, "B"),
                           weight=weight, connected_only=connected_only, backend=backend,
                           time_limit_per_case=time_limit, time_limit_total=total_time_limit,
                           time_limit_per_matrix=per_matrix_time_limit, max_candidates=max_candidates,
                           threads=threads, seed=seed, seed_known=seed_known, export_model=export_model,
                           output=str(root), dry_run=dry_run)
    report = run_batch(args)
    if dry_run:
        rows = []
        for job in report["cases"]:
            c = job["config"]
            rows.append({"case": job["name"], "field": c["field"], "prime": c["prime"],
                         "B_requested": c["branch_min"], "B_effective": c["effective_branch_target"],
                         "n": c["n"], "weight": c["weight"], "status": "PLANNED",
                         "lower_bound": None, "best_cost": None, "seconds_this_run": None,
                         "directory": str(root / job["name"])})
    else:
        rows = json.loads((root / "summary.json").read_text(encoding="utf-8"))
    return SearchResult(report=report, rows=rows, output=root)
