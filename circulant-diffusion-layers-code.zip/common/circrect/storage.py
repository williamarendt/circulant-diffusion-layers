"""Atomic saves tolerant of brief Windows sharing locks; one writer per directory."""
from contextlib import contextmanager
import os
from pathlib import Path
import tempfile
import time


def atomic_write_text(path, content, encoding="utf-8"):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    # Each save owns its temporary file, even if another process is misconfigured.
    with tempfile.NamedTemporaryFile(mode="w", encoding=encoding, newline="",
                                     dir=path.parent, prefix=f".{path.name}.",
                                     suffix=".tmp", delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(content)
        stream.flush()
    for attempt in range(9):
        try:
            os.replace(temporary, path)
            return
        except PermissionError as error:
            # Windows antivirus/indexers/readers may briefly deny atomic replacement.
            if getattr(error, "winerror", None) not in (5, 32, 33) or attempt == 8:
                raise OSError(f"Cannot save {path}; recoverable temporary file: {temporary}. {error}") from error
            time.sleep(min(0.02 * 2 ** attempt, 0.5))
    raise AssertionError("unreachable")


@contextmanager
def output_lock(directory):
    """OS lock releases on process exit; the small lock file can remain on disk."""
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    stream = (directory / ".circrect.lock").open("a+b")
    try:
        if os.fstat(stream.fileno()).st_size == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            raise RuntimeError(f"The result directory is in use by another search or cannot be locked: {directory}. Stop searches using this directory in other kernels, or choose a different output directory.") from error
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == "nt":
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
    finally:
        stream.close()
