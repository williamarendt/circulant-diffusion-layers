"""Complete rectangle generation and weighted position packing."""
from collections import defaultdict
from itertools import combinations
import math
import time

from .algebra import check_time


def rectangles(m, p, max_rows=None, max_cols=None, deadline=None):
    """Include every subrectangle, grouping signed rows modulo global negation."""
    groups = defaultdict(list)
    for i, row in enumerate(m):
        support = [j for j, v in enumerate(row) if v]
        for s in range(2, min(len(support), max_cols or len(support)) + 1):
            for cols in combinations(support, s):
                check_time(deadline)
                alpha = row[cols[0]]
                beta = tuple(row[j] * pow(alpha, -1, p) % p for j in cols)
                if any(v not in (1, p - 1) for v in beta):
                    continue
                groups[(cols, beta)].append((i, 1 if alpha == 1 else -1))
    result = []
    n = len(m[0])
    for (cols, beta), rows in sorted(groups.items()):
        for r in range(2, min(len(rows), max_rows or len(rows)) + 1):
            for chosen in combinations(rows, r):
                check_time(deadline)
                rr = [i for i, _ in chosen]
                mask = sum(1 << (i * n + j) for i in rr for j in cols)
                result.append({"rows": rr, "cols": list(cols),
                               "alpha": [v for _, v in chosen],
                               "beta": [1 if v == 1 else -1 for v in beta],
                               "gain": (r - 1) * (len(cols) - 1), "mask": mask})
    return result


def greedy(items):
    used, chosen = 0, []
    for j in sorted(range(len(items)), key=lambda j: (-items[j]["gain"], items[j]["mask"].bit_count(), j)):
        if not used & items[j]["mask"]:
            chosen.append(j)
            used |= items[j]["mask"]
    return chosen


def public_rectangle(r):
    return {k: v for k, v in r.items() if k != "mask"}


def available_backend(name):
    errors = []
    choices = ("gurobi", "cpsat", "brute") if name == "auto" else (name,)
    for choice in choices:
        env = None
        try:
            if choice == "gurobi":
                import gurobipy as gp
                # Silence license initialization output, including credential labels.
                env = gp.Env(empty=True)
                env.setParam("OutputFlag", 0)
                env.start()
                probe = gp.Model(env=env)
                x = probe.addVar(vtype=gp.GRB.BINARY)
                probe.setObjective(x, gp.GRB.MAXIMIZE)
                probe.optimize()
                if probe.Status != gp.GRB.OPTIMAL:
                    raise RuntimeError("license probe did not solve")
                probe.dispose()
                return choice, env, errors
            if choice == "cpsat":
                from ortools.sat.python import cp_model
                return choice, None, errors
            return choice, None, errors
        except Exception as e:
            if env is not None:
                env.dispose()
            errors.append({"backend": choice, "error": str(e)})
            if name != "auto":
                raise
    raise RuntimeError(str(errors))


def solve(items, backend, env=None, time_limit=None, threads=1, seed=0,
          deadline=None, model_path=None):
    started = time.monotonic()
    warm = greedy(items)
    incumbent = sum(items[j]["gain"] for j in warm)
    bound = sum(r["gain"] for r in items)
    if not items:
        return {"selected": [], "gain": 0, "gain_upper_bound": 0, "optimal": True,
                "status": "OPTIMAL", "backend": backend, "seconds": 0}
    local_deadline = deadline
    if time_limit is not None:
        local_deadline = min(deadline or math.inf, started + time_limit)
    remaining = None if local_deadline is None else max(0, local_deadline - time.monotonic())
    if remaining is not None and remaining <= 0:
        return {"selected": warm, "gain": incumbent, "gain_upper_bound": bound,
                "optimal": False, "status": "TIME_LIMIT", "backend": backend, "seconds": 0}
    positions = defaultdict(list)
    for j, rect in enumerate(items):
        for i in rect["rows"]:
            for c in rect["cols"]:
                positions[(i, c)].append(j)
    version = "stdlib"
    if backend == "gurobi":
        import gurobipy as gp
        m = gp.Model("C_rect_position_packing", env=env)
        m.Params.OutputFlag = 0
        m.Params.Threads = threads
        m.Params.Seed = seed
        m.Params.MIPGap = 0
        m.Params.MIPGapAbs = 0
        m.Params.IntFeasTol = 1e-9
        if remaining is not None:
            m.Params.TimeLimit = remaining
        x = m.addVars(len(items), vtype=gp.GRB.BINARY, name="rect")
        for js in positions.values():
            m.addConstr(gp.quicksum(x[j] for j in js) <= 1)
        m.setObjective(gp.quicksum(rect["gain"] * x[j] for j, rect in enumerate(items)), gp.GRB.MAXIMIZE)
        warmset = set(warm)
        for j in range(len(items)):
            x[j].Start = int(j in warmset)
        if model_path:
            m.write(str(model_path))
        m.optimize()
        if m.SolCount and m.ObjVal >= incumbent - 1e-6:
            warm = [j for j in range(len(items)) if x[j].X > 0.5]
            incumbent = sum(items[j]["gain"] for j in warm)
        if math.isfinite(m.ObjBound):
            bound = max(incumbent, math.floor(m.ObjBound + 1e-6))
        optimal = m.Status == gp.GRB.OPTIMAL or bound == incumbent
        status = {2: "OPTIMAL", 9: "TIME_LIMIT", 11: "INTERRUPTED"}.get(m.Status, str(m.Status))
        version = ".".join(map(str, gp.gurobi.version()))
        m.dispose()
    elif backend == "cpsat":
        import ortools
        from ortools.sat.python import cp_model
        m = cp_model.CpModel()
        x = [m.new_bool_var(f"rect_{j}") for j in range(len(items))]
        for js in positions.values():
            m.add(sum(x[j] for j in js) <= 1)
        m.maximize(sum(r["gain"] * x[j] for j, r in enumerate(items)))
        warmset = set(warm)
        for j, v in enumerate(x):
            m.add_hint(v, int(j in warmset))
        if model_path:
            m.export_to_file(str(model_path) + ".pbtxt")
        solver = cp_model.CpSolver()
        solver.parameters.num_search_workers = threads
        solver.parameters.random_seed = seed
        if remaining is not None:
            solver.parameters.max_time_in_seconds = remaining
        state = solver.solve(m)
        status = solver.status_name(state)
        if state in (cp_model.OPTIMAL, cp_model.FEASIBLE):
            warm = [j for j, xj in enumerate(x) if solver.value(xj)]
            incumbent = sum(items[j]["gain"] for j in warm)
        if state in (cp_model.OPTIMAL, cp_model.FEASIBLE, cp_model.UNKNOWN):
            # A zero UNKNOWN bound is not used unless a feasible solution exists.
            if solver.best_objective_bound >= incumbent:
                bound = math.floor(solver.best_objective_bound + 1e-6)
        optimal = state == cp_model.OPTIMAL or bound == incumbent
        version = ortools.__version__
    else:
        # Independent exact branch and bound; suitable only for tiny instances.
        order = sorted(range(len(items)), key=lambda j: -items[j]["gain"])
        suffix = [0] * (len(order) + 1)
        for t in range(len(order) - 1, -1, -1):
            suffix[t] = suffix[t + 1] + items[order[t]]["gain"]
        stack = [(0, 0, 0, [])]
        interrupted = False
        while stack:
            if local_deadline is not None and time.monotonic() >= local_deadline:
                interrupted = True
                break
            t, used, value, selected = stack.pop()
            if value + suffix[t] <= incumbent:
                continue
            if t == len(order):
                if value > incumbent:
                    incumbent, warm = value, selected
                continue
            j = order[t]
            stack.append((t + 1, used, value, selected))
            if not used & items[j]["mask"]:
                nv = value + items[j]["gain"]
                ns = selected + [j]
                if nv > incumbent:
                    incumbent, warm = nv, ns
                stack.append((t + 1, used | items[j]["mask"], nv, ns))
        optimal = not interrupted
        bound = incumbent if optimal else bound
        status = "OPTIMAL" if optimal else "TIME_LIMIT"
    return {"selected": warm, "gain": incumbent, "gain_upper_bound": bound,
            "optimal": optimal, "status": status, "backend": backend,
            "version": version, "seconds": time.monotonic() - started,
            "threads": threads, "seed": seed, "mip_gap": 0,
            "int_feas_tol": 1e-9 if backend == "gurobi" else None}
