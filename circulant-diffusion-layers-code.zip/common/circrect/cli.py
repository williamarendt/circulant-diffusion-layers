import argparse
import json
from pathlib import Path
import sys
import time

from .algebra import (BudgetExpired, circulant, prime, security, weight)
from .packing import available_backend, rectangles, solve, public_rectangle
from .search import run_search, write_json
from .witness import make_witness, verify


def parser():
    ap = argparse.ArgumentParser(description="Exact C_rect optimization (single-layer corner-disjoint signed rectangles)")
    sub = ap.add_subparsers(dest="command", required=True)
    for name in ("search", "optimize"):
        q = sub.add_parser(name)
        q.add_argument("--field", choices=("f2", "fp"), required=True)
        q.add_argument("--prime", type=int)
        q.add_argument("--branch-min", type=int, default=5)
        q.add_argument("--backend", choices=("auto", "gurobi", "cpsat", "brute"), default="auto")
        q.add_argument("--time-limit-total", type=float)
        q.add_argument("--time-limit-per-matrix", type=float)
        q.add_argument("--threads", type=int, default=1)
        q.add_argument("--seed", type=int, default=0)
        q.add_argument("--output", default=f"runs/{name}")
        q.add_argument("--export-model", action="store_true")
        q.add_argument("--connected-only", action="store_true")
        if name == "search":
            q.add_argument("--n", type=int, required=True)
            q.add_argument("--weight", type=int)
            q.add_argument("--resume", action="store_true")
            q.add_argument("--seed-known", action=argparse.BooleanOptionalAction, default=True)
            q.add_argument("--max-candidates", type=int,
                           help="maximum newly processed canonical matrices in this run (honest incomplete result)")
        else:
            q.add_argument("--row", required=True, help="comma-separated full generator, e.g. 1,1,0,-1")
            q.add_argument("--pair-only", action="store_true", help="restrict to two columns for C_pair comparison")
    q = sub.add_parser("batch", help="run a resumable grid of branch targets and dimensions")
    q.add_argument("--field", choices=("f2", "fp"), required=True)
    q.add_argument("--primes", help="odd primes, e.g. 3,5,7 (fp only)")
    q.add_argument("--n-values", required=True, help="e.g. 8:32:2,40,48; inclusive ranges")
    q.add_argument("--branch-values", required=True, help="e.g. 4,6,8 or 4:10")
    q.add_argument("--weight", type=int)
    q.add_argument("--backend", choices=("auto", "gurobi", "cpsat", "brute"), default="gurobi")
    q.add_argument("--time-limit-per-case", type=float, default=60)
    q.add_argument("--time-limit-total", type=float)
    q.add_argument("--time-limit-per-matrix", type=float)
    q.add_argument("--max-candidates", type=int)
    q.add_argument("--threads", type=int, default=1)
    q.add_argument("--seed", type=int, default=0)
    q.add_argument("--seed-known", action=argparse.BooleanOptionalAction, default=True)
    q.add_argument("--connected-only", action="store_true")
    q.add_argument("--export-model", action="store_true")
    q.add_argument("--output", default="runs/batch")
    q.add_argument("--dry-run", action="store_true", help="preview cases without initializing a solver")
    q = sub.add_parser("verify", help="independent verification without solver imports")
    q.add_argument("witness")
    q = sub.add_parser("doctor", help="check actual backend and license usability")
    q.add_argument("--backend", choices=("auto", "gurobi", "cpsat", "brute"), default="auto")
    return ap


def main(argv=None):
    args = parser().parse_args(argv)
    env = None
    try:
        if args.command == "batch":
            from .batch import run_batch
            result = run_batch(args)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 1 if result.get("errors") else 0
        if args.command == "verify":
            w = json.loads(Path(args.witness).read_text(encoding="utf-8"))
            print(json.dumps(verify(w), ensure_ascii=False, indent=2))
            return 0
        if args.command == "doctor":
            backend, env, errors = available_backend(args.backend)
            print(json.dumps({"python": sys.version, "executable": sys.executable,
                              "backend": backend, "fallback_reasons": errors}, indent=2))
            return 0
        p = 2 if args.field == "f2" else args.prime
        if p is None or not prime(p) or (args.field == "fp" and p == 2):
            raise ValueError("--field fp requires an odd prime --prime")
        if args.field == "f2" and args.prime not in (None, 2):
            raise ValueError("f2 requires prime 2")
        if args.branch_min < 4:
            raise ValueError("--branch-min must be >= 4")
        if args.threads < 1 or args.seed < 0:
            raise ValueError("threads must be positive; seed must be nonnegative")
        for name in ("time_limit_total", "time_limit_per_matrix"):
            value = getattr(args, name)
            if value is not None and value <= 0:
                raise ValueError(f"{name} must be positive")
        if args.command == "search" and (args.n < 1 or (args.weight is not None and args.weight < 1)):
            raise ValueError("n and weight must be positive")
        if args.command == "search" and args.max_candidates is not None and args.max_candidates < 1:
            raise ValueError("--max-candidates must be positive")
        started = time.monotonic()
        b = args.branch_min + (args.branch_min % 2 if p == 2 else 0)
        config = None
        if args.command == "search":
            config = {"model": "C_rect", "field": args.field, "prime": p, "n": args.n,
                      "branch_min": args.branch_min, "effective_branch_target": b,
                      "weight": args.weight if args.weight is not None else b - 1,
                      "connected_only": args.connected_only, "mode": "exact"}
        from .closed_form import odd_weight3_parameters
        if config and odd_weight3_parameters(config):
            backend, errors = "closed_form", []
        else:
            backend, env, errors = available_backend(args.backend)
        if errors:
            print(json.dumps({"backend_fallback": errors, "selected": backend}), file=sys.stderr)
        if args.command == "search":
            result = run_search(config, backend, env, args.output, args.resume,
                                args.time_limit_total, args.time_limit_per_matrix,
                                args.threads, args.seed, args.seed_known,
                                args.max_candidates, args.export_model)
        else:
            a = [int(v.strip()) for v in args.row.split(",")]
            allowed = (0, 1) if p == 2 else (-1, 0, 1)
            if not a or any(v not in allowed for v in a) or weight(a) == 0:
                raise ValueError("row must contain legal coefficients and be nonzero")
            if args.connected_only:
                from .algebra import components
                if components(a) != 1:
                    raise ValueError("generator excluded by --connected-only")
            deadline = None if args.time_limit_total is None else started + args.time_limit_total
            sec = security(a, p, b, deadline)
            if not sec["passed"]:
                result = {"status": "MATRIX_REJECTED", "security": sec}
                write_json(Path(args.output) / "report.json", result)
                print(json.dumps(result, ensure_ascii=False, indent=2))
                return 1
            cap = min(weight(a) - 1, weight(a) + 1 - (b + 1) // 2)
            items = rectangles(circulant(a, p), p, max_rows=cap,
                               max_cols=min(cap, 2) if args.pair_only else cap, deadline=deadline)
            output = Path(args.output)
            output.mkdir(parents=True, exist_ok=True)
            sol = solve(items, backend, env, args.time_limit_per_matrix, args.threads,
                        args.seed, deadline, output / "model.lp" if args.export_model else None)
            info = {k: v for k, v in sol.items() if k != "selected"}
            w = make_witness(a, p, args.branch_min,
                             [public_rectangle(items[j]) for j in sol["selected"]], info,
                             connected_only=args.connected_only)
            verify(w)  # Always finish independent validation before publishing a witness.
            write_json(output / "best_witness.json", w)
            result = {"status": "FIXED_MATRIX_OPTIMUM" if sol["optimal"] else "INCOMPLETE_WITH_WITNESS",
                      "optimization_scope": "C_pair" if args.pair_only else "C_rect",
                      "cost": w["cost"], "cost_lower_bound": w["direct_cost"] - sol["gain_upper_bound"],
                      "candidate_count": len(items), "solver": info,
                      "security": sec, "depth": w["circuit"]["depth"]}
            write_json(output / "report.json", result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except BudgetExpired:
        result = {"status": "INCOMPLETE_NO_WITNESS", "reason": "time budget during safety/candidate enumeration"}
        if hasattr(args, "output"):
            write_json(Path(args.output) / "report.json", result)
        print(json.dumps(result))
        return 2
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1
    finally:
        if env is not None:
            env.dispose()
