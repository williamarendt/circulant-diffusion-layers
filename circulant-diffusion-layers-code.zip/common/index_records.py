"""Summarize saved solver metadata; this does not solve or modify experiments."""
from collections import Counter
import json
from pathlib import Path

from bundle_paths import ROOT, section_dir


def solver_labels(value):
    if isinstance(value, dict):
        for key, child in value.items():
            if key == 'backend':
                yield str(child)
            yield from solver_labels(child)
    elif isinstance(value, list):
        for child in value:
            yield from solver_labels(child)


def build_inventory():
    result = dict(date='2026-11-09',
                  note='Counts refer to saved metadata occurrences, not solver invocations.',
                  datasets=[])
    datasets = [(section, 'gurobi') for section in ('3.1.4','3.2.2','4.1.4','4.2.4','4.3.2')]
    datasets += [('3.2.2','weight5_f2_n_le16_20261105'),
                 ('3.2.2','weight5_family_comparison_20261105'),
                 ('4.3.2','odd_weight5_remaining_20261107'),
                 ('4.3.2','odd_weight5_power_two_20261107'),
                 ('3.2.2','weight5_depth3_20261105')]
    for section, name in datasets:
        sections = [section]
        folder = section_dir(section) / 'results' / name
        reports = list(folder.rglob('report.json'))
        witness = list(folder.rglob('best_witness.json'))
        order_records = list(folder.glob('n[0-9]*.json'))
        def count(paths):
            return dict(Counter(label for path in paths for label in
                                solver_labels(json.loads(path.read_text(encoding='utf-8')))))
        result['datasets'].append(dict(folder=folder.relative_to(ROOT).as_posix(),
                                       sections=sections, report_files=len(reports),
                                       report_metadata=count(reports),
                                       best_witness_files=len(witness),
                                       best_witness_metadata=count(witness),
                                       order_record_files=len(order_records),
                                       order_record_metadata=count(order_records)))
    binary = section_dir('3.2.2').relative_to(ROOT).as_posix() + '/'
    odd = section_dir('4.3.2').relative_to(ROOT).as_posix() + '/'
    result['scipy_milp_direct'] = [binary+'search_weight5_small.py:solve_scipy',
                                  binary+'compare_weight5_families.py:solve_packing',
                                  binary+'auxiliary/search_weight5_depth3.py:search (different task)']
    result['scipy_milp_indirect'] = [binary+'refine_weight5_comparison.py',
                                    odd+'run_odd_weight5_remaining.py',
                                    odd+'run_odd_weight5_power_two.py', odd+'signed_packing_cache.py']
    result['scipy_continuous_lp_only'] = [binary+'auxiliary/classify_weight5_symbolic.py',
                                         binary+'auxiliary/investigate_core_optimality.py']
    result['component_bounds_no_milp'] = [odd+'refine_odd_weight5_power_two.py']
    return result


if __name__ == '__main__':
    inventory = build_inventory()
    (ROOT / 'docs' / 'solver_inventory.json').write_text(
        json.dumps(inventory, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    for dataset in inventory['datasets']:
        print(json.dumps(dataset, ensure_ascii=False))
