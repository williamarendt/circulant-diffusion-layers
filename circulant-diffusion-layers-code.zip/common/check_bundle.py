"""Check collected source integrity and syntax without running any solver."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def check():
    manifest = json.loads((ROOT / 'docs' / 'source_manifest.json').read_text(encoding='utf-8'))
    changed = []
    for record in manifest['files']:
        path = ROOT / record['destination']
        if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest() != record['bundle_sha256']:
            changed.append(record['destination'])
    if changed:
        raise AssertionError(f'Missing or changed collected files: {changed}')
    python_files = list(ROOT.rglob('*.py'))
    for path in python_files:
        ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path))
    cells = 0
    for path in ROOT.rglob('*.ipynb'):
        notebook = json.loads(path.read_text(encoding='utf-8'))
        for cell in notebook['cells']:
            if cell.get('cell_type') == 'code':
                assert not cell.get('outputs') and cell.get('execution_count') is None
                source = ''.join(cell.get('source', []))
                ast.parse(source, filename=path.name)
                assert "Path(r'E:\\LinearLayers')" not in source
                cells += 1
    # Local dependency closure: no user-specific path or external checkout is needed.
    from bundle_paths import setup_imports, section_dir
    setup_imports()
    for name in ('algebra.py', 'packing.py', 'search.py', 'witness.py'):
        assert (ROOT / 'common' / 'circrect' / name).is_file(), name
    assert (section_dir('4.2.4') / 'verify_section42.py').is_file()
    assert (section_dir('3.2.2') / 'search_weight5_small.py').is_file()
    assert (section_dir('4.3.2') / 'signed_packing_cache.py').is_file()
    forbidden = [p for p in ROOT.rglob('*') if p.is_file() and
                 (p.suffix.lower() == '.lic' or p.name == '.env')]
    assert not forbidden, forbidden
    result = dict(collected_files=len(manifest['files']),
                  python_files_parsed=len(python_files),
                  notebook_code_cells_parsed=cells,
                  source_hashes_valid=True, solvers_started=False)
    print(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    check()
