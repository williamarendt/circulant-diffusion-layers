# Provenance and Solver Records

- `source_manifest.json`: original source hashes and current section-based paths. Import adaptations, result-path changes, notebook cleanup, and English translation are recorded. The original workspace files were not modified.
- `english_translation_manifest.json`: hashes of files before and after translation, including documentation and display-message changes. Numerical result fields and solver status codes are unchanged; the Windows error text in three recovery metadata files is translated.
- `solver_inventory.json`: saved solver labels grouped by section and batch. Counts refer to metadata records, not the number of actual solver invocations.
- `archive_provenance.json`: hashes of the two earlier scalar-experiment archives and paths to the extracted source snapshots. These hashes describe the original archive contents; translated files are tracked separately in the English translation manifest.

Earlier organization notes are retained in `../historical/organization_v1/` as historical documentation, not current usage instructions. Use the root and section READMEs for the current entry points.
