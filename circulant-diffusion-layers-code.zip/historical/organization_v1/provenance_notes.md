# Provenance and Historical Versions

Historical organization note, translated into English. Paths below describe the earlier bundle layout; use the root README for the current layout.

Current modules and supplementary scripts were copied from `E:/LinearLayers`; per-file sources are recorded in `source_manifest.json`. Source files were neither moved nor rewritten. Notebook copies had outputs and execution counts cleared and absolute paths back to the original workspace removed. Distinct source and bundle hashes were recorded.

Source snapshots from two earlier archives were stored separately:

| Historical source | Source location in the earlier bundle |
|---|---|
| `experiments_for_gpt/C_rect_experiments_156cases_2026-10-22.zip` | `historical_sources/initial_156cases/` |
| `experiments_for_gpt/F2_B6_k5_n32_n64_2026-10-22.zip` | `historical_sources/binary_weight5_32_64/` |

Only Python files, READMEs, and dependency lists from `source_snapshot` were extracted, avoiding duplication of all old results. Archive and extracted-file hashes are in `archive_provenance.json` and `source_manifest.json`. Historical directories are excluded from runtime module search paths; normal entry points use the current `circrect/` package (now under `common/`). English translation hashes are tracked separately in `../../docs/english_translation_manifest.json`.

Section mapping was based on:

- The weight-three classification, weight-five structural reductions, finite-order results, and supplementary certificates in the original research notes `circulant_branch_4_5_20261013 (2).tex`.
- Sections 3.1.4, 3.2.2, 4.1.4, 4.2.4, and 4.3.2 of the current paper.
- `Paper/handoff.md` records of the original Gurobi batches, binary small-order and reduced supplementary searches on 2026-11-05, and odd-prime supplementary and order-32/64 searches on 2026-11-07.

The standalone files `verify_explicit_families.py` and `search_binary_b6.py` mentioned in the original notes were not found and were not reconstructed as if they were originals. Available verification scripts, shared implementations of equivalent tasks, and actual checkpoints are included; the READMEs distinguish their purposes.

Saved "global optimum" statements retain the scope of each record: field, order, weight, branch number, and connectivity. Earlier order-64 outer-search reports retain their incomplete status. Subsequent structural reductions and candidate lower bounds establish optimality without changing the completion flag of that earlier run.

Organization checks covered file integrity, syntax, local dependencies, existing basic tests, and a few saved witnesses. Exhaustive enumeration and solver experiments over the paper's matrix classes were not rerun.
