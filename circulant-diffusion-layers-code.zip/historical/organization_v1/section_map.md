# Paper 1 Code and Local Experimental Records

**Historical layout note:** this document describes the organization on 2026-11-09, before the section-based layout. In that layout, source code, notebooks, and `runs/` were rooted at `../experiments/`, notebooks were in its `notebooks/` directory, statistics and manifests were in `docs/`, and earlier source snapshots were in `../historical/`. For current usage, see the [root README](../../README.md).

This bundle accompanies Paper 1, `circulant_linear_layers.tex`. It excludes Paper 2's QARMA, YuX, and general block-circulant code.

It was assembled from copies of existing code and evidence, without changing originals, rerunning experiments, or replacing all solvers. `source_manifest.json` records sources and SHA-256 hashes. Notebook outputs and absolute paths back to `E:\LinearLayers` were removed. Python sources were originally retained unchanged; English text was subsequently translated in the GitHub preparation copy, as recorded in `docs/english_translation_manifest.json`.

## Locating code by section (historical paths)

| Paper section | Main entry points | Tasks and evidence |
|---|---|---|
| 2.2–2.3 | `circrect/algebra.py`, `packing.py`, `witness.py`; `tests/` | Shared finite fields, supports, branch numbers, rectangle enumeration, packing, circuits, and verification. Analytical Section 2 bounds do not depend on an optimization run. |
| 3.1.1–3.1.4, former Appendix A.1 | `Paper/verify_weight_three_appendix.py` | Enumerates weight-three supports; checks analytical formulas using exact gcd and maximum matching; verifies nine-gate circuits and lifts. See `Paper/weight_three_verification/`. Requires neither SciPy nor Gurobi. |
| 3.2.1 | `Paper/verify_section32.py` | Support classification, overlaps, constructions, and local certificates; standard-library exact backtracking at order 12 and audit of the original order-64 checkpoint. Not a SciPy integer program. |
| 3.2.2, small orders | `search_weight5_small.py`; `weight5_small_search.ipynb` | Binary weight five, orders 1–16: complete affine classification, branch number cross-checks, and optimal rectangle packing. See `runs/weight5_f2_n_le16_20261105/`. Recorded solver: SciPy/HiGHS. |
| 3.2.2, larger orders | `circrect/`, `C_rect_interactive_v2.ipynb`; `compare_weight5_families.py`, `refine_weight5_comparison.py` | Original Gurobi results in `runs/notebook/` plus structurally reduced supplementary evidence. The latter scripts use SciPy packing; see `runs/weight5_family_comparison_20261105/`. Additional orders not in the paper are retained and should not all be treated as main-table results. |
| 4.1.1–4.1.4 | `Paper/verify_section41.py` | Sign/support classification, maximum matching, attaining constructions, and characteristic-three examples; `runs/odd_weight3_theorem/` and `Paper/section41_verification.json`. Section 4.1.4 optimality is analytical, not dependent on integer programming. |
| 4.2.1–4.2.3 | `Paper/verify_section42.py` | Finite checks of branch number criteria, local conditions, complete rectangle covers, constructions, and depth results; no integer programming solver. |
| 4.2.4, finite optima | `circrect/`, `C_rect_interactive_v2.ipynb` | Original Gurobi rectangle packing in `runs/notebook/fp_p*_B5_*/`; `Paper/audit_section424.py` checks saved optimum records and witnesses. |
| 4.2.4, attainability of 2n | `complete_cover`, `exclusion_audit` in `Paper/audit_section424.py` | Enumerates row pairings, propagates cover constraints, and checks rank. A complete-cover existence check, not a SciPy integer program. |
| 4.3.2, original parameters | `circrect/`, `C_rect_interactive_v2.ipynb` | `runs/notebook/fp_p*_B6_*/`; recorded solver: Gurobi. |
| 4.3.2, supplementary small orders | `run_odd_weight5_remaining.py` | 48 SciPy cases: p=3,5,7,11; n=1–6,9,12–16. See `runs/odd_weight5_remaining_20261107/`. |
| 4.3.2, orders 32/64 | `run_odd_weight5_power_two.py`, `signed_packing_cache.py`, `refine_odd_weight5_power_two.py` | Eight structurally reduced searches, SciPy packing, caching of identical integer problems, and component lower bounds; `runs/odd_weight5_power_two_20261107/`. |
| 4.3.2, result audit | `Paper/audit_section43_records.py` | Audits 88 reports and 62 feasible witnesses, and regenerates large-order candidates. Checks saved evidence without resolving integer programs. |
| 5 | Shared code and entry points above | Methods description; no new independent experiment. |
| 6 | None | Conclusions; no independent experiment. |

The earlier layout retained a nested `Paper/` directory to support imports such as `from Paper.verify_section42 import ...` and existing relative paths. The entire `code1/` directory was the independent project root. The current distribution instead adapts imports through `common/bundle_paths.py`.

## Integer programs using SciPy

1. **`search_weight5_small.py::solve_scipy`** calls `scipy.optimize.milp` for optimal rectangle packing, supporting the complete small-order binary search in Section 3.2.2. It also supports `--backend gurobi`, but the saved batch used SciPy.
2. **`compare_weight5_families.py::solve_packing`** calls `milp` with additional valid inequalities for reduced larger-order supplementary searches in Section 3.2.2. `refine_weight5_comparison.py` refines through this function; some steps only propagate component results.
3. **`run_odd_weight5_remaining.py`** invokes item 1 through `scipy_adapter` for supplementary small-order cases in Section 4.3.2.
4. **`run_odd_weight5_power_two.py`** invokes item 1 through `signed_packing_cache.py` and the adapter for order-32/64 cases in Section 4.3.2. Cache hits do not resolve the problem.

`refine_odd_weight5_power_two.py` only propagates known component lower bounds; **it does not invoke SciPy integer programming**.

Historical auxiliary code has different purposes from the rectangle minima in the main tables:

- `search_weight5_depth3.py` uses SciPy **integer programming** for restricted depth-three general XOR circuits; see `runs/weight5_depth3_20261105/`. It is not rectangle packing and does not prove optimality among all general circuits. Related counterexamples were kept separately in drafts.
- `classify_weight5_symbolic.py` and `investigate_core_optimality.py` use `scipy.optimize.linprog` to discover rational certificates: **continuous LP, not integer programming**.
- `verify_core_optimality_certificate.py` independently checks certificates using exact rationals without an optimizer. `generate_core_optimality_appendix.py` generates historical proof tables. These supplement the research notes and are not the solvers for the current main tables.

Historical solver statistics are in `solver_inventory.json`. Counts refer to reports/metadata, not solver invocations. Some earlier cases terminate via formulas or infeasibility screening.

## Original usage

The original local environment used Windows Python 3.13, Gurobi for earlier batches, and SciPy 1.16.2 for later supplementary runs. Dependencies were separated into `requirements-gurobi.txt` and `requirements-scipy.txt`. Collection did not install dependencies or probe/consume a Gurobi license.

The following commands describe the earlier layout and are retained for provenance. For current runnable paths, follow the root and section READMEs.

```powershell
Set-Location E:\LinearLayers\Paper\code1
$paper1Python = 'C:\Users\dell\AppData\Local\Programs\Python\Python313\python.exe'

# Check hashes, Python/notebook syntax, and relative paths without experiments.
& $paper1Python -X utf8 check_bundle.py

# Existing basic tests, without initializing Gurobi by default.
& $paper1Python -X utf8 -m unittest tests.test_circrect tests.test_closed_form

# Verify a saved witness without starting an optimizer.
& $paper1Python -X utf8 -m circrect verify runs/notebook/f2_p2_B6_n16_k5/best_witness.json

# Search again in a new directory to preserve historical evidence.
& $paper1Python -X utf8 -m circrect search --field fp --prime 5 --n 8 --weight 4 --branch-min 5 --backend gurobi --output runs/repeat_gurobi/fp5_n8

# Likewise use a new output directory for a fresh SciPy run.
& $paper1Python -X utf8 search_weight5_small.py --min-n 10 --max-n 10 --backend scipy --out runs/repeat_scipy/f2_n10
```

Open notebooks from the project directory. `C_rect_interactive.ipynb` and `C_rect_interactive_v2.ipynb` are the original Gurobi interfaces; `weight5_small_search.ipynb` defaults to loading saved small-order SciPy results. Inspect verification scripts before execution: some regenerate audit JSON files, and some historical scripts use fixed output paths.

## Completeness and remaining organization notes

- Collection retains incomplete search statuses and actual solver identities; SciPy records are not relabeled as Gurobi records.
- Both solvers actually used, Gurobi and HiGHS, are retained. `search_weight5_small.py` supports Gurobi, but saved solver fields keep their original values.
- The standalone `verify_explicit_families.py` and `search_binary_b6.py` mentioned in the notes were not found in the workspace or either scalar-experiment archive. Available `Paper/verify_section*.py`, shared modules, and batch snapshots are included; missing original files are not fabricated.
- Archived `source_snapshot/circrect` versions may differ from the current shared package. Two earlier snapshots were stored under `historical_sources/`; original ZIP files are in the workspace's `experiments_for_gpt/`. See `provenance_notes.md` and `archive_provenance.json` for versions and hashes.
- No Gurobi license, key, or environment credentials were included. No Git repository was created or published; "online" in the manuscript remained a placeholder.
