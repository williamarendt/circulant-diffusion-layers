"""Exhaustive affine-orbit search, persistent candidate bounds and honest statuses."""
from itertools import combinations, product
import json
from pathlib import Path
import time

from .algebra import (BudgetExpired, canonical, check_time, circulant, components,
                      lower_bound, security)
from .packing import rectangles, solve, public_rectangle
from .witness import make_witness, verify
from .closed_form import odd_weight3_parameters, odd_weight3_witness
from .storage import atomic_write_text, output_lock


def write_json(path, data):
    atomic_write_text(path, json.dumps(data, indent=2, ensure_ascii=False))


def seeds(n, p, k, b):
    rows = []
    if p == 2 and k == 5 and b == 6:
        if n % 3 == 0 and n // 3 >= 5 and n // 3 % 3:
            rows.append({0: 1, 1: 1, 2: 1, n // 3: 1, 2 * n // 3: 1})
        if n % 4 == 0 and n >= 16 and n % 3:
            rows.append({0: 1, 1: 1, 2: 1, 3: 1, n // 2: 1})
    if p != 2 and k == 4 and b == 5:
        if n % 2 and n >= 9:
            rows.append({0: 1, 1: 1, 3: 1, 4: 1})
        if n % 8 == 4 and n >= 12:
            rows.append({0: 1, 1: 1, 2: 1, n // 2 + 1: -1})
        step, odd = 1, n
        while odd % 2 == 0:
            step, odd = step * 2, odd // 2
        if step > 1 and odd >= 9:
            rows.append({0: 1, step: 1, 3 * step: 1, 4 * step: 1})
    for d in rows:
        yield [d.get(j, 0) for j in range(n)]


def generators(n, k, p, deadline):
    # Translation and global negation make a[0]=1 lossless.
    for tail in combinations(range(1, n), k - 1):
        for signs in product((1,) if p == 2 else (1, -1), repeat=k - 1):
            check_time(deadline)
            a = [0] * n
            a[0] = 1
            for j, s in zip(tail, signs):
                a[j] = s
            yield a


def run_search(config, backend, env, output, resume=False, total_limit=None,
               per_matrix=None, threads=1, seed=0, seed_known=True, max_candidates=None,
               export_model=False):
    with output_lock(output):
        return _run_search(config, backend, env, output, resume, total_limit, per_matrix,
                           threads, seed, seed_known, max_candidates, export_model)


def _run_search(config, backend, env, output, resume=False, total_limit=None,
                per_matrix=None, threads=1, seed=0, seed_known=True, max_candidates=None,
                export_model=False):
    started = time.monotonic()
    deadline = None if total_limit is None else started + total_limit
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    cp = output / "checkpoint.json"
    if resume:
        state = json.loads(cp.read_text(encoding="utf-8"))
        if state["config"] != config:
            raise ValueError("checkpoint search scope differs from requested parameters")
    else:
        if cp.exists():
            raise ValueError("output already has checkpoint.json; use --resume or a new output directory")
        state = {"format": "circrect-checkpoint-v1", "config": config, "records": {},
                 "best": None, "enumeration_complete": False, "elapsed_seconds": 0}
    n, p, k, b = (config[x] for x in ("n", "prime", "weight", "effective_branch_target"))
    lb, rule = lower_bound(n, k, b)
    theorem = odd_weight3_parameters(config)
    if theorem:
        lb, rule = theorem["minimum"], theorem["name"]
    records, best = state["records"], state["best"]
    if best is not None:
        verify(best)
    seen = set()
    count = 0
    stopped = False
    interrupted = False

    def save():
        state["best"] = best
        state["elapsed_seconds_current_run"] = time.monotonic() - started
        write_json(cp, state)
        if best is not None:
            write_json(output / "best_witness.json", best)

    def process(a):
        nonlocal best, count
        check_time(deadline)
        keydata = canonical(a, p)
        key = json.dumps(keydata, separators=(",", ":"))
        if key in seen:
            return
        seen.add(key)
        prior = records.get(key)
        if prior and (not prior["feasible"] or
                      (best is not None and prior["cost_lower_bound"] >= best["cost"])):
            return
        if max_candidates is not None and count >= max_candidates:
            raise BudgetExpired()
        count += 1
        # Canonical representative, including all signs, drives the solver/cache.
        a = [0] * n
        for j, sign in keydata:
            a[j] = sign
        if config["connected_only"] and components(a) != 1:
            records[key] = {"feasible": False, "reason": "excluded_disconnected"}
            save()
            return
        sec = security(a, p, b, deadline)
        if not sec["passed"]:
            records[key] = {"feasible": False, "security": sec}
            save()
            return
        # Bound dimensions only after the complete security test has passed.
        cap = min(k - 1, k + 1 - (b + 1) // 2)
        items = rectangles(circulant(a, p), p, max_rows=cap, max_cols=cap, deadline=deadline)
        c0 = n * (k - 1)
        sol = solve(items, backend, env, per_matrix, threads, seed, deadline,
                    output / "last_model.lp" if export_model else None)
        rects = [public_rectangle(items[j]) for j in sol["selected"]]
        solver_info = {key: value for key, value in sol.items() if key != "selected"}
        w = make_witness(a, p, config["branch_min"], rects, solver_info,
                         connected_only=config["connected_only"])
        if w["cost"] < lb:
            raise RuntimeError("cost below proved rectangle lower bound")
        # Verify each improved witness independently of the solver and its caches.
        if best is None or w["cost"] < best["cost"]:
            verify(w, deadline)
            best = w
            print(f"best C_rect={w['cost']}, lower bound={lb}, generator={a}", flush=True)
        cost_lb = max(lb, c0 - sol["gain_upper_bound"])
        if prior:
            cost_lb = max(cost_lb, prior["cost_lower_bound"])
        records[key] = {"feasible": True, "generator": a, "cost": w["cost"],
                        "cost_lower_bound": cost_lb, "security": sec, "solver": solver_info,
                        "candidate_count": len(items)}
        save()
        if sol["status"] == "INTERRUPTED":
            raise KeyboardInterrupt()

    impossible = (k < b - 1 or k > n or b > n + 1 or (p == 2 and k % 2 == 0))
    try:
        if theorem:
            check_time(deadline)
            best_constructed = odd_weight3_witness(config, theorem, deadline)
            verify(best_constructed, deadline)
            best = best_constructed
            state["optimality_proof"] = theorem
            print(f"theorem C_rect={lb}, support={theorem['support']}; no enumeration or MILP", flush=True)
        elif not impossible and (best is None or best["cost"] != lb):
            if seed_known:
                for a in seeds(n, p, k, b):
                    process(a)
                    if best and best["cost"] == lb:
                        break
            if best is None or best["cost"] != lb:
                # Revisit incomplete matrix solves first on resume, even if enumeration finished.
                for record in list(records.values()):
                    if record["feasible"] and (best is None or record["cost_lower_bound"] < best["cost"]):
                        process(record["generator"])
                if not state["enumeration_complete"]:
                    for a in generators(n, k, p, deadline):
                        process(a)
                        if best and best["cost"] == lb:
                            break
                    else:
                        state["enumeration_complete"] = True
        if impossible:
            state["enumeration_complete"] = True
    except BudgetExpired:
        stopped = True
    except KeyboardInterrupt:
        stopped = True
        interrupted = True
    unresolved = [r for r in records.values() if r["feasible"] and
                  (best is None or r["cost_lower_bound"] < best["cost"])]
    if theorem and best is not None and best["cost"] == lb:
        status = "THEOREM_OPTIMUM"
        unresolved = []
    elif best is not None and best["cost"] == lb:
        status = "TARGET_ATTAINED"
    elif state["enumeration_complete"] and not unresolved:
        status = "GLOBAL_OPTIMUM" if best else "NO_FEASIBLE_FIXED_WEIGHT"
    else:
        status = "INCOMPLETE_WITH_WITNESS" if best else "INCOMPLETE_NO_WITNESS"
    global_lb = lb
    if state["enumeration_complete"] and best is not None:
        global_lb = max(lb, min([best["cost"]] + [r["cost_lower_bound"] for r in records.values() if r["feasible"]]))
    report = {"format": "circrect-report-v1", "config": config, "status": status,
              "theoretical_lower_bound": lb, "lower_bound_rule": rule,
              "global_lower_bound": global_lb, "best_cost": None if best is None else best["cost"],
              "enumeration_complete": state["enumeration_complete"],
              "unresolved_matrices": len(unresolved), "canonical_records": len(records),
              "attempted_this_run": count, "budget_or_interrupt": stopped,
              "interrupted": interrupted,
              "backend": "closed_form" if theorem else backend, "threads": threads, "seed": seed,
              "optimality_proof": theorem if status == "THEOREM_OPTIMUM" else None,
              "seconds_this_run": time.monotonic() - started,
              "search_scope": "all fixed-weight scalar circulant generators with coefficients in {0,+1,-1}"}
    state["elapsed_seconds"] += time.monotonic() - started
    save()
    write_json(output / "report.json", report)
    return report
