# C_rect Circulant Linear Layer Optimizer

Historical source-snapshot documentation. Paths and local environment details below describe the original project, not the current section-based distribution. See the root README for current instructions. The original Chinese documentation has been translated into English.

Implemented according to the revised definitions in `rectangle_reuse_bounds_and_search.md`, supplemented by the outer-search requirements in `C_pair_search_codex_blueprint.md`. The notation **C_rect** is used consistently, including for what was previously called C_rec.

For a fixed first row `a`, the matrix is `M[i,j] = a[(j-i) mod n]`. Sums of any number of original inputs may be shared; signed rank-one rectangles are allowed over odd prime fields. Rectangles may share rows or columns but may not occupy the same matrix entries. Each rectangle computes its own summation tree; intermediate signals are not shared between rectangles.

The objective is exactly:

```text
C_rect(M) = n*(k-1) - max sum (r-1)*(s-1)
```

Candidates include all admissible subrectangles, not just maximal rectangles. The inner problem is a Gurobi binary set-packing model with capacity one at each matrix position. Optional OR-Tools CP-SAT and standard-library exact backtracking implementations are also provided; backtracking is intended for tiny instances.

## Running locally

### Jupyter interface

Open **`C_rect_interactive.ipynb`** with a Python 3.13 kernel containing Gurobi. Run the loading, parameter, preview, and search cells in order. Set `n`, `B`, `field='F2'/'Fp'`, and `p` in the parameter cell. Integers and lists are supported for n, B, and p; n also accepts a range such as `range(8,33,2)`. Progress and a result table are displayed directly, without command-line interaction.

Searches automatically resume unfinished cases and skip completed ones. After changing parameters, rerun the parameter, preview, and search cells. Results are saved in `runs/notebook`. Subsequent cells let you select a result index to inspect its first row, rectangles, circuit, and independent verification results.

The interface can also be called from another notebook:

```python
from circrect.notebook import search

results = search(n=[12, 15, 16], B=[4, 6], field="F2", time_limit=60)
display(results)

# Odd prime fields:
# results = search(n=[9,11,12], B=5, field="Fp", p=[3,5], time_limit=120)
# results.verify(0)   # Verify the witness at result-table index 0.
# results.table       # A pandas DataFrame if pandas is installed.
```

### Exact-formula shortcut for odd-order binary weight-three matrices

For **F2, odd n, weight three, invertible scalar circulants, B=4**, write `n=3^a*t` with `t>1` and `3` not dividing `t`. The proved theorem gives:

```text
min C_rect = (3*n + 3^a)/2
Attaining support D = {0, 3^a, 2*3^a}
```

Notebook, batch, and single-case searches recognize these parameters and directly generate the matrix, entry-disjoint rectangles, and gate-by-gate circuit. Rank, branch number, and gate count are verified again. **No candidate enumeration, MILP, or Gurobi license initialization is required.** The report status is `THEOREM_OPTIMUM`, displayed as "Theorem construction, C_rect optimality proved" in the translated notebook interface. The formula, a, t, support, and proof source are recorded. This path is independent of `--seed-known`: it applies an exact minimum theorem, not a heuristic seed.

Construction: let `g=3^a`, partition the rows into g odd cycles of length t by their residues modulo g, and choose `(t-1)/2` nonadjacent edges in each cycle. Each edge gives a 2-by-2 reuse rectangle. The total saving is `(n-g)/2` gates, yielding cost `2*n-(n-g)/2=(3*n+g)/2`. The rectangles are also exported as an independently verifiable circuit witness.

```python
# Set these values in the parameter cell; weight=None selects weight three.
n = [15, 21, 45]
B = 4
field = "F2"
# The exact minima are 24, 33, and 72, respectively.
```

Limitations: pure powers of three (`t=1`), even orders, other B values, other weights, and odd prime fields use ordinary search. With `connected_only=True`, this construction is used only for `a=0`. For `a>0` its support has g components, violating the connectivity requirement. This theorem establishes optimality only for C_rect.

### Command line

In the original local environment, `python` on PATH was MSYS Python 3.12, whereas the verified Gurobi installation used Windows Python **3.13.7**:

```powershell
Set-Location E:\LinearLayers
$py313 = "$env:LOCALAPPDATA\Programs\Python\Python313\python.exe"
& $py313 -m circrect doctor --backend gurobi
```

The local PowerShell policy disallowed direct `.ps1` execution, so `& $py313 -m circrect` was used without changing system policy. The program used the existing `gurobipy` installation; no additional software was installed. Verification used Gurobi **12.0.3**. OR-Tools was not present in that environment: the CP-SAT interface was implemented but not tested locally. SAT and OR-Tools CP-SAT are distinct interfaces.

`auto` probes the Gurobi license, reports failures, then tries CP-SAT and finally standard-library backtracking. For production computations, specify `--backend gurobi` to avoid an unintended fallback to exponential backtracking.

## Searching circulant matrices

### Batches over B and n

`batch` runs the Cartesian product of the parameter values. A `start:stop:step` range **includes the endpoint** when the step reaches it; comma-separated values can be mixed with ranges.

```powershell
# F2: B=4,6,8; n=8,10,...,32; 39 cases, at most 60 seconds per case.
& $py313 -m circrect batch --field f2 --branch-values "4,6,8" --n-values "8:32:2" --time-limit-per-case 60 --output runs/grid_f2

# Odd prime fields: p=3,5,7; B=4,5,6; n=8,12,...,32; 120 seconds per case.
& $py313 -m circrect batch --field fp --primes "3,5,7" --branch-values "4:6" --n-values "8:32:4" --time-limit-per-case 120 --output runs/grid_fp

# Resume with the same output directory, adding 300 seconds per case.
& $py313 -m circrect batch --field f2 --branch-values "4,6,8" --n-values "8:32:2" --time-limit-per-case 300 --output runs/grid_f2

# Preview without initializing a solver or writing files.
& $py313 -m circrect batch --field f2 --branch-values "4,6,8" --n-values "8:32:2" --dry-run
```

Set `$py313` once in the current PowerShell session as shown above.

Each case saves its checkpoint, report, and best witness in a separate directory, such as `f2_p2_B6_n16_k5`. Repeated execution resumes unfinished cases and skips those proved optimal or infeasible, without requiring `--resume` for each case. You can extend the B/n lists; existing cases with matching parameters are reused. `summary.csv` lists the requested/effective B, n, weight, status, lower bound, best gate count, and time for the current run. The program also writes `summary.json`, `plan.json`, and `batch_report.json`.

Cases run sequentially in p, B, n order using one solver environment. `--threads` controls Gurobi threads per solve. The default is 60 seconds per case, adjustable with `--time-limit-per-case`. `--time-limit-total` limits the batch time excluding solver initialization; `--time-limit-per-matrix` limits each inner solve. Ctrl+C saves the current search and stops the batch; rerun the same command to continue. An individual case error is recorded before the batch proceeds to other cases.

Over F2, B=5 and B=6 have the same effective target, six. Use even values `4,6,8,...` to avoid duplicate work. If both odd and even requests are supplied, separate directories and labels are retained. By default each search is restricted to the minimum candidate weight `k=b-1`; it does not optimize across weights. Exact enumeration for high B or large n may require multiple runs. Unfinished cases retain `INCOMPLETE_*` status and the available bounds.

### Single cases

```powershell
# F2: B>=5 is treated as effective B>=6 at fixed weight five.
& $py313 -m circrect search --field f2 --branch-min 5 --n 15 --backend gurobi --time-limit-total 60 --output runs/my_f2_n15

# F3: B>=5, fixed weight four, including both signs.
& $py313 -m circrect search --field fp --prime 3 --branch-min 5 --n 12 --backend gurobi --time-limit-total 60 --output runs/my_fp3_n12

# Resume the same search space with more time or another solver implementation.
& $py313 -m circrect search --field f2 --branch-min 5 --n 15 --backend gurobi --time-limit-total 300 --output runs/my_f2_n15 --resume
```

Each run fixes `field,prime,n,weight,branch_min,connected_only`. The default weight is the effective branch target minus one; `--weight` overrides it. The program does not optimize across weights. `--connected-only` requires the support differences to generate the entire cyclic group; this restriction is stored in checkpoints and witnesses.

The exact outer search enumerates supports and all signs, identifying candidates under global translation, multiplication by units modulo n, and global sign reversal. Normalization transforms both positions and signs. The optimal rectangle packing need not have cyclic symmetry. Known families supply seeds, all checked again for rank and branch number; disable them with `--no-seed-known`.

`--time-limit-total` covers outer security checks, candidate generation, and optimization, starting after solver initialization. `--time-limit-per-matrix` limits each inner solve. Time checks and safe persistence may add a small finishing overhead. `--max-candidates` limits the number of normalized candidates processed in the current run. Further options include `--threads`, `--seed`, and `--export-model`.

After each candidate, `checkpoint.json` is saved atomically with processing status, matrix cost lower bounds, solver status, and the best witness. Unresolved candidates are retained and retried first on resume. Candidate generation rescans from the beginning and skips resolved classes; this saves solver time but does not provide immediate jumps to arbitrary enumeration positions. At larger scales, candidate counts, normalization, and checkpoint size can become bottlenecks.

Saving uses separate temporary files and retries transient Windows replacement failures while preserving atomic replacement. Persistent failures leave temporary files for recovery. A process lock prevents two notebook kernels from writing the same `output`. The lock is released when the process exits; the `.circrect.lock` file need not be deleted. After a save error, summaries preserve the best gate count already saved whenever possible.

For single-case search, an output directory containing a checkpoint requires `--resume` or a new directory to avoid overwriting results. Even if enumeration finishes, the search remains incomplete when time-limited candidates might improve the current upper bound; resume with a larger budget.

## Fixed-matrix optimization and independent verification

```powershell
# First-row support {0,1,2,5,10}.
& $py313 -m circrect optimize --field f2 --branch-min 5 --row 1,1,1,0,0,1,0,0,0,0,1,0,0,0,0 --backend gurobi --output runs/my_fixed_n15 --export-model

# Restrict to two-column rectangles to compare with the earlier C_pair model.
& $py313 -m circrect optimize --field f2 --branch-min 5 --row 1,1,1,0,0,1,0,0,0,0,1,0,0,0,0 --backend gurobi --pair-only --output runs/my_fixed_n15_pair

# Verification uses only the Python standard library and loads no solver.
& $py313 -m circrect verify runs/my_fixed_n15/best_witness.json
```

`optimize` first checks the requested invertibility and branch number constraints. A rejected matrix returns `MATRIX_REJECTED` and is not included among acceptable matrices' optimization results.

`best_witness.json` contains the generating row, rectangle rows/columns/signs, gate-by-gate circuit, output signal indices, actual gate count, depth, and solver information. The verifier repeats finite-field, entry-capacity, and private-tree checks, and computes all output coefficients. Invalid signs, overlapping entries, gate sequences, or costs are rejected.

`--pair-only` still produces valid C_rect witnesses, but `optimization_scope` is explicitly C_pair: optimality applies only to the two-column restriction.

`--export-model` saves `model.lp` for fixed optimization or the latest inner model `last_model.lp` during search; it does not archive every candidate's proof. CP-SAT exports add a `.pbtxt` suffix.

## Security checks, bounds, and termination statuses

Finite-field operations use integers modulo p. Invertibility and inverses are computed by exact elimination, including when `p|n`; no floating-point rank is used.

Binary weight-five matrices at effective target six use the complete overlap/inverse-row-weight criterion. Odd-prime weight-four matrices at target five use the signed-overlap/inverse-row-weight criterion. Other parameters use a complete fallback: enumerate inputs of weight at most `floor((b-1)/2)` for both the matrix and its inverse, normalize the first nonzero coefficient to one, and check the weight sum exactly. This can be expensive for large p or high branch numbers. Budget exhaustion does not count an unchecked matrix as accepted.

At minimum weight, the C_rect lower bounds are `ceil(2*(2R-1)*n/(R+1))` for odd `b=2R+1` and `ceil(2*(R-1)*(2R-1)*n/R^2)` for even `b=2R`. All rounding uses integer arithmetic.

At other weights, a conservative rectangle rank-counting bound uses `R=min(k-1,k+1-ceil(b/2))`. If `R<2`, there are no nontrivial rectangles; otherwise `L=ceil(2*n*(k-1)/(R+1))`. This follows from both rectangle dimensions being at most R, `sum(rs-1)<=n(k-1)`, and `(r-1)(s-1)/(rs-1)<=(R-1)/(R+1)`. The old pair-only bound is not used. The integer lower-bound strengthening model in Section 8.5 of the original notes was not implemented; this does not affect correctness of the complete search.

| Status | Meaning |
|---|---|
| `TARGET_ATTAINED` | An independently verified witness attains the theoretical bound, proving optimality in the current search space early |
| `GLOBAL_OPTIMUM` | Complete enumeration; all feasible matrices are solved or certified bounds exclude improvement |
| `NO_FEASIBLE_FIXED_WEIGHT` | No matrix satisfies the constraints at the fixed weight |
| `INCOMPLETE_WITH_WITNESS` | A witness exists, but the optimality proof is incomplete |
| `INCOMPLETE_NO_WITNESS` | Incomplete with no witness; this does not establish infeasibility |
| `FIXED_MATRIX_OPTIMUM` | Only the inner optimization for a fixed matrix is complete |

Global optimality is always scoped to scalar circulants over the specified field, order, weight, branch number, and connectivity option. Relative and absolute MIP gaps are zero; Gurobi's integer feasibility tolerance is `1e-9`. Optimality is established by mathematical bounds or complete enumeration combined with solver bounds; no formal proof certificate is generated. Independent witness verification establishes feasibility and gate count, not optimality over the entire search space by itself.

## Original local verification

```powershell
# Standard-library checks.
& $py313 -m unittest discover -s tests -v

# Full verification including actual Gurobi solves.
& $py313 -m tests.test_circrect --gurobi -v
```

The original local run passed **all 12 tests**: candidate completeness, triple-reuse scoring, signed normalization, exhaustive tiny-instance comparisons, rejection of corrupted witnesses, checkpoint resume, and fixed-weight status checks. Verification requires ordinary Python mode and explicitly rejects `-O`, which disables assertions.

| Instance | Result | Saved output |
|---|---|---|
| F2, n=15, fixed support {0,1,2,5,10}, B=6 | C_rect=40, depth 3; C_pair=45 | `runs/n15_rect`, `runs/n15_pair` |
| F2, n=15, k=5, B>=6, all circulants | **Minimum C_rect=40**; 34 normalized classes, 17 security-feasible | `runs/n15_search` |
| F3, n=12, k=4, B>=5 | C_rect=24, attaining the new bound | `runs/fp3_n12` |
| F2, n=9, k=3, B>=4, all circulants | Minimum C_rect=18 | `runs/f2_n9_b4` |

For n=15, all `C(15,5)=3003` supports independently confirmed the 34 normalized classes. Security was cross-checked on every representative by Gray-code enumeration of all 32767 nonzero inputs. Security-feasible matrices were optimized over complete rectangle candidates without dimension caps. This establishes the previously undetermined minimum cost for the **n=15, weight-five** circulant class in the research notes, with no claim about other weights or general noncirculant matrices.

Module roles: `circrect/algebra.py` handles exact finite fields and branch number checks; `packing.py` handles complete rectangles and solver interfaces; `search.py` handles search and checkpoints; `witness.py` handles circuits and independent verification; `cli.py` provides the command line. Original research Markdown files were not changed.
